"""Convert the Markdown report and Wolfram analysis into notebook inputs."""
import json
import pathlib
import re

root = pathlib.Path(__file__).resolve().parent
repository = root.parents[1]
analysis = (root / 'analyze.wls').read_text()
analysis = analysis[analysis.index('records = data['):analysis.index('Export[FileNameJoin[{root, "metrics.json"}]')]
analysis = analysis.replace('Exit[1]', 'Abort[]')
setup = '''repository = ParentDirectory[NotebookDirectory[]];
PacletDirectoryLoad[FileNameJoin[{repository, "Recursor"}]];
Needs["WolframInstitute`Recursor`"];
Needs["Wolfram`Lambda`"];
data = Import[FileNameJoin[{repository, "docs", "notes", "data", "OEISMeasurements9110.json.gz"}], {"GZIP", "RawJSON"}];
'''+analysis
render = (root / 'render.wls').read_text()
setup += render[render.index('numeric[value_String]'):render.index('UsingFrontEnd[')]
setup += '''prefixSizes = ReverseSort[Values[Counts[Lookup[records, "TrainingKey"]]]];
illustrationIDs = {"A028552", "A037915", "A191967", "A002837"};
heatRecords = Take[SortBy[longCohort, Hash["Recursor-report-9110:" <> #["ID"], "SHA256"] &], 128];
heatValues = Transpose[Take[#, 48] & /@ Lookup[heatRecords, "Matches"]];
parent = Rec[Var, Const[1], Mul[Succ[Idx], Acc]];
mutationExample = <|"Seed" -> 2, "Site" -> BlockRandom[SeedRandom[2]; RandomChoice[RecursorSites[parent]]], "Mutant" -> BlockRandom[SeedRandom[2]; MutateRecursor[parent, 3]]|>;
assert[FormatRecursor[mutationExample["Mutant"]] === "Rec[Var, Const[1], Mul[Succ[Acc], Acc]]", "Mutation illustration"];
'''
(root / 'notebook-setup.wl').write_text(setup)
blocks = []
lines = (repository / 'docs/notes/OEISMeasurements9110.md').read_text().splitlines()
i = 0
while i < len(lines):
    line = lines[i]
    if not line.strip():
        i += 1
        continue
    if line.startswith('```'):
        code = []
        i += 1
        while lines[i] != '```':
            code.append(lines[i]); i += 1
        blocks.append({'Kind':'Input','Text':'\n'.join(code)})
        i += 1
        continue
    figure = re.fullmatch(r'!\[([^\]]*)\]\(figures/OEISMeasurements9110/([^)]*)\.svg\)', line)
    if figure:
        blocks.append({'Kind':'Figure','Name':figure[2],'Alt':figure[1]})
        i += 1
        continue
    if line.startswith('# '):
        blocks.append({'Kind':'Title','Text':line[2:]}); i += 1; continue
    if line.startswith('## '):
        blocks.append({'Kind':'Section','Text':line[3:]}); i += 1; continue
    paragraph = [line]
    i += 1
    while i < len(lines) and lines[i].strip() and not lines[i].startswith(('# ', '## ', '```', '![', '- ')):
        paragraph.append(lines[i]); i += 1
    text = ' '.join(part.strip() for part in paragraph)
    if text.startswith('*Figure ') and text.endswith('*'):
        blocks.append({'Kind':'Caption','Text':text[1:-1]})
    elif text.startswith('- '):
        blocks.append({'Kind':'Item','Text':text[2:]})
    else:
        blocks.append({'Kind':'Text','Text':text})
token_pattern = re.compile(r"(\[[^\]]+\]\([^)]+\)|\*\*[^*]+\*\*|`[^`]+`)")
for block in blocks:
    if block['Kind'] in ('Input', 'Figure'):
        if block['Kind'] == 'Input':
            function = re.match(r'(a\d{6})\[n_\]\s*:=', block['Text'])
            if function:
                block['FunctionName'] = function[1]
                block['SequenceID'] = function[1].upper()
        continue
    parts = []
    for token in token_pattern.split(block['Text']):
        if not token:
            continue
        if token.startswith('[') and '](' in token:
            label, target = token[1:-1].split('](', 1)
            parts.append({'Kind':'Link','Text':label,'Target':target})
        elif token.startswith('**'):
            parts.append({'Kind':'Bold','Text':token[2:-2]})
        elif token.startswith('`'):
            parts.append({'Kind':'InlineCode','Text':token[1:-1]})
        else:
            parts.append({'Kind':'Plain','Text':token})
    block['Parts'] = parts
assert len([b for b in blocks if b['Kind']=='Figure']) == 42
grouped = []
for block in blocks:
    if block['Kind'] == 'Caption':
        assert grouped[-1]['Kind'] == 'Figure'
        grouped[-1]['Caption'] = block
    else:
        grouped.append(block)
blocks = grouped
(root / 'notebook-blocks.json').write_text(json.dumps(blocks, ensure_ascii=False))
print('Prepared', len(blocks), 'notebook blocks and reproducible Mathematica setup.')
