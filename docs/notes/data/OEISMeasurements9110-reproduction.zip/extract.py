"""Read the historical 9,110-fit checkpoint without changing the running study."""
import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import sqlite3
import zlib

root = pathlib.Path(__file__).resolve().parent
repository = root.parents[1]
study = root.parent / 'oeis-corpus-v1'
cutoff = '2026-11-06T07:26:05.809007+00:00'
db = sqlite3.connect('file:' + str(study / 'results.sqlite3') + '?mode=ro', uri=True, timeout=30)
db.row_factory = sqlite3.Row
db.execute('BEGIN')
protocol = json.loads((study / 'protocol.json').read_text())

ranking = '''WITH ranked AS (
 SELECT t.job_id,t.id,t.fitness,t.nodes,t.seed,t.training_exact,t.test_exact,t.extended_count,t.extended_exact,
 row_number() OVER(PARTITION BY t.id ORDER BY t.fitness DESC,t.nodes ASC,t.seed ASC) AS rank
 FROM trials t JOIN jobs j USING(job_id)
 WHERE t.arm='Evolution' AND t.status='Completed' AND j.finished_utc<=?
) '''
selected = [dict(row) for row in db.execute(ranking + 'SELECT * FROM ranked WHERE rank=1', (cutoff,))]
assert len(selected) == 283165
cohort_jobs = {row['job_id'] for row in selected if row['training_exact']}
assert len(cohort_jobs) == 9110

records = []
for job_id in sorted(cohort_jobs):
    row = db.execute('''SELECT s.id,s.name,s.offset,s.terms_json,s.source_sha256,s.source_wl_json,
                       b.last_term_training,b.last_term_test,b.affine_training,b.affine_test,
                       t.result_zlib FROM trials t JOIN sequences s USING(id) JOIN baselines b USING(id)
                       WHERE t.job_id=?''', (job_id,)).fetchone()
    trial = json.loads(zlib.decompress(row['result_zlib']))
    search, validation = trial['Search'], trial['Validation']
    checks = validation['Checks']
    terms = json.loads(row['terms_json'])
    assert [item['Expected'] for item in checks] == terms
    assert [item['Input'] for item in checks] == list(range(int(row['offset']), int(row['offset']) + len(terms)))
    assert all(item['Match'] for item in checks[:8])
    records.append({
        'ID': row['id'], 'Name': row['name'], 'Offset': int(row['offset']), 'Terms': terms,
        'SourceSHA256': row['source_sha256'], 'OEISWLReference': json.loads(row['source_wl_json']),
        'JobID': job_id, 'Seed': trial['Seed'], 'TrainingKey': trial['TrainingKey'],
        'Program': search['Program'], 'Nodes': search['Nodes'], 'FitnessHistory': search['FitnessHistory'],
        'SearchSeconds': search['Seconds'], 'SearchSourceJob': trial['SearchSourceJob'],
        'ActualSearchExecuted': trial['ActualSearchExecuted'],
        'CandidateProposals': search['CandidateProposals'], 'DistinctCandidates': search['DistinctCandidates'],
        'Values': [item['Value'] for item in checks], 'Statuses': [item['Status'] for item in checks],
        'Matches': [int(item['Match']) for item in checks],
        'PrimaryExact': all(item['Match'] for item in checks[:20]),
        'AllRecordedExact': all(item['Match'] for item in checks),
        'TrainingFitnessRechecked': validation.get('TrainingFitnessRechecked', False),
        'WLCode': validation['WL']['Code'], 'WLStatus': validation['WL']['Status'],
        'WLMethod': validation['WL']['Method'],
        'WLVerifiedComparisons': validation['WL'].get('VerifiedComparisons', 0),
        'WLIncompleteComparisons': validation['WL'].get('IncompleteComparisons', 0),
        'ConstantBaselineTrainingExact': bool(row['last_term_training']),
        'ConstantBaselinePrimaryExact': bool(row['last_term_training'] and row['last_term_test']),
        'AffineBaselineTrainingExact': bool(row['affine_training']),
        'AffineBaselinePrimaryExact': bool(row['affine_training'] and row['affine_test']),
    })
records.sort(key=lambda row: row['ID'])
assert sum(row['PrimaryExact'] for row in records) == 897
assert sum(row['AllRecordedExact'] for row in records) == 91
print('Read 9,110 training-fitting programs and all their recorded-term checks.', flush=True)

first_pass_histograms = [[0]*9 for _ in range(21)]
first_pass_status = collections.Counter()
first_pass_counts = collections.Counter()
execution = collections.Counter()
primary_seconds = 0.0
for index, row in enumerate(db.execute('''SELECT t.*,j.finished_utc FROM trials t JOIN jobs j USING(job_id)
                   WHERE t.arm='Evolution' AND t.seed=9101 AND j.status='Done' AND j.finished_utc<=?''', (cutoff,)), 1):
    trial = json.loads(zlib.decompress(row['result_zlib']))
    first_pass_status[row['status']] += 1
    first_pass_counts['Attempted'] += 1
    first_pass_counts['TrainingFits'] += row['training_exact']
    first_pass_counts['JointFits'] += row['training_exact'] * row['test_exact']
    first_pass_counts['AllRecordedFits'] += row['training_exact'] * row['test_exact'] * int(row['extended_count']==0 or row['extended_exact'])
    search = trial['Search']
    if search['Status'] == 'Completed':
        for generation, score in enumerate(search['FitnessHistory']):
            first_pass_histograms[generation][score] += 1
    if trial['ActualSearchExecuted']:
        execution['ExecutedSearches'] += 1
        primary_seconds += search.get('Seconds', 0)
    else:
        execution['ReusedSearches'] += 1
    if index % 50000 == 0:
        print('Read first-pass loss histories:', index, flush=True)
assert first_pass_counts['Attempted'] == 283167

ablation = set(protocol['AblationIDs'])
deep = set(protocol['DeepSearchIDs'])
comparisons = []
for row in db.execute('''SELECT t.* FROM trials t JOIN jobs j USING(job_id)
                         WHERE t.seed=9101 AND j.status='Done' AND j.finished_utc<=?''', (cutoff,)):
    if not ((row['arm'] == 'Evolution' and row['id'] in ablation) or row['arm'] in ['NoMutation','NoCrossover','RandomSearch','DeepEvolution']):
        continue
    trial = json.loads(zlib.decompress(row['result_zlib']))
    search = trial['Search']
    comparisons.append({
        'ID': row['id'], 'Seed': row['seed'], 'Arm': row['arm'], 'Status': row['status'],
        'History': search.get('FitnessHistory', []), 'TrainingFit': bool(row['training_exact']),
        'JointFit': bool(row['training_exact'] and row['test_exact']),
        'AllRecordedFit': bool(row['training_exact'] and row['test_exact'] and (row['extended_count']==0 or row['extended_exact'])),
        'SearchSeconds': search.get('Seconds', 0),
        'ActualSearchSeconds': trial.get('ActualSearchSeconds', search.get('Seconds', 0)),
        'ActualSearchExecuted': trial['ActualSearchExecuted'], 'SearchSourceJob': trial['SearchSourceJob'],
        'Proposals': search.get('CandidateProposals'), 'DistinctCandidates': search.get('DistinctCandidates'),
        'Nodes': search.get('Nodes'), 'DeepCohort': row['id'] in deep,
    })
assert len(comparisons) == 9216
baseline = dict(db.execute('''SELECT count(*) AS Eligible,sum(last_term_training*last_term_test) AS ConstantJointFits,
           sum(affine_training*affine_test) AS AffineJointFits,sum(constant_training) AS ConstantTrainingPrefixes,
           count(distinct training_key) AS DistinctTrainingPrefixes FROM baselines''').fetchone())
stage_jobs = [dict(row) for row in db.execute('''SELECT phase,count(*) AS Completed FROM jobs WHERE status='Done' AND finished_utc<=? GROUP BY phase''', (cutoff,))]
db.close()

payload = {
    'Title': 'Recursor on OEIS: an interim measurement of 9,110 training fits',
    'CutoffUTC': cutoff, 'ExtractedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'SelectionRule': 'Highest independently checked training score, then fewer nodes, then lower seed; no held-out selection.',
    'Protocol': protocol, 'HistoricalSelectedCount': len(selected), 'CompletedJobsByPhase': stage_jobs,
    'PrimaryPass': dict(first_pass_counts), 'PrimaryPassStatuses': dict(first_pass_status),
    'PrimaryPassFitnessCounts': first_pass_histograms,
    'PrimaryPassExecution': dict(execution, ActualSearchSeconds=primary_seconds),
    'Baselines': baseline, 'Sequences': records, 'Comparisons': comparisons,
    'Notice': 'OEIS data copyright the OEIS Foundation Inc. and contributors; CC BY-SA 4.0. Code follows the Recursor MIT license.'
}
out = repository / 'docs/notes/data/OEISMeasurements9110.json.gz'
serialized = json.dumps(payload, separators=(',', ':'), ensure_ascii=False).encode()
with open(out, 'wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        compressed.write(serialized)
(root/'input.json').write_bytes(serialized)
manifest = {'CutoffUTC': cutoff, 'TrainingFitCount': len(records), 'PrimaryTestFitCount': 897,
            'AllRecordedFitCount': 91, 'DataSHA256': hashlib.sha256(out.read_bytes()).hexdigest(),
            'UncompressedSHA256': hashlib.sha256(serialized).hexdigest(), 'Bytes': out.stat().st_size}
(root/'extraction.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(manifest), flush=True)
