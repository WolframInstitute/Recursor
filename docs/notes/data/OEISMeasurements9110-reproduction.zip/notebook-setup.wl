repository = ParentDirectory[NotebookDirectory[]];
PacletDirectoryLoad[FileNameJoin[{repository, "Recursor"}]];
Needs["WolframInstitute`Recursor`"];
data = Import[FileNameJoin[{repository, "docs", "notes", "data", "OEISMeasurements9110.json.gz"}], {"GZIP", "RawJSON"}];
records = data["Sequences"];
comparisons = data["Comparisons"];
assert[condition_, message_] := If[! TrueQ[condition], Print["FAILED: ", message]; Abort[]];
assert[Length[records] === 9110 && Count[Lookup[records, "PrimaryExact"], True] === 897 && Count[Lookup[records, "AllRecordedExact"], True] === 91, "Checkpoint totals"];
assert[AllTrue[records, Take[#["Matches"], 8] === ConstantArray[1, 8] &], "Training fits"];
assert[AllTrue[records, Length[#["Terms"]] === Length[#["Matches"]] === Length[#["Values"]] === Length[#["Statuses"]] &], "Complete term records"];
indexed = AssociationThread[Lookup[records, "ID"], records];
passed = Select[records, #["PrimaryExact"] &];
complete = Select[records, #["AllRecordedExact"] &];
failed = Select[records, ! #["PrimaryExact"] &];
firstPerfect[record_] := First[FirstPosition[record["FitnessHistory"], 8]] - 1;
firstFailure[record_] := Replace[FirstPosition[record["Matches"], 0], {position_List :> First[position], _Missing -> Null}];
constantPrefixQ[record_] := Length[DeleteDuplicates[Take[record["Terms"], 8]]] === 1;
constantWLQ[record_] := StringMatchQ[record["WLCode"], RegularExpression["Function\\[n,[0-9]+\\]"]];
meanLoss[group_] := N[1 - Mean[Lookup[group, "FitnessHistory"]]/8];
weightedLoss[counts_] := N[1 - (Range[0, 8].counts)/(8 Total[counts])];
primaryLoss = weightedLoss /@ data["PrimaryPassFitnessCounts"];
cohortLoss = meanLoss[records];
generationCounts = Table[Count[firstPerfect /@ records, generation], {generation, 0, 20}];
cohortGroups = GroupBy[records, If[constantPrefixQ[#], "Constant prefix", "Varying prefix"] &];
lengths = Length /@ Lookup[records, "Terms"];
longCohort = Select[records, Length[#["Terms"]] >= 48 &];
prefixSurvival = Table[{horizon, N[100 Count[Map[Total[Take[#["Matches"], 8 + horizon]] == 8 + horizon &, longCohort], True]/Length[longCohort]]}, {horizon, 0, 40}];
positionAgreement = Table[{position, N[100 Mean[Lookup[longCohort, "Matches"][[All, position]]]]}, {position, 1, 48}];
termAgreementCounts = Table[Count[Total /@ (Take[Drop[#, 8], 12] & /@ Lookup[records, "Matches"]), score], {score, 0, 12}];
primaryStatuses = Counts[Flatten[Take[Drop[#, 8], 12] & /@ Lookup[records, "Statuses"]]];
allStatuses = Counts[Flatten[Lookup[records, "Statuses"]]];
primaryOnlyBudgetFailures = Select[failed, AllTrue[Transpose[{Take[Drop[#["Statuses"], 8], 12], Take[Drop[#["Matches"], 8], 12]}], First[#] =!= "Completed" || Last[#] === 1 &] &];
arms = {"Evolution", "NoMutation", "NoCrossover", "RandomSearch"};
armNames = {"Evolution", "No mutation", "No crossover", "Random search"};
armGroups = KeyTake[GroupBy[comparisons, #["Arm"] &], arms];
assert[And @@ (Length[#] == 2048 & /@ Values[armGroups]), "Matched comparison sizes"];
assert[SameQ @@ (Sort[Lookup[#, "ID"]] & /@ Values[armGroups]), "Matched comparison IDs"];
armSummary = KeyValueMap[Function[{arm, group}, <|"Arm" -> arm, "Sequences" -> Length[group], "TrainingFits" -> Count[Lookup[group, "TrainingFit"], True], "JointFits" -> Count[Lookup[group, "JointFit"], True], "AllRecordedFits" -> Count[Lookup[group, "AllRecordedFit"], True], "TotalSearchSeconds" -> Total[Lookup[group, "ActualSearchSeconds"]], "MedianLogicalTrialSeconds" -> Median[Lookup[group, "SearchSeconds"]]|>], armGroups];
armCurves = Map[N[1 - Mean[Lookup[#, "History"]]/8] &, armGroups];
armIndex = AssociationMap[AssociationThread[Lookup[armGroups[#], "ID"], armGroups[#]] &, arms];
pairContrasts = AssociationMap[Function[arm, With[{pairs = Transpose[{Values[KeySort[armIndex["Evolution"]]], Values[KeySort[armIndex[arm]]]}]}, <|"EvolutionOnly" -> Count[Map[#[[1]]["JointFit"] && ! #[[2]]["JointFit"] &, pairs], True], "ComparisonOnly" -> Count[Map[! #[[1]]["JointFit"] && #[[2]]["JointFit"] &, pairs], True]|>]], Rest[arms]];
deepGroups = <|"Standard" -> Select[armGroups["Evolution"], #["DeepCohort"] &], "Larger and deeper" -> Select[comparisons, #["Arm"] === "DeepEvolution" &]|>;
assert[And @@ (Length[#] == 1024 & /@ Values[deepGroups]), "Deep comparison sizes"];
deepCurves = Map[N[1 - Mean[Lookup[#, "History"]]/8] &, deepGroups];
deepSummary = KeyValueMap[Function[{arm, group}, <|"Arm" -> arm, "Sequences" -> Length[group], "TrainingFits" -> Count[Lookup[group, "TrainingFit"], True], "JointFits" -> Count[Lookup[group, "JointFit"], True], "AllRecordedFits" -> Count[Lookup[group, "AllRecordedFit"], True], "TotalSearchSeconds" -> Total[Lookup[group, "ActualSearchSeconds"]]|>], deepGroups];
baselineOverlap = <|"Both" -> Length[Select[records, #["PrimaryExact"] && #["AffineBaselinePrimaryExact"] &]], "RecursorOnly" -> Length[Select[records, #["PrimaryExact"] && ! #["AffineBaselinePrimaryExact"] &]]|>;
baselineOverlap["AffineOnly"] = data["Baselines"]["AffineJointFits"] - baselineOverlap["Both"];
baselineOverlap["RecursorOnlyAllRecorded"] = Length[Select[complete, ! #["AffineBaselinePrimaryExact"] &]];
groupSummary = KeyValueMap[Function[{name, group}, <|"Group" -> name, "TrainingFits" -> Length[group], "JointFits" -> Count[Lookup[group, "PrimaryExact"], True], "AllRecordedFits" -> Count[Lookup[group, "AllRecordedExact"], True]|>], cohortGroups];
exampleIDs = {"A028552", "A037915", "A191967", "A000030", "A002837", "A006983"};
assert[And @@ (KeyExistsQ[indexed, #] & /@ exampleIDs), "Illustration IDs"];
metrics = <|
 "CutoffUTC" -> data["CutoffUTC"], "Eligible" -> data["Protocol"]["EligibleCount"], "TotalRecords" -> data["Protocol"]["SequenceCount"],
 "CoveredWithValidatedProgram" -> data["HistoricalSelectedCount"], "TrainingFits" -> Length[records], "PrimaryFits" -> Length[passed], "AllRecordedFits" -> Length[complete],
 "ConditionalPrimaryPercent" -> N[100 Length[passed]/Length[records]], "ConditionalAllRecordedPercent" -> N[100 Length[complete]/Length[records]],
 "CorpusPrimaryPercent" -> N[100 Length[passed]/data["Protocol"]["EligibleCount"]], "CorpusAllRecordedPercent" -> N[100 Length[complete]/data["Protocol"]["EligibleCount"]],
 "FirstPass" -> data["PrimaryPass"], "FirstPassStatuses" -> data["PrimaryPassStatuses"],
 "DistinctTrainingPrefixes" -> Length[DeleteDuplicates[Lookup[records, "TrainingKey"]]],
 "DistinctPrimaryFitPrefixes" -> Length[DeleteDuplicates[Lookup[passed, "TrainingKey"]]],
 "DistinctAllRecordedFitPrefixes" -> Length[DeleteDuplicates[Lookup[complete, "TrainingKey"]]],
 "DistinctPrograms" -> Length[DeleteDuplicates[Lookup[records, "Program"]]],
 "DistinctAllRecordedPrograms" -> Length[DeleteDuplicates[Lookup[complete, "Program"]]],
 "ConstantWLPrimaryFits" -> Length[Select[passed, constantWLQ]], "ConstantWLAllRecordedFits" -> Length[Select[complete, constantWLQ]],
 "InitialTrainingFits" -> First[generationCounts], "FirstPerfectGenerationCounts" -> generationCounts,
 "MedianFirstPerfectGeneration" -> Median[firstPerfect /@ records], "PrimaryMeanInitialLoss" -> First[primaryLoss], "PrimaryMeanFinalLoss" -> Last[primaryLoss],
 "SelectedMeanInitialLoss" -> First[cohortLoss], "SelectedMeanFinalLoss" -> Last[cohortLoss],
 "LongCohortSize" -> Length[longCohort], "RecordedTermsMinimum" -> Min[lengths], "RecordedTermsMedian" -> Median[lengths], "RecordedTermsMaximum" -> Max[lengths],
 "PrimaryEvaluationStatuses" -> primaryStatuses, "AllEvaluationStatuses" -> allStatuses, "PrimaryFailuresWithoutObservedWrongValue" -> Length[primaryOnlyBudgetFailures],
 "WLVerificationStatuses" -> Counts[Lookup[records, "WLStatus"]], "TrainingFitnessRecheckFailures" -> Count[Lookup[records, "TrainingFitnessRechecked"], False],
 "Baselines" -> data["Baselines"], "BaselineOverlap" -> baselineOverlap, "PrefixGroups" -> groupSummary,
 "Arms" -> armSummary, "PairedContrasts" -> pairContrasts, "DeepArms" -> deepSummary,
 "Examples" -> Map[Join[KeyTake[#, {"ID", "Name", "Offset", "Program", "Nodes", "Seed", "WLCode", "WLStatus", "PrimaryExact", "AllRecordedExact"}], <|"RecordedTerms" -> Length[#["Terms"]], "FirstPerfectGeneration" -> firstPerfect[#], "FirstFailurePosition" -> firstFailure[#]|>] &, Lookup[indexed, exampleIDs]],
 "SourceDataSHA256" -> IntegerString[FileHash[FileNameJoin[{repository, "docs", "notes", "data", "OEISMeasurements9110.json.gz"}], "SHA256"], 16, 64],
 "WolframVersion" -> $Version, "SystemID" -> $SystemID
|>;
numeric[value_String] /; StringMatchQ[value, DigitCharacter..] := FromDigits[value];
numeric[_] := Missing["Unfinished"];
predictionPlot[id_, count_: All] := Module[{record = indexed[id], amount, inputs, observed, predicted},
 amount = If[count === All, Length[record["Terms"]], Min[count, Length[record["Terms"]]]];
 inputs = Range[record["Offset"], record["Offset"] + amount - 1];
 observed = Take[record["Terms"], amount];
 predicted = numeric /@ Take[record["Values"], amount];
 ListPlot[{Transpose[{inputs, observed}], Transpose[{inputs, predicted}]}, Joined -> {True, False}, PlotMarkers -> Automatic,
  PlotLegends -> {"OEIS", "Recursor"}, Frame -> True, FrameLabel -> {"Original index n", "a(n)"}, PlotLabel -> id,
  GridLines -> {{record["Offset"] + 7.5, record["Offset"] + 19.5}, None}, PlotRange -> All]
];
prefixSizes = ReverseSort[Values[Counts[Lookup[records, "TrainingKey"]]]];
illustrationIDs = {"A028552", "A037915", "A191967", "A002837"};
heatRecords = Take[SortBy[longCohort, Hash["Recursor-report-9110:" <> #["ID"], "SHA256"] &], 128];
heatValues = Transpose[Take[#, 48] & /@ Lookup[heatRecords, "Matches"]];
parent = Rec[Var, Const[1], Mul[Succ[Idx], Acc]];
mutationExample = <|"Seed" -> 2, "Site" -> BlockRandom[SeedRandom[2]; RandomChoice[RecursorSites[parent]]], "Mutant" -> BlockRandom[SeedRandom[2]; MutateRecursor[parent, 3]]|>;
assert[FormatRecursor[mutationExample["Mutant"]] === "Rec[Var, Const[1], Mul[Succ[Acc], Acc]]", "Mutation illustration"];
