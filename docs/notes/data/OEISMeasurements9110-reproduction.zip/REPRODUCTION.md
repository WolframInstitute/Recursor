# Reproduce the 9,110-fit report

The checkpoint is 2026-11-06T07:26:05.809007+00:00. The report does not read
later results and reproduction does not start, stop or alter experiment workers.

The checked-in Markdown is the prose source. The compressed JSON contains all
9,110 selected records, the matched comparisons and aggregate first-pass loss
counts. Mathematica computes the statistics and figures from that JSON.

## Run from a Recursor checkout

Use a licensed Wolfram Language 15 installation with its front end and Python 3.
The reference computation used Mathematica 15.0.0 on MacOSX-ARM64. The package
kernel matches revision e7786c8b9200a308e495a91e6bb66000d0fa0462; keep that
revision of Recursor/Kernel when reproducing the seeded mutation illustration.

From the repository root:

```sh
unzip docs/notes/data/OEISMeasurements9110-reproduction.zip -d build/oeis-measurements-9110-replay
python3 build/oeis-measurements-9110-replay/prepare-notebook.py
wolframscript -file build/oeis-measurements-9110-replay/build-notebook.wls
wolframscript -file build/oeis-measurements-9110-replay/evaluate-notebook.wls
wolframscript -file build/oeis-measurements-9110-replay/export-figures.wls
```

The build recomputes the metrics and checks them against the saved reference,
then writes notebooks/RecursorOEISMeasurements-01.nb. The second Wolfram command
evaluates the actual saved Input boxes in a fresh kernel and checks all 32
native figures and the metrics. The last command rewrites the SVG figures.
No corpus search is run. Native plot appearance can differ across front ends.

Alternatively, open the saved notebook and evaluate its closed “Recompute the
measurements” section, then its figure cells. The notebook's package load is
separate from parsing expressions that use its symbols.

## Files in this archive

- `extract.py`: historical SQLite extraction, using a read-only connection.
  This optional step requires the original results.sqlite3 and protocol.json
  in build/oeis-corpus-v1; the shared compressed JSON replaces that requirement
  for report reproduction.
- `analyze.wls`, `render.wls`: original analysis and figure-generation record.
  They use local build inputs; the portable sequence above uses notebook-setup.wl.
- `prepare-notebook.py`: derives notebook blocks and setup from the Markdown,
  analysis and render sources.
- `notebook-setup.wl`, `notebook-blocks.json`, `figure-sources.json`: saved
  executable analysis, report content and figure expressions.
- `build-notebook.wls`, `evaluate-notebook.wls`, `export-figures.wls`: build,
  check and export the report from the shared data.
- `validation.json`: recorded checks on the delivered report.
- `SHA256SUMS`: hashes of the archived reproduction files.

Report data SHA-256:
1fd52993f55048d6b2f73503869538bc3797b5f100e125c9df398b1780183096

The OEIS source repository is https://github.com/WolframInstitute/OEIS at
revision d82309e7f1436b641490aa8abf426c39e0d158a7, with oeisdata revision
69c667df437a093151042e2cbec1f1198e70765a. Sequence data, names and reference code
are copyright the OEIS Foundation Inc. and contributors, under CC BY-SA 4.0
(https://creativecommons.org/licenses/by-sa/4.0/). The report, its derived data
and figures use the same license. Recursor and the reproduction code use MIT.

The data include finite term checks, not mathematical proofs. Unexecuted OEIS
WL reference text must not be evaluated by the report generators.
