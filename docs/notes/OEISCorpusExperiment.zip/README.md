# Recursor OEIS corpus experiment

This is a frozen experiment, not a new paclet API. The search uses the public
Recursor functions at revision `e7786c8b9200a308e495a91e6bb66000d0fa0462`.
`protocol.json` specifies the data, cohorts, random seeds and evaluation rules.

## Run and inspect

Run these commands from this directory with Python 3.9 or later:

```sh
python3 run.py status
python3 run.py run --hours 24 --workers 12
python3 run.py export
```

The experiment resumes pending jobs. A file named `STOP` requests a checkpoint
after active jobs finish. Remove that file before explicitly resuming. A lock
prevents two experiment managers from writing at once. A deadline stops new
jobs; active jobs finish under their individual resource budgets.

`progress.md` and `summary.json` update each minute. `report.md`, SVG figures,
`sequence-results.csv.gz`, `generalized.csv` and `loss-curves.csv` update hourly
and at shutdown. `results.sqlite3` is the authoritative checkpoint: it contains
every sequence, exclusion, trial, program and per-term validation record. Trial
JSON is compressed in `trials.result_zlib`; decode it with `zlib.decompress`.
The successful-sequence export requires an exact fit to all eight training and
twelve primary held-out terms. Further recorded terms are reported separately.

## Reproduce in a fresh directory

Extract `experiment-code.zip` into `Recursor/build/oeis-corpus-v1` in a fresh
Recursor checkout. Create the pinned source worktree there:

```sh
git worktree add --detach build/oeis-corpus-v1/source e7786c8b9200a308e495a91e6bb66000d0fa0462
```

Clone `https://github.com/WolframInstitute/OEIS` at the revision in the protocol
and initialize its `oeisdata` submodule at the recorded revision. Set
`RECURSOR_OEIS_PATH` to that checkout. From the experiment directory, run
`python3 prepare.py`; preparation refuses to overwrite an existing database.
It parses the complete corpus and verifies the frozen inventory digest.

Set `RECURSOR_CORPUS_KERNEL` to the native WolframKernel executable and
`WOLFRAM_USERBASE` to a licensed Wolfram user base. The recorded run uses Wolfram
Language 15.0.0 on macOS ARM64. The renderer additionally expects
`/usr/local/bin/wolframscript`. No credentials are included in this archive.
The controller uses Python's standard library and macOS process conventions.

Run `python3 client.py` for a native-kernel smoke check. `test-worker.wls` checks
the standalone WL translation. `code-manifest.json` hashes the frozen runner,
protocol, provenance files and paclet source; workers refuse altered inputs.
Do not edit the frozen files during a run. Create a new study directory for a
changed protocol.

## Interpretation and provenance

The first eight indexed terms are the only sequence information available to
search. Names, formulas, held-out terms and existing OEIS WL code are excluded.
Stored OEIS code is unexecuted reference text. Repeated training prefixes may
reuse a search, identified by its source job, but have separate held-out checks.

Compact WL means the shortest candidate found by the recorded translations and
verified on completed inputs. It does not mean a globally minimal program.
Resource exhaustion is recorded separately. Finite held-out agreement does
not prove equality of infinite sequences.

OEIS data are copyright the OEIS Foundation Inc. and contributors, under
CC BY-SA 4.0. The experiment code follows Recursor's MIT license. The pinned
snapshot, inventory digest and original source hashes identify the data used.
