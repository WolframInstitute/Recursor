import csv
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from run import ROOT, atomic_json, connect, summary, unpack, utc


def collect():
    db = connect()
    db.execute('BEGIN')
    status = summary(database=db)
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    ablation_ids = set(protocol['AblationIDs'])
    deep_ids = set(protocol['DeepSearchIDs'])
    curves = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    paired = defaultdict(dict)
    deep = defaultdict(dict)
    diagnostics = Counter()
    execution_seconds = 0
    reused = 0
    executed = 0
    for row in db.execute("SELECT * FROM trials WHERE status!='AwaitingValidation'"):
        result = unpack(row['result_zlib'])
        search = result['Search']
        validation = result.get('Validation', {})
        diagnostics[row['status']] += 1
        if result.get('ActualSearchExecuted', True):
            executed += 1
            execution_seconds += search.get('Seconds', 0)
        else:
            reused += 1
        if validation.get('Status') == 'Completed':
            if not validation.get('TrainingFitnessRechecked', False):
                diagnostics['TrainingFitnessRecheckMismatch'] += 1
            for check in validation['Checks']:
                diagnostics['Evaluation:' + check['Status']] += 1
            diagnostics['WL:' + validation['WL']['Status']] += 1
        if search['Status']=='Completed' and (row['arm'] != 'Evolution' or row['seed'] == 9101):
            for generation, fitness in enumerate(search['FitnessHistory']):
                aggregate = curves[row['arm']][generation]
                aggregate[0] += 1
                aggregate[1] += fitness
        value = {'TrainingFit': bool(row['training_exact']), 'JointFit': bool(row['training_exact'] and row['test_exact']),
                 'Completed': row['status'] == 'Completed', 'FitnessHistory': search.get('FitnessHistory',[]), 'Program': row['program']}
        key = (row['id'], row['seed'])
        if row['id'] in ablation_ids and row['arm'] in ['Evolution', 'NoMutation', 'NoCrossover', 'RandomSearch']:
            paired[key][row['arm']] = value
        if row['id'] in deep_ids and row['seed'] == 9101 and row['arm'] in ['Evolution', 'DeepEvolution']:
            deep[key][row['arm']] = value
    arms = ['Evolution', 'NoMutation', 'NoCrossover', 'RandomSearch']
    matched = [value for value in paired.values() if all(arm in value for arm in arms)]
    matched_complete = [value for value in matched if all(value[arm]['Completed'] for arm in arms)]
    paired_summary = []
    paired_curves = {}
    for arm in arms:
        paired_summary.append({'Arm': arm, 'Pairs': len(matched), 'Completed':sum(value[arm]['Completed'] for value in matched), 'TrainingFits': sum(value[arm]['TrainingFit'] for value in matched),
                               'JointFits': sum(value[arm]['JointFit'] for value in matched)})
        if matched_complete:
            paired_curves[arm] = [[24 + 22*g, statistics.mean(1-value[arm]['FitnessHistory'][g]/8 for value in matched_complete)] for g in range(21)]
    contrasts = {}
    for arm in arms[1:]:
        contrasts[arm] = {'EvolutionOnlyJointFits': sum(value['Evolution']['JointFit'] and not value[arm]['JointFit'] for value in matched),
                          'ComparisonOnlyJointFits': sum(value[arm]['JointFit'] and not value['Evolution']['JointFit'] for value in matched)}
    deep_matched = [value for value in deep.values() if all(arm in value for arm in ['Evolution', 'DeepEvolution'])]
    deep_complete = [value for value in deep_matched if all(value[arm]['Completed'] for arm in ['Evolution','DeepEvolution'])]
    deep_summary = [{'Arm': arm, 'Pairs': len(deep_matched), 'Completed':sum(value[arm]['Completed'] for value in deep_matched), 'JointFits': sum(value[arm]['JointFit'] for value in deep_matched)} for arm in ['Evolution', 'DeepEvolution']]
    deep_curves = {}
    if deep_complete:
        for arm, initial, increment, generations in [('Evolution',24,22,20),('DeepEvolution',64,62,100)]:
            deep_curves[arm] = [[initial+increment*g, statistics.mean(1-value[arm]['FitnessHistory'][g]/8 for value in deep_complete)] for g in range(generations+1)]
    all_curves = {arm:[[((64+62*g) if arm=='DeepEvolution' else (24+22*g)), 1-total/(8*count)] for g,(count,total) in sorted(rows.items())] for arm,rows in curves.items()}
    agreements = {'Training fits': [], 'Other final programs': []}
    horizon = defaultdict(lambda: [0,0])
    selected_examples = []
    seen_programs = set()
    constant_successes = 0
    failure_examples = []
    for row in db.execute('''SELECT s.id,s.name,s.offset,s.terms_json,t.* FROM sequences s JOIN trials t ON s.selected_trial=t.job_id
                             ORDER BY t.training_exact DESC,t.test_exact DESC,t.nodes DESC,s.id'''):
        result = unpack(row['result_zlib'])
        validation = result['Validation']
        agreements['Training fits' if row['training_exact'] else 'Other final programs'].append(validation['PrimaryHeldOutMatches']/12)
        if row['training_exact']:
            for position, check in enumerate(validation['Checks'][8:], 1):
                horizon[position][0] += 1
                horizon[position][1] += int(check['Match'])
        if row['training_exact'] and row['test_exact']:
            import re
            constant_successes += int(bool(re.fullmatch(r'Function\[n,\d+\]',row['wl_code'] or '')))
            if len(selected_examples)<6 and row['program'] not in seen_programs:
                selected_examples.append({'ID':row['id'],'Name':row['name'],'Program':row['program'],'Nodes':row['nodes'],'WL':row['wl_code'],'Seed':row['seed'],
                                          'Offset':int(row['offset']),'Terms':json.loads(row['terms_json']), 'ExtendedCount':row['extended_count'],'ExtendedExact':bool(row['extended_exact'])})
                seen_programs.add(row['program'])
        elif row['training_exact'] and len(failure_examples)<4:
            failure_examples.append({'ID':row['id'],'Name':row['name'],'Program':row['program'],'WL':row['wl_code'],
                                     'TestMatches':validation['PrimaryHeldOutMatches'],'Checks':validation['Checks'][:20]})
    baseline_all = dict(db.execute('''SELECT count(*) AS sequences,sum(last_term_training*last_term_test) AS last_term_joint_fits,
                                     sum(affine_training*affine_test) AS affine_joint_fits,sum(constant_training) AS constant_training_prefixes FROM baselines''').fetchone())
    baseline_covered = dict(db.execute('''SELECT count(*) AS sequences,sum(b.last_term_training*b.last_term_test) AS last_term_joint_fits,
                                         sum(b.affine_training*b.affine_test) AS affine_joint_fits,sum(b.constant_training) AS constant_training_prefixes
                                         FROM baselines b JOIN sequences s ON s.id=b.id WHERE s.selected_trial IS NOT NULL''').fetchone())
    data = {'UpdatedUTC':utc(),'Summary':status,'Diagnostics':dict(diagnostics),'SearchExecutions':executed,'TrainingSearchReuses':reused,
            'ActualSearchSeconds':execution_seconds,'AllCurves':all_curves,'MatchedPairs':len(matched),'PairedArms':paired_summary,
            'PairedCurves':paired_curves,'PairedCurvePairs':len(matched_complete),'PairedContrasts':contrasts,'DeepPairs':len(deep_matched),'DeepCurvePairs':len(deep_complete),'DeepArms':deep_summary,'DeepCurves':deep_curves,
            'HeldOutAgreements':agreements,'TrainingFitHorizon':[[position,count,correct,correct/count] for position,(count,correct) in sorted(horizon.items())],
            'ConstantSelectedJointFits':constant_successes,'Examples':selected_examples,'TrainingFitFailures':failure_examples,
            'BaselinesFullCorpus':baseline_all,'BaselinesSameCoveredSequences':baseline_covered}
    atomic_json(ROOT/'analysis.json',data)
    with open(ROOT/'loss-curves.csv','w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['Comparison','Arm','CandidateProposals','MeanTrainingMismatch'])
        for label,group in [('AllAvailable',all_curves),('MatchedArms',paired_curves),('MatchedBudgetStudy',deep_curves)]:
            for arm,points in group.items():
                for proposals,loss in points: writer.writerow([label,arm,proposals,loss])
    lines=['# OEIS corpus experiment: current results','',f"Updated {data['UpdatedUTC']}.",'',
           'These are checkpoint results. Pending searches have not been counted as completed experiments.','',
           f"Primary pass: {status['PrimaryPass']['attempted']:,} of {status['EligibleSequences']:,} eligible sequences attempted; {status['PrimaryPass']['joint_fits'] or 0:,} matched all training and twelve primary held-out terms.",
           f"Across completed seeds, training-only selection produced {status['TrainingSelectedAcrossSeeds']['joint_fits'] or 0:,} joint fits. Of these, {constant_successes:,} have a constant compact WL function.",
           f"Extended terms are available for {status['TrainingSelectedAcrossSeeds']['with_extended_terms'] or 0:,} covered sequences; {status['TrainingSelectedAcrossSeeds']['extended_fits'] or 0:,} fit training and all recorded held-out terms.",'',
           '![Corpus coverage](figures/coverage.svg)','![Training and held-out fits](figures/fits.svg)','![Training loss](figures/loss.svg)','![Held-out agreement](figures/agreement.svg)','![Prediction horizon](figures/horizon.svg)','',
           'Histograms normalize within each group. The horizon curve gives exact agreement at each later position among training-fitting programs with a recorded term at that position. Its denominator can change with the available sequence lengths; it is not a cumulative survival curve.','',
           '## Mutation and search-budget comparisons','',
           f"Attempted matched sequence-seed pairs across all four arms: {len(matched):,}. Deep-budget pairs: {len(deep_matched):,}.",
           'Comparisons use the same sequences and seeds, with 464 proposed candidates in each standard arm. Random search samples depth-three programs. The deeper arm proposes 6,264 candidates. Resource failures count as unsuccessful outcomes. Loss curves use the separately counted pairs for which every arm completed.','',
           '| Arm | Matched pairs | Completed | Training fits | Training and test fits |','| --- | ---: | ---: | ---: | ---: |']
    for row in paired_summary: lines.append(f"| {row['Arm']} | {row['Pairs']:,} | {row['Completed']:,} | {row['TrainingFits']:,} | {row['JointFits']:,} |")
    if paired_curves: lines+=['','![Matched search arms](figures/ablations.svg)']
    if deep_curves: lines+=['','![Larger search budget](figures/budget.svg)']
    lines+=['','## Simple predictive baselines','',
            f"On the same {baseline_covered['sequences']:,} covered sequences, the constant-last-term rule fits training and test on {baseline_covered['last_term_joint_fits'] or 0:,}; the affine rule through the first two terms does so on {baseline_covered['affine_joint_fits'] or 0:,}.",
            f"Over all eligible records, those counts are {baseline_all['last_term_joint_fits']:,} and {baseline_all['affine_joint_fits']:,}. The full corpus has {baseline_all['constant_training_prefixes']:,} constant training prefixes.",'',
            '## Program illustrations','',
            'These examples were selected after evaluation for structural diversity. They illustrate successful outputs, not a representative sample. Compact WL was derived from each Recursor program and checked against its completed outputs.','']
    for index,example in enumerate(selected_examples,1):
        lines += [f"### {example['ID']}: {example['Name']}",'',f"Recursor: `{example['Program']}`.",'',f"WL: `{example['WL']}`.",'']
        if example['Nodes']>1:
            lines += [f"![Program tree for {example['ID']}](figures/program-{index:02d}.svg)",'']
    lines+=['## Interpretation and reproducibility','',
            'Training uses the first eight recorded terms at their original indices. The primary test is the next twelve; all remaining recorded terms are a separate extended test. Model selection never uses held-out terms.',
            'Identical indexed training prefixes share a completed search for the same seed and arm. Every sequence is validated on its own held-out terms and retains the source job of any reused search.',
            f"Actual search executions: {executed:,}; recorded search reuses: {reused:,}. Repeated prefixes and related sequences are not independent evidence.",
            'The compact WL field records the shortest verified candidate found among structural translation, safe simplification and recognized constructor patterns. Global minimality is not claimed.',
            'Finite agreement does not establish an infinite identity. Resource failures do not establish nontermination. Search limits constrain this experiment, not the language.',
            'The full records are in results.sqlite3; sequence-results.csv.gz includes every source record, its status, program, compact WL and terms. generalized.csv lists successful training-selected predictions. See protocol.json and code-manifest.json for source revisions and executable provenance.',
            'OEIS data: copyright OEIS Foundation Inc. and contributors; CC BY-SA 4.0.','']
    (ROOT/'report.md.tmp').write_text('\n'.join(lines));(ROOT/'report.md.tmp').replace(ROOT/'report.md')
    db.close()
    print(f"Analyzed {status['Jobs'].get('Done',0):,} completed jobs; {len(matched):,} matched arm comparisons.",flush=True)


if __name__=='__main__':
    collect()
