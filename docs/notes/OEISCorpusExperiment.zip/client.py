import json
import hashlib
import os
import queue
import subprocess
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
KERNEL = os.environ.get('RECURSOR_CORPUS_KERNEL','/Applications/Wolfram Latest.app/Contents/MacOS/WolframKernel')
PROFILE = os.environ.get('WOLFRAM_USERBASE',str(ROOT.parent/'release-qa'/'wolfram-userbase'))


def verify_code():
    manifest = ROOT/'code-manifest.json'
    if manifest.exists():
        for name,digest in json.loads(manifest.read_text())['Files'].items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
                raise RuntimeError('Frozen experiment file changed: '+name)


class Kernel:
    def __init__(self, name):
        verify_code()
        self.name = str(name)
        self.lines = queue.Queue()
        self.log = open(ROOT / ('kernel-' + self.name + '.log'), 'a', buffering=1)
        environment = dict(os.environ, WOLFRAM_USERBASE=PROFILE, OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
        self.process = subprocess.Popen([KERNEL, '-noprompt', '-script', str(ROOT / 'worker.wls')],
                                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.log,
                                        text=True, bufsize=1, env=environment, start_new_session=True)
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()
        self._receive('READY', 60)

    def _read(self):
        for line in self.process.stdout:
            self.lines.put(line.rstrip('\n'))
        self.lines.put(None)

    def _receive(self, prefix, timeout):
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Kernel response deadline exceeded')
            line = self.lines.get(timeout=remaining)
            if line is None:
                raise RuntimeError('Kernel exited with code ' + str(self.process.poll()))
            if line.startswith(prefix):
                return line[len(prefix):].strip()
            self.log.write(line + '\n')

    def request(self, request, timeout=160):
        self.process.stdin.write(json.dumps(request, separators=(',', ':')) + '\n')
        self.process.stdin.flush()
        return json.loads(self._receive('RESULT ', timeout))

    def close(self):
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=10)
        self.log.close()


if __name__ == '__main__':
    kernel = Kernel('smoke')
    try:
        square = kernel.request({'Operation': 'Search', 'Arm': 'Evolution', 'Seed': 9101, 'Examples': [[i, i*i] for i in range(8)]})
        print(json.dumps(square))
        checked = kernel.request({'Operation': 'Validate', 'Program': square['Program'], 'Examples': [[i, i*i] for i in range(20)]})
        print(json.dumps(checked))
        assert square['Status'] == checked['Status'] == 'Completed'
        assert checked['TrainingMatches'] == 8 and checked['PrimaryHeldOutMatches'] == 12
        assert checked['WL']['Status'] == 'VerifiedOnCompletedInputs'
    finally:
        kernel.close()
