import argparse
import csv
import fcntl
import gzip
import hashlib
import io
import json
import os
import signal
import sqlite3
import subprocess
import threading
import time
import traceback
import zlib
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from client import Kernel, ROOT, PROFILE, verify_code


def utc():
    return datetime.now(timezone.utc).isoformat()


def connect():
    connection = sqlite3.connect(str(ROOT / 'results.sqlite3'), timeout=60)
    connection.row_factory = sqlite3.Row
    connection.execute('PRAGMA busy_timeout=60000')
    return connection


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def compact(value):
    return zlib.compress(json.dumps(value, separators=(',', ':')).encode(), 3)


def unpack(value):
    return json.loads(zlib.decompress(value))


def claim(db, worker, calibration):
    db.execute('BEGIN IMMEDIATE')
    query = "SELECT * FROM jobs WHERE status='Pending'"
    if calibration:
        query += ' AND phase=0'
    row = db.execute(query + ' ORDER BY phase,sort_key,job_id LIMIT 1').fetchone()
    if row is not None:
        db.execute("UPDATE jobs SET status='Running',worker=?,attempts=attempts+1,started_utc=? WHERE job_id=?", (worker, utc(), row['job_id']))
    db.commit()
    return row


def check_validation(validation, examples):
    assert validation['Status'] == 'Completed'
    assert len(validation['Checks']) == len(examples)
    for row, example in zip(validation['Checks'], examples):
        assert [row['Input'], row['Expected']] == example
        if isinstance(row['Value'], str):
            assert row['Match'] == (int(row['Value']) == example[1])
        elif row['Value'] is None:
            assert not row['Match']
    assert validation['TrainingMatches'] == sum(row['Match'] for row in validation['Checks'][:8])
    assert validation['PrimaryHeldOutMatches'] == sum(row['Match'] for row in validation['Checks'][8:20])
    assert validation['ExtendedHeldOutMatches'] == sum(row['Match'] for row in validation['Checks'][20:])


def save(db, job, result, final):
    search = result['Search']
    validation = result.get('Validation', {})
    validated = validation.get('Status') == 'Completed'
    trained = int(validated and validation['TrainingMatches'] == 8)
    tested = int(validated and validation['PrimaryHeldOutMatches'] == 12)
    extended_count = validation.get('ExtendedHeldOutCount', 0)
    extended = int(validated and extended_count > 0 and validation['ExtendedHeldOutMatches'] == extended_count)
    wl = validation.get('WL', {})
    status = ('Completed' if validated else validation.get('Status', search['Status'])) if final else 'AwaitingValidation'
    db.execute('BEGIN IMMEDIATE')
    db.execute('''INSERT OR REPLACE INTO trials(job_id,id,seed,arm,status,program,nodes,fitness,training_exact,test_exact,extended_exact,wl_code,wl_status,seconds,result_zlib,extended_count)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
               (job['job_id'], job['id'], job['seed'], job['arm'], status, search.get('Program'), search.get('Nodes'),
                validation.get('TrainingMatches', search.get('Fitness')), trained, tested, extended, wl.get('Code'), wl.get('Status'),
                result.get('ActualSearchSeconds', search.get('Seconds')), compact(result), extended_count))
    if final:
        db.execute("UPDATE jobs SET status='Done',finished_utc=? WHERE job_id=?", (utc(), job['job_id']))
        if job['arm'] == 'Evolution':
            if job['seed'] == 9101:
                db.execute('UPDATE sequences SET primary_trial=? WHERE id=?', (job['job_id'], job['id']))
            if validated:
                previous = db.execute('SELECT t.fitness,t.nodes,t.seed FROM sequences s JOIN trials t ON s.selected_trial=t.job_id WHERE s.id=?', (job['id'],)).fetchone()
                rank = (validation['TrainingMatches'], -search['Nodes'], -job['seed'])
                if previous is None or rank > (previous['fitness'], -previous['nodes'], -previous['seed']):
                    db.execute('UPDATE sequences SET selected_trial=? WHERE id=?', (job['job_id'], job['id']))
    db.commit()


def worker_loop(number, stop, deadline, calibration, workers):
    db = connect()
    kernel = None
    uses = 0
    consecutive_failures = 0
    try:
        while not stop.is_set() and time.time() < deadline and not (ROOT / 'STOP').exists():
            job = claim(db, number, calibration)
            if job is None:
                break
            start = time.monotonic()
            started_utc = utc()
            try:
                if kernel is None or uses >= 512:
                    if kernel is not None:
                        kernel.close()
                    kernel = Kernel(number)
                    uses = 0
                sequence = db.execute('SELECT offset,terms_json FROM sequences WHERE id=?', (job['id'],)).fetchone()
                terms = json.loads(sequence['terms_json'])
                offset = int(sequence['offset'])
                examples = [[offset + i, term] for i, term in enumerate(terms)]
                prior = db.execute("SELECT result_zlib FROM trials WHERE job_id=? AND status='AwaitingValidation'", (job['job_id'],)).fetchone()
                if prior is not None:
                    result = unpack(prior['result_zlib'])
                    search = result['Search']
                else:
                    training_key = hashlib.sha256(json.dumps(examples[:8], separators=(',', ':')).encode()).hexdigest()
                    cached = db.execute('SELECT source_job,search_zlib FROM search_cache WHERE training_key=? AND seed=? AND arm=?', (training_key,job['seed'],job['arm'])).fetchone()
                    if cached is None:
                        search = kernel.request({'Operation': 'Search', 'Arm': job['arm'], 'Seed': job['seed'], 'Examples': examples[:8]}, timeout=205 if job['arm']=='DeepEvolution' else 55)
                    else:
                        search = unpack(cached['search_zlib'])
                    result = {'ID': job['id'], 'Seed': job['seed'], 'Arm': job['arm'], 'StartedUTC': started_utc,
                              'TrainingKey': training_key, 'ActualSearchExecuted': cached is None,
                              'ActualSearchSeconds': search.get('Seconds',0) if cached is None else 0,
                              'ExecutionWorkers': workers, 'ExecutionMode': 'Calibration' if calibration else 'Corpus',
                              'SearchSourceJob': job['job_id'] if cached is None else cached['source_job'], 'Search': search}
                    if search['Status'] == 'Completed':
                        expected = 6264 if job['arm'] == 'DeepEvolution' else 464
                        assert search['CandidateProposals'] == expected
                        assert len(search['FitnessHistory']) == (101 if job['arm'] == 'DeepEvolution' else 21)
                        assert search['Nodes'] <= 60
                        if cached is None:
                            db.execute('INSERT OR IGNORE INTO search_cache VALUES(?,?,?,?,?)', (training_key,job['seed'],job['arm'],job['job_id'],compact(search)))
                            db.commit()
                        save(db, job, result, False)
                if search['Status'] == 'Completed':
                    validation = kernel.request({'Operation': 'Validate', 'Program': search['Program'], 'Examples': examples}, timeout=150)
                    if validation['Status'] == 'Completed':
                        check_validation(validation, examples)
                        assert validation['WL'].get('Mismatches', 0) == 0
                        validation['TrainingFitnessRechecked'] = validation['TrainingMatches'] == search['Fitness']
                    result['Validation'] = validation
                result['FinishedUTC'] = utc()
                result['TotalSeconds'] = time.monotonic() - start
                save(db, job, result, True)
                uses += 1
                consecutive_failures = 0
            except Exception:
                with open(ROOT / ('worker-' + str(number) + '-errors.log'), 'a') as log:
                    log.write(utc() + ' ' + job['id'] + ' ' + job['arm'] + '\n' + traceback.format_exc() + '\n')
                db.rollback()
                if kernel is not None:
                    kernel.close()
                    kernel = None
                attempts = db.execute('SELECT attempts FROM jobs WHERE job_id=?', (job['job_id'],)).fetchone()[0]
                if attempts < 3:
                    db.execute("UPDATE jobs SET status='Pending',worker=NULL WHERE job_id=?", (job['job_id'],))
                    db.commit()
                else:
                    result = {'ID': job['id'], 'Seed': job['seed'], 'Arm': job['arm'], 'Search': {'Status': 'WorkerFailure'}, 'FinishedUTC': utc()}
                    save(db, job, result, True)
                    consecutive_failures += 1
                    if consecutive_failures >= 3:
                        stop.set()
    finally:
        if kernel is not None:
            kernel.close()
        db.close()


def summary(state=None, database=None):
    db = database if database is not None else connect()
    if database is None:
        db.execute('BEGIN')
    counts = dict(db.execute('SELECT status,count(*) FROM jobs GROUP BY status').fetchall())
    arms = []
    for row in db.execute('''SELECT arm,count(*) AS trials,sum(status='Completed') AS completed,
                             sum(training_exact) AS training_fits,sum(training_exact*test_exact) AS joint_fits,
                             sum(training_exact*test_exact*extended_exact) AS extended_fits,
                             sum(seconds) AS search_seconds FROM trials WHERE status!='AwaitingValidation' GROUP BY arm'''):
        arms.append(dict(row))
    selected = dict(db.execute('''SELECT count(*) AS sequences,sum(t.training_exact) AS training_fits,
                                 sum(t.training_exact*t.test_exact) AS joint_fits,
                                 sum(t.training_exact*t.test_exact*t.extended_exact) AS extended_fits,
                                 sum(t.extended_count>0) AS with_extended_terms
                                 FROM sequences s JOIN trials t ON t.job_id=s.selected_trial''').fetchone())
    primary = dict(db.execute('''SELECT count(*) AS attempted,sum(t.status='Completed') AS completed,
                                sum(t.training_exact) AS training_fits,sum(t.training_exact*t.test_exact) AS joint_fits
                                FROM sequences s JOIN trials t ON t.job_id=s.primary_trial''').fetchone())
    any_success = db.execute("SELECT count(DISTINCT id) FROM trials WHERE arm='Evolution' AND training_exact=1 AND test_exact=1").fetchone()[0]
    excluded = dict(db.execute('SELECT exclusion,count(*) FROM sequences WHERE eligible=0 GROUP BY exclusion').fetchall())
    protocol = json.loads(db.execute("SELECT value_json FROM metadata WHERE key='Protocol'").fetchone()[0])
    result = {'UpdatedUTC': utc(), 'State': state or 'Snapshot', 'TotalSequences': protocol['SequenceCount'],
              'EligibleSequences': protocol['EligibleCount'], 'Excluded': excluded, 'Jobs': counts, 'Arms': arms,
              'PrimaryPass': primary, 'TrainingSelectedAcrossSeeds': selected, 'AnySeedFitsTrainingAndTest': any_success}
    if (ROOT / 'run-state.json').exists():
        result['Run'] = json.loads((ROOT / 'run-state.json').read_text())
        if state is None:
            result['State'] = result['Run'].get('State', 'Snapshot')
        elapsed = max(time.time() - result['Run']['StartedUnix'], 0.001)
        new_done = counts.get('Done', 0) - result['Run'].get('InitialDone', 0)
        result['CurrentSessionJobsPerHour'] = new_done * 3600 / elapsed
        if new_done:
            result['EstimatedHoursForRemainingJobsAtObservedRate'] = (counts.get('Pending', 0) + counts.get('Running', 0)) * elapsed / new_done / 3600
    atomic_json(ROOT / 'summary.json', result)
    lines = ['# Recursor OEIS corpus experiment', '', f"Updated: {result['UpdatedUTC']}. State: {result['State']}.", '',
             f"The frozen snapshot has {result['TotalSequences']:,} records; {result['EligibleSequences']:,} meet the documented criteria.",
             f"Jobs completed: {counts.get('Done', 0):,}; running: {counts.get('Running', 0):,}; pending: {counts.get('Pending', 0):,}.", '',
             '## Primary pass', '',
             f"Sequences attempted: {primary['attempted']:,}. Completed searches and validation: {primary['completed'] or 0:,}.",
             f"Complete training fits: {primary['training_fits'] or 0:,}. Fits extending across all 12 primary held-out terms: {primary['joint_fits'] or 0:,}.", '',
             '## Selection across seeds', '',
             'The main selected program uses training accuracy, then smaller syntax size, then the lowest seed. Held-out terms never select it.',
             f"Sequences with a validated selected program: {selected['sequences']:,}; fitting training and primary test: {selected['joint_fits'] or 0:,}.",
             f"Sequences with at least one successful seed: {any_success:,}. This is a separate, best-of-runs coverage statistic.", '',
             '## Experimental arms', '', '| Arm | Completed trials | Training fits | Training and test fits |', '| --- | ---: | ---: | ---: |']
    for arm in arms:
        lines.append(f"| {arm['arm']} | {arm['completed'] or 0:,} | {arm['training_fits'] or 0:,} | {arm['joint_fits'] or 0:,} |")
    lines += ['', 'Arm counts can cover different numbers of sequences while the experiment runs. Paired comparisons require the same sequence and seed in every arm.', '',
              '## Records', '', '`results.sqlite3` stores all sequence records, exclusions, job states, programs, compact WL functions, loss curves and per-term checks.',
              '`protocol.json` freezes the data revision, search parameters, seeds, cohorts and selection rules.',
              'CSV exports, analysis figures and detailed reports are produced at checkpoints and at the end of the run.', '',
              '“Compact WL” means the shortest verified equivalent found by the recorded transformations. Global minimality is not claimed.',
              'Finite held-out agreement is an empirical prediction test; it is not a proof of an infinite sequence identity.',
              'OEIS data are copyright the OEIS Foundation and contributors, under CC BY-SA 4.0.', '']
    (ROOT / 'progress.md.tmp').write_text('\n'.join(lines))
    (ROOT / 'progress.md.tmp').replace(ROOT / 'progress.md')
    if database is None:
        db.close()
    return result


def analyze_and_render():
    with open(ROOT / 'analysis.log', 'a', buffering=1) as log:
        analyzed = subprocess.run(['/usr/bin/python3', str(ROOT / 'analyze.py')], stdout=log, stderr=log)
        if analyzed.returncode != 0:
            return
        environment = dict(os.environ, WOLFRAM_USERBASE=PROFILE)
        try:
            subprocess.run(['/usr/local/bin/wolframscript', '-file', str(ROOT / 'render.wls')], stdout=log, stderr=log, env=environment, timeout=600)
        except subprocess.TimeoutExpired:
            log.write(utc() + ' Figure rendering exceeded its time budget. Raw records remain available.\n')


def export_results():
    db = connect()
    db.execute('BEGIN')
    temporary = ROOT / 'sequence-results.csv.gz.tmp'
    with gzip.open(temporary, 'wt', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['OEIS_ID', 'Name', 'Offset', 'Eligible', 'Exclusion', 'Status', 'Seed', 'RecursorProgram', 'Nodes', 'CompactWL', 'WLVerification', 'TrainingMatches', 'TrainingExact', 'PrimaryHeldOutExact', 'ExtendedHeldOutCount', 'ExtendedHeldOutExact', 'SequenceTerms', 'OEISWolframCode_UnexecutedReference', 'SourceSHA256'])
        query = '''SELECT s.*,t.status,t.seed,t.program,t.nodes,t.wl_code,t.wl_status,t.fitness,t.training_exact,t.test_exact,t.extended_count,t.extended_exact
                   FROM sequences s LEFT JOIN trials t ON t.job_id=coalesce(s.selected_trial,s.primary_trial) ORDER BY s.id'''
        for row in db.execute(query):
            writer.writerow([row['id'], row['name'], row['offset'], row['eligible'], row['exclusion'], row['status'] or ('Pending' if row['eligible'] else 'Excluded'),
                             row['seed'], row['program'], row['nodes'], row['wl_code'], row['wl_status'], row['fitness'], row['training_exact'], row['test_exact'],
                             row['extended_count'], row['extended_exact'], row['terms_json'], row['source_wl_json'], row['source_sha256']])
    temporary.replace(ROOT / 'sequence-results.csv.gz')
    temporary = ROOT / 'generalized.csv.tmp'
    with open(temporary, 'w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['OEIS_ID', 'Name', 'Offset', 'Seed', 'RecursorProgram', 'CompactWL', 'WLVerification', 'ExtendedHeldOutCount', 'ExtendedHeldOutExact', 'SequenceTerms'])
        for row in db.execute('''SELECT s.*,t.seed,t.program,t.wl_code,t.wl_status,t.extended_count,t.extended_exact FROM sequences s JOIN trials t ON t.job_id=s.selected_trial
                                 WHERE t.training_exact=1 AND t.test_exact=1 ORDER BY s.id'''):
            writer.writerow([row['id'], row['name'], row['offset'], row['seed'], row['program'], row['wl_code'], row['wl_status'], row['extended_count'], row['extended_exact'], row['terms_json']])
    temporary.replace(ROOT / 'generalized.csv')
    db.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['run', 'calibrate', 'status', 'export'])
    parser.add_argument('--hours', type=float, default=24)
    parser.add_argument('--workers', type=int, default=10)
    args = parser.parse_args()
    if args.command == 'status':
        print(json.dumps(summary(), indent=2))
        return
    if args.command == 'export':
        export_results()
        return
    verify_code()
    lock = open(ROOT / 'run.lock', 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('An experiment manager is already running.')
    if (ROOT / 'STOP').exists():
        raise SystemExit('STOP exists. Remove it before explicitly resuming the experiment.')
    db = connect()
    db.execute("UPDATE jobs SET status='Pending',worker=NULL WHERE status='Running'")
    db.commit()
    initial_done = db.execute("SELECT count(*) FROM jobs WHERE status='Done'").fetchone()[0]
    db.close()
    started = time.time()
    deadline = started + args.hours * 3600
    run_state = {'StartedUTC': utc(), 'StartedUnix': started, 'DeadlineUnix': deadline,
                 'Workers': args.workers, 'PID': os.getpid(), 'Mode': args.command, 'InitialDone': initial_done, 'State': 'Running'}
    atomic_json(ROOT / 'run-state.json', run_state)
    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    threads = [threading.Thread(target=worker_loop, args=(number, stop, deadline, args.command == 'calibrate', args.workers)) for number in range(args.workers)]
    for thread in threads:
        thread.start()
    last_summary = 0
    last_export = time.time()
    try:
        while any(thread.is_alive() for thread in threads):
            now = time.time()
            if now - last_summary >= 60:
                current = summary('Running')
                print(utc(), json.dumps(current['Jobs']), 'primary:', current['PrimaryPass'], flush=True)
                last_summary = now
            if now - last_export >= 3600:
                export_results()
                analyze_and_render()
                last_export = now
            if now >= deadline or (ROOT / 'STOP').exists():
                stop.set()
            time.sleep(2)
    finally:
        stop.set()
        for thread in threads:
            thread.join()
        remaining_db = connect()
        remaining = remaining_db.execute("SELECT count(*) FROM jobs WHERE status!='Done'" + (' AND phase=0' if args.command == 'calibrate' else '')).fetchone()[0]
        remaining_db.close()
        state = ('CalibrationComplete' if args.command == 'calibrate' else 'Completed') if remaining == 0 else ('CheckpointedAtLimit' if time.time() >= deadline or (ROOT / 'STOP').exists() else 'Interrupted')
        atomic_json(ROOT / 'run-state.json', dict(run_state, State=state, FinishedUTC=utc()))
        final = summary(state)
        export_results()
        analyze_and_render()
        print(utc(), state, json.dumps(final['Jobs']), flush=True)
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()


if __name__ == '__main__':
    main()
