import hashlib
import json
import os
import re
import sqlite3
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
oeis = Path(os.environ.get('RECURSOR_OEIS_PATH',str(root.parents[3]/'Mathematics'/'OEIS')))
expected_data = '69c667df437a093151042e2cbec1f1198e70765a'
assert subprocess.check_output(['git', '-C', str(oeis / 'oeisdata'), 'rev-parse', 'HEAD'], text=True).strip() == expected_data
database = root / 'results.sqlite3'
if database.exists():
    raise SystemExit('The database already exists; preparation will not overwrite it.')
db = sqlite3.connect(str(database))
db.execute('PRAGMA journal_mode=WAL')
db.executescript('''
CREATE TABLE sequences (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, offset TEXT NOT NULL,
 terms_json TEXT NOT NULL, keywords_json TEXT NOT NULL, source_wl_json TEXT NOT NULL,
 source_sha256 TEXT NOT NULL, eligible INTEGER NOT NULL, exclusion TEXT,
 sample_order TEXT NOT NULL, role TEXT NOT NULL,
 selected_trial INTEGER, primary_trial INTEGER
);
CREATE INDEX eligibility ON sequences(eligible, sample_order);
CREATE TABLE jobs (
 job_id INTEGER PRIMARY KEY, id TEXT NOT NULL, seed INTEGER NOT NULL,
 arm TEXT NOT NULL, phase INTEGER NOT NULL, sort_key TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending', attempts INTEGER NOT NULL DEFAULT 0,
 worker INTEGER, started_utc TEXT, finished_utc TEXT,
 UNIQUE(id, seed, arm)
);
CREATE INDEX pending_jobs ON jobs(status, phase, sort_key);
CREATE TABLE trials (
 job_id INTEGER PRIMARY KEY, id TEXT NOT NULL, seed INTEGER NOT NULL, arm TEXT NOT NULL,
 status TEXT NOT NULL, program TEXT, nodes INTEGER, fitness INTEGER,
 training_exact INTEGER NOT NULL DEFAULT 0, test_exact INTEGER NOT NULL DEFAULT 0,
 extended_exact INTEGER NOT NULL DEFAULT 0, wl_code TEXT, wl_status TEXT,
 seconds REAL, result_zlib BLOB NOT NULL, extended_count INTEGER DEFAULT 0
);
CREATE INDEX trial_sequences ON trials(id, arm, seed);
CREATE TABLE metadata (key TEXT PRIMARY KEY, value_json TEXT NOT NULL);
CREATE TABLE search_cache (training_key TEXT, seed INTEGER, arm TEXT, source_job INTEGER, search_zlib BLOB, PRIMARY KEY(training_key,seed,arm));
CREATE TABLE baselines (id TEXT PRIMARY KEY, training_key TEXT, constant_training INTEGER, last_term_training INTEGER, last_term_test INTEGER, affine_training INTEGER, affine_test INTEGER);
CREATE INDEX baseline_training_key ON baselines(training_key);
''')
controls = {'A001477', 'A000290', 'A000217', 'A000079', 'A000045', 'A000120', 'A000142', 'A000578'}
pilot_path = root / 'pilot-cohort.json'
if not pilot_path.exists():
    pilot_path = root.parent / 'oeis-benchmark' / 'cohort.json'
pilot = json.loads(pilot_path.read_text())
pilot_ids = {row['ID'] for row in pilot['Sequences']}
counts = Counter()
eligible_ids = []
digest = hashlib.sha256()
pattern = re.compile(r'^%([A-Za-z])\s+(A\d{6})(?:\s+(.*))?$')
integer = re.compile(r'-?\d+')
for count, path in enumerate(sorted((oeis / 'oeisdata' / 'seq').glob('*/*.seq')), 1):
    content = path.read_bytes()
    fields = {}
    identifier = path.stem
    for line in content.decode('utf-8').splitlines():
        match = pattern.fullmatch(line)
        if match:
            tag, line_id, value = match.groups()
            assert identifier == line_id
            fields.setdefault(tag, []).append((value or '').strip())
    raw_terms = [token.strip() for tag in 'STU' for part in fields.get(tag, []) for token in part.split(',') if token.strip()]
    raw_offset = [token.strip() for part in fields.get('O', []) for token in part.split(',') if token.strip()]
    assert all(integer.fullmatch(token) for token in raw_terms + raw_offset) and raw_offset, identifier
    terms = list(map(int, raw_terms))
    offset = int(raw_offset[0])
    keywords = [token.strip() for part in fields.get('K', []) for token in part.split(',') if token.strip()]
    reason = ('No nonn keyword' if 'nonn' not in keywords else
              'Negative offset' if offset < 0 else
              'Fewer than 20 terms' if len(terms) < 20 else
              'Negative recorded terms' if any(term < 0 for term in terms) else
              'Dead or full entry' if {'dead', 'full'} & set(keywords) else None)
    counts[reason or 'Eligible'] += 1
    sort_key = hashlib.sha256(('Recursor-OEIS-corpus-v1:' + identifier).encode()).hexdigest()
    source_hash = hashlib.sha256(content).hexdigest()
    relative = path.relative_to(oeis / 'oeisdata').as_posix()
    digest.update(relative.encode() + b'\0' + source_hash.encode() + b'\n')
    role = 'Control' if identifier in controls else ('Pilot' if identifier in pilot_ids else 'Corpus')
    db.execute('INSERT INTO sequences(id,name,offset,terms_json,keywords_json,source_wl_json,source_sha256,eligible,exclusion,sample_order,role) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
               (identifier, ' '.join(fields.get('N', [])), str(offset), json.dumps(terms, separators=(',', ':')),
                json.dumps(keywords), json.dumps(fields.get('t', [])), source_hash, int(reason is None), reason, sort_key, role))
    if reason is None:
        eligible_ids.append((sort_key, identifier))
        examples = [[offset+i, term] for i, term in enumerate(terms[:8])]
        key = hashlib.sha256(json.dumps(examples, separators=(',', ':')).encode()).hexdigest()
        constant = len(set(terms[:8])) == 1
        difference = terms[1] - terms[0]
        db.execute('INSERT INTO baselines VALUES(?,?,?,?,?,?,?)', (identifier,key,int(constant),int(constant),int(all(term==terms[7] for term in terms[8:20])),int(all(term==terms[0]+i*difference for i,term in enumerate(terms[:8]))),int(all(term==terms[0]+i*difference for i,term in enumerate(terms[:20]) if i>=8))))
    if count % 50000 == 0:
        db.commit()
        print(f'Indexed {count:,} records', flush=True)
db.commit()
audit_path = root / 'snapshot.json'
if not audit_path.exists():
    audit_path = oeis / 'build' / 'recursor' / 'snapshot.json'
audit = json.loads(audit_path.read_text())
assert count == audit['SequenceFiles'] == 393450
assert digest.hexdigest() == audit['InventorySHA256']
assert len(eligible_ids) == 283167
eligible_ids.sort()
ablation_ids = [identifier for _, identifier in eligible_ids if identifier not in pilot_ids][:2048]
calibration_ids = [identifier for _, identifier in sorted(eligible_ids, key=lambda row: hashlib.sha256(('Recursor-OEIS-corpus-v1-timing:' + row[1]).encode()).digest())[:256]]
calibration_ids = sorted(set(calibration_ids) | controls)
options = {'PopulationSize': 24, 'MaxGenerations': 20, 'EliteCount': 2,
           'TournamentSize': 3, 'CrossoverRate': 0.8, 'MutationRate': 0.3,
           'InitialDepth': 2, 'MutationDepth': 3, 'MaxNodes': 60,
           'MaxConstant': 3, 'IncludeWhile': True, 'MaxSteps': 2000,
           'TimeLimit': 1, 'MemoryLimit': 67108864, 'StopOnSolve': False}
protocol = {
    'Study': 'Recursor OEIS corpus v1', 'CreatedUTC': datetime.now(timezone.utc).isoformat(),
    'RecursorRevision': 'e7786c8b9200a308e495a91e6bb66000d0fa0462',
    'OEISRevision': 'd82309e7f1436b641490aa8abf426c39e0d158a7', 'DataRevision': expected_data,
    'InventorySHA256': digest.hexdigest(), 'SequenceCount': count, 'EligibleCount': len(eligible_ids),
    'Eligibility': audit['Eligibility'], 'ExclusionCounts': dict(counts),
    'TrainingTerms': 8, 'PrimaryHeldOutTerms': 12,
    'ExtendedHeldOutTerms': 'All remaining recorded terms, reported separately.',
    'Seeds': [9101, 9102, 9103], 'SearchOptions': options,
    'TrialTimeLimitSeconds': 30, 'TrialMemoryLimitBytes': 536870912,
    'DeepTrialTimeLimitSeconds': 180,
    'ValidationTimeLimitSeconds': 120, 'Workers': 10, 'MaximumWallHours': 24,
    'CandidateProposalsPerTrial': 464,
    'MainArm': 'Evolution',
    'Ablations': {
        'NoMutation': {'MutationRate': 0},
        'NoCrossover': {'CrossoverRate': 0},
        'RandomSearch': {'Candidates': 464, 'Depth': 3}
    },
    'AblationIDs': ablation_ids, 'CalibrationIDs': calibration_ids,
    'DeepSearchOptions': {'PopulationSize': 64, 'MaxGenerations': 100, 'InitialDepth': 3, 'MutationDepth': 4},
    'DeepSearchIDs': ablation_ids[:1024], 'DeepCandidateProposalsPerTrial': 6264,
    'Selection': 'Within a run: public EvolveRecursor training fitness and size. Across seeds: maximum independently checked training matches, then minimum nodes, then lowest seed. Held-out terms never select programs.',
    'Scheduling': 'Timing jobs, every eligible sequence at seed 9101, seed-9101 ablations and a fixed 1024-sequence deeper-search arm, entire-corpus seeds 9102 and 9103, remaining ablations. Deadline stops dispatch and preserves pending jobs.',
    'WLCode': 'Standalone structural translation and safe simplification; shortest verified candidate found. No claim of global minimality. OEIS source code is retained as unexecuted reference text and never supplied to search.',
    'FailurePolicy': 'Resource exhaustion is recorded separately and contributes no exact match. It never establishes nontermination.',
    'DataLicense': 'CC BY-SA 4.0', 'DataCopyright': 'OEIS Foundation Inc. and its contributors',
    'TrainingReuse': 'Identical indexed training examples, seed and arm share one completed search. Each sequence retains its own held-out validation. Every reuse identifies its source job; repeated training prefixes are not independent evidence.',
    'Baselines': 'Last training term and the affine rule through the first two terms, checked against the same training and primary test windows for every eligible sequence.',
}
if (root / 'protocol.json').exists():
    frozen = json.loads((root / 'protocol.json').read_text())
    for key in ['DataRevision', 'InventorySHA256', 'SequenceCount', 'EligibleCount',
                'SearchOptions', 'AblationIDs', 'CalibrationIDs', 'DeepSearchIDs', 'Seeds']:
        assert frozen[key] == protocol[key], 'Frozen protocol mismatch: ' + key
    protocol = frozen
calibration_set = set(calibration_ids)
for seed, phase in [(9101, 1), (9102, 3), (9103, 4)]:
    db.executemany('INSERT INTO jobs(id,seed,arm,phase,sort_key) VALUES(?,?,?,?,?)',
                   [(identifier, seed, 'Evolution', 0 if seed == 9101 and identifier in calibration_set else phase, key)
                    for key, identifier in eligible_ids])
    db.commit()
sort_keys = {identifier: key for key, identifier in eligible_ids}
for identifier in protocol['DeepSearchIDs']:
    db.execute('INSERT INTO jobs(id,seed,arm,phase,sort_key) VALUES(?,?,?,?,?)',
               (identifier, 9101, 'DeepEvolution', 2, sort_keys[identifier]))
for seed in protocol['Seeds']:
    for arm in protocol['Ablations']:
        db.executemany('INSERT INTO jobs(id,seed,arm,phase,sort_key) VALUES(?,?,?,?,?)',
                       [(identifier, seed, arm, 2 if seed == 9101 else 5, sort_keys[identifier]) for identifier in ablation_ids])
db.execute('INSERT INTO metadata VALUES(?,?)', ('Protocol', json.dumps(protocol)))
db.commit()
db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
jobs = db.execute('SELECT COUNT(*) FROM jobs').fetchone()[0]
db.close()
(root / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
print(f'Prepared {count:,} records, {len(eligible_ids):,} eligible sequences, {jobs:,} search jobs.', flush=True)
