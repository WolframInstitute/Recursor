# Synthesizing sequence programs

A working notebook for SynthesizeRecursor and TranslateRecursor. Evaluate the Setup section first; every other section can then be run and changed on its own.

## Setup

Load the paclet from this checkout.

```code
PacletDirectoryLoad[FileNameJoin[{ParentDirectory[NotebookDirectory[]], "Recursor"}]];

Needs["WolframInstitute`Recursor`"]
```

The recorded terms of an OEIS sequence, as {index, value} pairs, from the local corpus file.

```code
corpus = FileNameJoin[{ParentDirectory[NotebookDirectory[]], "build", "oeis-corpus-v2", "data", "sequences.tsv"}];

oeis[id_String] := With[{line = ReadList["!grep -m1 '^" <> id <> "[[:space:]]' '" <> corpus <> "'", String]},
	If[line === {}, Missing["NotInCorpus", id],
		With[{fields = StringSplit[First[line], "\t"]},
			With[{terms = FromDigits /@ StringSplit[fields[[3]], ","]},
				Transpose[{FromDigits[fields[[2]]] + Range[0, Length[terms] - 1], terms}]
			]
		]
	]
]
```

One experiment: synthesize from the first terms and check the program on the terms after them.

```code
study[examples_List, given_Integer, options___] := Module[{shown, later, seconds, result},
	{shown, later} = TakeDrop[examples, UpTo[given]];
	later = Take[later, UpTo[40]];
	{seconds, result} = AbsoluteTiming[SynthesizeRecursor[shown, options]];
	Join[result, <|
		"Seconds" -> N[Round[seconds, 1/10]],
		"LaterChecked" -> Length[later],
		"LaterMatched" -> If[MissingQ[result["Program"]], 0,
			LengthWhile[later, EvaluateRecursor[result["Program"], First[#], "MaxSteps" -> 5000000, "TimeLimit" -> 20] === Last[#] &]]
	|>]
]

summary[result_Association] := KeyTake[result, {"Solved", "Method", "Nodes", "Evidence", "HeldOutMatches", "HeldOutExamples", "LaterMatched", "LaterChecked", "Seconds"}]
```

Recorded terms against the values of the program. The lines end the terms the search saw and the terms it was tested on.

```code
predictionPlot[examples_List, result_Association, count_Integer : 40] := Module[{shown = Take[examples, UpTo[count]], values, ends},
	values = {First[#], EvaluateRecursor[result["Program"], First[#], "MaxSteps" -> 5000000, "TimeLimit" -> 20]} & /@ shown;
	ends = examples[[{result["TrainingExamples"], result["TrainingExamples"] + result["HeldOutExamples"]}, 1]] + 1/2;
	If[Min[shown[[All, 2]]] > 0 && Max[shown[[All, 2]]] > 200 Median[shown[[All, 2]]], ListLogPlot, ListPlot][
		{shown, Select[values, IntegerQ[Last[#]] &]},
		Joined -> {True, False}, PlotMarkers -> {{"\[FilledCircle]", 7}, {"\[EmptySquare]", 13}}, PlotLegends -> {"Recorded", "Program"},
		Frame -> True, FrameLabel -> {"Index", "Value"}, GridLines -> {ends, None}, PlotRange -> All]
]
```

## One sequence

Take thirty terms of a sequence. Change the identifier, or give your own pairs.

```wl
examples = Take[oeis["A000040"], 30]
```

Search. Twenty-three terms go to the search and seven test the program it finds.

```wl
result = SynthesizeRecursor[examples]
```

```wl
RecursorProgramTree[result["Program"]]
```

The program as a Wolfram Language function, tested on the same inputs.

```wl
TranslateRecursor[result["Program"], "TestInputs" -> examples[[All, 1]]]
```

```wl
predictionPlot[oeis["A000040"], result]
```

## Twelve sequences

Each sequence gets its first thirty recorded terms, or all of them if it has fewer. LaterMatched counts the recorded terms after those that the program reproduces.

```code
twelve = <|"A000040" -> "Prime numbers", "A000108" -> "Catalan numbers", "A000166" -> "Derangements", "A000120" -> "Binary weight",
	"A000123" -> "Binary partitions", "A018252" -> "Nonprime numbers", "A000272" -> "Labeled trees", "A000005" -> "Number of divisors",
	"A002808" -> "Composite numbers", "A001006" -> "Motzkin numbers", "A005258" -> "Apéry numbers", "A001181" -> "Baxter permutations"|>;
```

```wl
studies = AssociationMap[study[oeis[#], 30] &, Keys[twelve]];
Dataset[KeyMap[twelve[#] <> " (" <> # <> ")" &, summary /@ studies]]
```

The programs as Wolfram Language functions.

```wl
Column[KeyValueMap[Row[{twelve[#1], ":  ", TranslateRecursor[#2["Program"], "TestInputs" -> Take[oeis[#1], UpTo[24]][[All, 1]]]}] &, studies], Spacings -> 1]
```

Two of the programs.

```wl
RecursorProgramTree[studies["A000166"]["Program"]]
```

```wl
RecursorProgramTree[studies["A002808"]["Program"]]
```

## How many terms are enough

Evidence grows with the number of terms. Solved needs 24 bits and at least four held-out terms, all reproduced.

```wl
ListLinePlot[Table[{k, SynthesizeRecursor[Take[oeis["A000120"], k]]["Evidence"]}, {k, 12, 60, 6}], GridLines -> {None, {24}}, PlotMarkers -> Automatic, Frame -> True, FrameLabel -> {"Terms given", "Evidence in bits"}]
```

Eight terms give the right program for the Catalan numbers, but not the evidence.

```wl
summary[study[oeis["A000108"], #]] & /@ <|"8 terms" -> 8, "16 terms" -> 16|> // Dataset
```

## A random sample of the corpus

Forty random sequences, twenty terms each, on parallel kernels. Change the seed or the size.

```code
identifiers = StringTake[ReadList[corpus, String], 7];

LaunchKernels[];

ParallelEvaluate[PacletDirectoryLoad[FileNameJoin[{ParentDirectory[NotebookDirectory[]], "Recursor"}]]; Needs["WolframInstitute`Recursor`"]];

DistributeDefinitions[corpus, oeis, study];
```

```wl
sample = BlockRandom[SeedRandom[2026]; RandomSample[identifiers, 40]];
sampled = AssociationThread[sample, ParallelMap[study[oeis[#], 20] &, sample, Method -> "FinestGrained"]];
Counts[Which[#Solved, "solved", ! MissingQ[#Program], "fitted, not solved", True, "nothing found"] & /@ Values[sampled]]
```

The solved ones, with the later terms each program reproduces.

```wl
Dataset[summary /@ Select[sampled, #Solved &]]
```

```wl
Column[KeyValueMap[Row[{#1, ":  ", TranslateRecursor[#2["Program"], "TestInputs" -> Take[oeis[#1], UpTo[24]][[All, 1]]]}] &, Select[sampled, #Solved &]], Spacings -> 1]
```

## Your own sequence

Give terms from index 0, or {index, value} pairs.

```wl
mine = SynthesizeRecursor[{1, 3, 7, 13, 21, 31, 43, 57, 73, 91, 111, 133, 157, 183, 211, 241}]
```

```wl
TranslateRecursor[mine["Program"]]
```

More room for the search: larger parts, larger loop terms and more time.

```wl
summary[study[oeis["A000203"], 30, "MaxFoldTerm" -> 6, "TimeLimit" -> 120]]
```
