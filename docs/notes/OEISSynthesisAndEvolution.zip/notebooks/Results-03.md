# Evolving programs for integer sequences

Programs are evolved from the first twenty terms of a sequence. Fitness is the number of those terms a program reproduces.

## Setup

```code
PacletDirectoryLoad[FileNameJoin[{ParentDirectory[NotebookDirectory[]], "Recursor"}]];

Needs["WolframInstitute`Recursor`"]

(* the first offset and the first recorded terms of each sequence, from the OEIS *)
recorded = <|"A000040" -> {1, {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181}},
	"A000108" -> {0, {1, 1, 2, 5, 14, 42, 132, 429, 1430, 4862, 16796, 58786, 208012, 742900, 2674440, 9694845, 35357670, 129644790, 477638700, 1767263190, 6564120420, 24466267020, 91482563640, 343059613650, 1289904147324, 4861946401452, 18367353072152, 69533550916004, 263747951750360, 1002242216651368, 3814986502092304}},
	"A000166" -> {0, {1, 0, 1, 2, 9, 44, 265, 1854, 14833, 133496, 1334961, 14684570, 176214841, 2290792932, 32071101049, 481066515734, 7697064251745, 130850092279664, 2355301661033953, 44750731559645106, 895014631192902121, 18795307255050944540, 413496759611120779881, 9510425471055777937262}},
	"A000120" -> {0, {0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3}},
	"A000123" -> {0, {1, 2, 4, 6, 10, 14, 20, 26, 36, 46, 60, 74, 94, 114, 140, 166, 202, 238, 284, 330, 390, 450, 524, 598, 692, 786, 900, 1014, 1154, 1294, 1460, 1626, 1828, 2030, 2268, 2506, 2790, 3074, 3404, 3734, 4124, 4514}},
	"A018252" -> {1, {1, 4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 22, 24, 25, 26, 27, 28, 30, 32, 33, 34, 35, 36, 38, 39, 40, 42, 44, 45, 46, 48, 49, 50, 51, 52, 54, 55, 56, 57, 58}},
	"A000272" -> {0, {1, 1, 1, 3, 16, 125, 1296, 16807, 262144, 4782969, 100000000, 2357947691, 61917364224, 1792160394037, 56693912375296, 1946195068359375, 72057594037927936, 2862423051509815793, 121439531096594251776, 5480386857784802185939, 262144000000000000000000, 13248496640331026125580781}},
	"A000005" -> {1, {1, 2, 2, 3, 2, 4, 2, 4, 3, 4, 2, 6, 2, 4, 4, 5, 2, 6, 2, 6, 4, 4, 2, 8, 3, 4, 4, 6, 2, 8, 2, 6, 4, 4, 4, 9, 2, 4, 4, 8, 2, 8}},
	"A002808" -> {1, {4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 22, 24, 25, 26, 27, 28, 30, 32, 33, 34, 35, 36, 38, 39, 40, 42, 44, 45, 46, 48, 49, 50, 51, 52, 54, 55, 56, 57, 58, 60}},
	"A001006" -> {0, {1, 1, 2, 4, 9, 21, 51, 127, 323, 835, 2188, 5798, 15511, 41835, 113634, 310572, 853467, 2356779, 6536382, 18199284, 50852019, 142547559, 400763223, 1129760415, 3192727797, 9043402501, 25669818476, 73007772802, 208023278209, 593742784829, 1697385471211}},
	"A005258" -> {0, {1, 3, 19, 147, 1251, 11253, 104959, 1004307, 9793891, 96918753, 970336269, 9807518757, 99912156111, 1024622952993, 10567623342519, 109527728400147, 1140076177397091, 11911997404064793, 124879633548031009, 1313106114867738897, 13844511065506477501}},
	"A001181" -> {0, {1, 1, 2, 6, 22, 92, 422, 2074, 10754, 58202, 326240, 1882960, 11140560, 67329992, 414499438, 2593341586, 16458756586, 105791986682, 687782586844, 4517543071924, 29949238543316, 200234184620736, 1349097425104912, 9154276618636016, 62522506583844272}}|>;

twelve = <|"A000040" -> "Prime numbers", "A000108" -> "Catalan numbers", "A000166" -> "Derangements", "A000120" -> "Binary weight",
	"A000123" -> "Binary partitions", "A018252" -> "Nonprime numbers", "A000272" -> "Labeled trees", "A000005" -> "Number of divisors",
	"A002808" -> "Composite numbers", "A001006" -> "Motzkin numbers", "A005258" -> "Apéry numbers", "A001181" -> "Baxter permutations"|>;

oeis[id_String] := With[{offset = recorded[id][[1]], terms = recorded[id][[2]]}, Transpose[{offset + Range[0, Length[terms] - 1], terms}]]

given = 20;

limits = {"MaxSteps" -> 2000, "TimeLimit" -> 1};

(* guided variation: each change is worked out backwards from the terms *)
guided[id_String, generations_Integer : 30, seed_Integer : 1] := EvolveRecursor[Take[oeis[id], given], Method -> "Guided", "MaxGenerations" -> generations,
	"StopOnSolve" -> False, "RandomSeed" -> seed, Sequence @@ limits]

(* the same search with larger pieces in its library *)
wider[id_String, cost_Integer] := EvolveRecursor[Take[oeis[id], given], Method -> "Guided", "LibraryCost" -> cost, "StopOnSolve" -> False, "RandomSeed" -> 1, Sequence @@ limits]

(* how many of the recorded terms after the ones given a program reproduces *)
later[id_String, program_] := With[{rest = Drop[oeis[id], given]}, Row[{Count[rest, {n_, term_} /; value[program, n] === term], " of ", Length[rest]}]]

random[id_String, seed_Integer : 1] := EvolveRecursor[Take[oeis[id], given], "StopOnSolve" -> False, "RandomSeed" -> seed, Sequence @@ limits]

(* every program of a search as a dot, and the best so far as a line *)
evolutionPlot[id_String, result_Association, size_ : 230] := Show[
	ListPlot[{#Generation, #Score} & /@ Select[result["Genealogy"], #Size <= 60 &], PlotStyle -> Directive[GrayLevel[0.55], Opacity[0.35], PointSize[If[Length[result["FitnessHistory"]] > 60, 0.006, 0.012]]]],
	ListStepPlot[result["FitnessHistory"], DataRange -> {0, Length[result["FitnessHistory"]] - 1}, PlotStyle -> Directive[ColorData[97, 2], Thick]],
	PlotRange -> {{-0.5, Length[result["FitnessHistory"]] - 0.5}, {-0.5, given + 0.7}}, PlotLabel -> twelve[id], Frame -> True, Axes -> False,
	FrameLabel -> {"Generation", "Terms reproduced"}, ImageSize -> size]

value[program_, n_] := EvaluateRecursor[program, n, "MaxSteps" -> 2000000, "TimeLimit" -> 10]

(* which recorded terms a program reproduces: the terms given, then the ones after them *)
termStrip[id_String, program_, shown_ : given] := ArrayPlot[{Boole[value[program, First[#]] === Last[#]] & /@ oeis[id]}, ColorRules -> {1 -> RGBColor[0.2, 0.65, 0.4], 0 -> GrayLevel[0.85]},
	Mesh -> True, MeshStyle -> White, Frame -> False, ImageSize -> 330, Epilog -> {Black, Thick, Line[{{shown, 0}, {shown, 1}}]}]

wl[id_String, program_] := TranslateRecursor[program, "TestInputs" -> Take[oeis[id], given][[All, 1]]]

(* the programs at which a search first reproduced more terms *)
breakthroughs[result_Association] := Module[{best = -1},
	Select[SortBy[result["Genealogy"], {#Generation &, -#Score &}], If[#Score > best, best = #Score; True, False] &]
]
```

## Random and guided variation

The best program so far in two searches with the same budget, thirty generations of forty programs. Random variation mutates and crosses programs. Guided variation works out what a part of a program must compute and looks it up.

```wl
searches = AssociationMap[guided, Keys[twelve]];
randoms = AssociationMap[random, Keys[twelve]];
Legended[Grid[Partition[Table[ListStepPlot[{randoms[id]["FitnessHistory"], searches[id]["FitnessHistory"]}, DataRange -> {0, 30}, PlotRange -> {0, given + 0.7}, PlotLabel -> twelve[id], Frame -> True, FrameLabel -> {"Generation", "Terms reproduced"}, PlotLegends -> None, ImageSize -> 220], {id, Keys[twelve]}], 4]], LineLegend[{ColorData[97, 1], ColorData[97, 2]}, {"Random variation", "Guided variation"}]]
```

## Guided evolution

Every dot is a program the search tried, of at most sixty nodes, placed at its generation and the number of the twenty terms it reproduces. The line is the best so far.

```wl
Grid[Partition[KeyValueMap[evolutionPlot, searches], 4]]
```

## One search enlarged

```wl
evolutionPlot["A000123", searches["A000123"], 520]
```

## The breakthroughs of one search

Binary partitions. Each row is the program at which the guided search first reproduced more terms. Green marks the recorded terms it gets right; the line ends the twenty terms given.

```wl
Grid[Prepend[{#Generation, #Score, termStrip["A000123", #Program], wl["A000123", #Program]} & /@ breakthroughs[searches["A000123"]], Style[#, Bold] & /@ {"Generation", "Terms", "Recorded terms reproduced", "Program"}], Alignment -> Left, Dividers -> {None, {2 -> GrayLevel[0.7]}}, Spacings -> {2, 1}]
```

## Five times as many generations

The same searches run for 150 generations.

```wl
longer = AssociationMap[guided[#, 150] &, Keys[twelve]];
Grid[Partition[KeyValueMap[evolutionPlot, longer], 4]]
```

Terms reproduced of the twenty given, and of the recorded terms after them, at 30 and at 150 generations.

```wl
Dataset[Association[Table[twelve[id] -> <|"Given, 30 generations" -> searches[id]["Fitness"], "Given, 150 generations" -> longer[id]["Fitness"],
	"Later, 30 generations" -> later[id, searches[id]["Program"]], "Later, 150 generations" -> later[id, longer[id]["Program"]],
	"Nodes, 30" -> RecursorNodeCount[searches[id]["Program"]], "Nodes, 150" -> RecursorNodeCount[longer[id]["Program"]]|>, {id, Keys[twelve]}]]]
```

## A larger library

The pieces a variation can insert are the small programs of a library. Here they may have seven nodes instead of six; thirty generations as before.

```wl
larger = AssociationMap[wider[#, 7] &, Keys[twelve]];
Grid[Partition[KeyValueMap[evolutionPlot, larger], 4]]
```

Terms reproduced of the twenty given, and of the recorded terms after them, with library pieces of up to six and up to seven nodes.

```wl
Dataset[Association[Table[twelve[id] -> <|"Given, library 6" -> searches[id]["Fitness"], "Given, library 7" -> larger[id]["Fitness"],
	"Later, library 6" -> later[id, searches[id]["Program"]], "Later, library 7" -> later[id, larger[id]["Program"]],
	"Nodes, 6" -> RecursorNodeCount[searches[id]["Program"]], "Nodes, 7" -> RecursorNodeCount[larger[id]["Program"]]|>, {id, Keys[twelve]}]]]
```

The Catalan numbers with the larger library: the breakthroughs of the search.

```wl
Grid[Prepend[{#Generation, #Score, termStrip["A000108", #Program], wl["A000108", #Program]} & /@ breakthroughs[larger["A000108"]], Style[#, Bold] & /@ {"Generation", "Terms", "Recorded terms reproduced", "Program"}], Alignment -> Left, Dividers -> {None, {2 -> GrayLevel[0.7]}}, Spacings -> {2, 1}]
```

## Do the evolved programs continue the sequence?

The program of each guided search on every recorded term: twenty given, the rest never seen.

```wl
Grid[Prepend[KeyValueMap[{twelve[#1], termStrip[#1, #2["Program"]], wl[#1, #2["Program"]]} &, searches], Style[#, Bold] & /@ {"Sequence", "Recorded terms reproduced", "Evolved program"}], Alignment -> Left, Dividers -> {None, {2 -> GrayLevel[0.7]}}, Spacings -> {2, 1}]
```

## The same sequences by exhaustive synthesis

SynthesizeRecursor enumerates programs by size instead of evolving them. Up to thirty terms given; it holds back a quarter of them to test what it finds.

```wl
synthesized = AssociationMap[SynthesizeRecursor[Take[oeis[#], UpTo[30]]] &, Keys[twelve]];
Grid[Prepend[KeyValueMap[{twelve[#1], #2["Method"], termStrip[#1, #2["Program"], Min[30, Length[oeis[#1]]]], TranslateRecursor[#2["Program"], "TestInputs" -> Take[oeis[#1], UpTo[24]][[All, 1]]]} &, synthesized], Style[#, Bold] & /@ {"Sequence", "Found by", "Recorded terms reproduced", "Program"}], Alignment -> Left, Dividers -> {None, {2 -> GrayLevel[0.7]}}, Spacings -> {2, 1}]
```
