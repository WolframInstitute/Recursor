# Evolution on OEIS sequences

A working notebook for the evolutionary searches. Every search sees the first eight terms of a sequence and is judged on the terms after them. Evaluate the Setup section first; every other section can then be run and changed on its own.

## Setup

Load the paclet from this checkout, and the measurements.

```code
PacletDirectoryLoad[FileNameJoin[{ParentDirectory[NotebookDirectory[]], "Recursor"}]];

Needs["WolframInstitute`Recursor`"]

data = Import[FileNameJoin[{ParentDirectory[NotebookDirectory[]], "docs", "notes", "data", "OEISSynthesisAndEvolution.json.gz"}], {"GZIP", "RawJSON"}];

arms = Association[#Name -> # & /@ data["Arms"]];

options = data["Protocol"]["SearchOptions"];
```

The improved search: every term is a test, parents are chosen by lexicase selection, and no two individuals behave alike. Change it and run it below.

```include
build/oeis-evolution-v2/improved.wl
```

The guided search is in the paclet: EvolveRecursor with Method -> "Guided". Each variation runs a program backwards from the terms and asks a library of small programs for the part that is missing.

```code
guidedSearch[examples_, seed_ : 9101] := EvolveRecursor[examples, Method -> "Guided", Sequence @@ Normal[options], "StopOnSolve" -> False, "RandomSeed" -> seed]
```

## The arms

Sequences fitted (the eight terms reproduced), predicted (the terms up to the twentieth too) and complete (every recorded term). An arm with twenty training terms has nothing between fitted and complete.

```code
counts[arm_Association] := <|"Sequences" -> arm["Sequences"], "Fitted" -> Total[arm["Fitted"]],
	"Predicted" -> If[arm["TrainingTerms"] === 8, Total[arm["Predicted"]], Missing["NotApplicable"]], "Complete" -> Total[arm["Complete"]],
	"Seconds per sequence" -> Round[Mean[arm["Seconds"]], 0.1]|>
```

```wl
Dataset[Association[#Label -> counts[#] & /@ data["Arms"]]]
```

The same sequences in every arm with eight terms: the first ones of the fixed random order, as many as the shortest arm has. Corpus v1 is the evolution of paclet 0.1.0, the engine is the search of corpus v2, and the straight line is the baseline: a line through the eight terms.

```code
shared = Min[#Sequences & /@ Select[data["Arms"], #TrainingTerms === 8 && ! StringContainsQ[#Name, "long"] &]];

perThousand[flags_List] := 1000. Total[Take[flags, shared]]/shared

compared = Join[
	<|"Straight line" -> data["Reference"]["StraightLine"], "Evolution, corpus v1" -> data["Reference"]["EvolutionV1"]|>,
	Association[#Label -> # & /@ Select[data["Arms"], #TrainingTerms === 8 && ! StringContainsQ[#Name, "long"] &]],
	<|"Engine of corpus v2" -> data["Reference"]["Engine8"]|>
];
```

```wl
BarChart[Reverse[perThousand[#Predicted] & /@ compared], BarOrigin -> Left, ChartLabels -> Reverse[Keys[compared]], Frame -> True, FrameLabel -> {None, "Sequences predicted per 1,000"}, PlotLabel -> Row[{"The first ", shared, " sequences"}]]
```

```wl
BarChart[Reverse[perThousand[#Fitted] & /@ compared], BarOrigin -> Left, ChartLabels -> Reverse[Keys[compared]], Frame -> True, FrameLabel -> {None, "Sequences fitted per 1,000"}]
```

How close a search comes: the number of training terms that the chosen program of each sequence reproduces.

```wl
BarChart[Transpose[Normalize[BinCounts[Take[#Matched, shared], {0, 9, 1}], Total] & /@ Select[data["Arms"], #TrainingTerms === 8 && #Kind === "Evolution" && ! StringContainsQ[#Name, "long"] &]], ChartLabels -> {Range[0, 8], None}, ChartLegends -> (#Label & /@ Select[data["Arms"], #TrainingTerms === 8 && #Kind === "Evolution" && ! StringContainsQ[#Name, "long"] &]), Frame -> True, FrameLabel -> {"Training terms reproduced", "Share of sequences"}]
```

## Programs that evolution finds

The sequences that the guided search predicts, with the size of each program.

```code
found[name_String, key_String] := With[{arm = arms[name]},
	KeyTake[arm["Programs"], Pick[Take[data["Sequences"], arm["Sequences"]], arm[key], 1]]
]

terms[id_String] := With[{record = data["Terms"][id]},
	Transpose[{record["Offset"] + Range[0, Length[record["Terms"]] - 1], FromDigits /@ record["Terms"]}]
]
```

```wl
predicted = found["guided-8", "Predicted"];
Histogram[Values[predicted][[All, "Nodes"]], {1}, Frame -> True, FrameLabel -> {"Nodes", "Programs"}]
```

Ten of them as Wolfram Language functions.

```wl
Column[KeyValueMap[Row[{#1, ":  ", TranslateRecursor[ParseRecursor[#2["Program"]], "TestInputs" -> Take[terms[#1], UpTo[16]][[All, 1]]]}] &, Take[predicted, UpTo[10]]], Spacings -> 1]
```

One of them as a tree.

```wl
RecursorProgramTree[ParseRecursor[First[Values[predicted]]["Program"]]]
```

Fitted is not predicted. The share of fitted programs that predict, by size.

```wl
With[{arm = arms["guided-8"]}, With[{sizes = Lookup[arm["Programs"], Pick[Take[data["Sequences"], arm["Sequences"]], arm["Fitted"], 1]][[All, "Nodes"]], right = Pick[arm["Predicted"], arm["Fitted"], 1]},
	With[{shares = KeySort[N[Mean /@ GroupBy[Transpose[{Clip[5 Ceiling[sizes/5], {5, 40}], right}], First -> Last]]]},
		BarChart[Values[shares], ChartLabels -> Keys[shares], Frame -> True, FrameLabel -> {"Nodes, up to", "Share predicted"}]]]]
```

## One search, generation by generation

Eight terms of a sequence. Change them to try another.

```wl
examples = Transpose[{Range[0, 7], {1, 1, 2, 3, 5, 8, 13, 21}}]
```

The search of corpus v1. The curve is the fitness of the best program so far.

```wl
plain = EvolveRecursor[examples, Sequence @@ Normal[options], "RandomSeed" -> 9101];
RecursorEvolutionPlot[plain]
```

The improved and the guided search with the same seed and budget: the number of terms that the best program reproduces. The guided search spends the first half of its generations on closed programs and the second half on recurrence steps.

```wl
improved = improvedEvolve[examples, options, 9101];
guided = guidedSearch[examples];
ListStepPlot[{improved["FitnessHistory"], guided["FitnessHistory"]}, DataRange -> {0, 20}, PlotLegends -> {"Improved", "Guided"}, Frame -> True, FrameLabel -> {"Generation", "Terms reproduced"}, PlotRange -> {0, 8.4}]
```

The family tree of the guided search. Every program has the parents it was made from.

```wl
RecursorGenealogyGraph[guided]
```

```wl
FormatRecursor /@ <|"Corpus v1" -> plain["Program"], "Improved" -> improved["Program"], "Guided" -> guided["Program"]|>
```

```wl
RecursorProgramTree[guided["Program"]]
```

The program of the guided search on later terms.

```wl
Table[EvaluateRecursor[guided["Program"], n], {n, 0, 15}]
```

## Evolution and synthesis on your own sequence

The first eight terms go to each search; the rest test the programs.

```code
compare[sequence_List] := With[{examples = Transpose[{Range[0, 7], Take[sequence, 8]}], later = Transpose[{Range[8, Length[sequence] - 1], Drop[sequence, 8]}]},
	Map[
		<|"Program" -> FormatRecursor[#], "Nodes" -> RecursorNodeCount[#],
			"Terms fitted" -> Count[examples, {n_, value_} /; EvaluateRecursor[#, n] === value],
			"Later terms right" -> Row[{Count[later, {n_, value_} /; EvaluateRecursor[#, n, "MaxSteps" -> 1000000] === value], " of ", Length[later]}]|> &,
		<|"Improved evolution" -> improvedEvolve[examples, options, 9101]["Program"], "Guided evolution" -> guidedSearch[examples]["Program"],
			"Synthesis" -> Replace[SynthesizeRecursor[examples]["Program"], _Missing -> Const[0]]|>
	]
]
```

```wl
Dataset[compare[Table[n^3 + 2 n, {n, 0, 19}]]]
```

```wl
Dataset[compare[LucasL[Range[0, 19]]]]
```
