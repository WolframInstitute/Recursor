# Evolution and synthesis on OEIS sequences

Corpus v1 measured EvolveRecursor on the OEIS snapshot with paclet 0.1.0, before Quot and Let
existed. This directory repeats that protocol on the same sequences in v1's fixed random order:
eight training terms, seeds 9101 to 9103, the same search options and budgets
(`../oeis-corpus-v1/protocol.json`). The arms differ in the paclet source and in the search.

| Arm | File | What changes |
| --- | --- | --- |
| Evolution | `evolution-0.1.0.jsonl` | Nothing: the source of corpus v1. Checks that the rerun reproduces it. |
| Evolution | `evolution-0.2.1.jsonl` | The paclet source of 0.2.1, with Quot and Let. |
| Improved | `improved-8.jsonl` | `improved.wl`: every term a test, lexicase selection, one individual per behaviour. |
| Improved | `improved-8-long.jsonl` | The same with 100 generations instead of 20. |
| Improved | `improved-20.jsonl` | The same with twenty training terms. |
| Guided | `guided-8.jsonl` | `guided.wl`: variation by running programs backwards against a library. |
| Synthesis | `synthesis-8.jsonl` to `synthesis-20.jsonl` | SynthesizeRecursor of the working tree from 8, 12, 16 and 20 terms, one deterministic trial. |

```sh
python3 prepare.py 30000        # jobs.json: the first sequences of v1's order, with their terms
./queue.sh                      # the arms, one after another; or single runs:
wolframscript -file run.wls source-0.2.1 improved-8.jsonl 1 5000 9 Improved
wolframscript -file run.wls ../../Recursor guided-8.jsonl 1 2000 9 Guided
wolframscript -file run.wls ../../Recursor synthesis-8.jsonl 1 2000 9 Synthesis
python3 summarize.py --v1       # v1-fitted.json: the programs corpus v1 selected
wolframscript -file recheck.wls v1          # later terms again, with a generous evaluation budget
wolframscript -file recheck.wls improved-8  # ... for every evolutionary arm
python3 summarize.py --tables --export      # the comparison, the tables of the note, the exported data
```

`source-0.2.1` is `git archive v0.2.1 Recursor`, unpacked. `run.wls` appends one line per trial and
skips finished sequences when started again. A file named `STOP` ends a run after its current chunk
of 200 sequences. Do not edit `run.wls` while a run is reading it.

`summarize.py` selects one trial per sequence as v1 did (most training terms matched, then fewest
nodes, then lowest seed). A sequence is fitted when the program reproduces its training terms,
predicted when it also reproduces the terms up to the twentieth, and complete when it reproduces
every recorded term. The runs judge later terms with v1's evaluation budget of 2,000 steps;
`recheck.wls` judges them again with 5,000,000 steps and ten seconds per term, and the summary uses
that where it exists. The synthesis arms use the generous budget from the start.

`queue.sh` ran the first arms and `queue3.sh` the ones a shutdown cut short. `stop-one.sh PID` ends one
run after its chunk. `solved-rule.py` gives the share of solved programs that continue, by the number of
terms given. `port-check.wl` compares the guided method of the paclet with `guided.wl`.
`../synth/profile.wl` measures the time and the memory kept by repeated SynthesizeRecursor calls.

`check-guided.wl` tests the backward rules of `guided.wl` against the interpreter by brute force.
`tune.sh` and `tune.py` ran the guided arm on sequences 20,001 to 20,300 of the order, which no
reported arm uses, to choose its library size. `../synth` holds the measurement of
SynthesizeRecursor on random samples of the development and evaluation splits (`sample.py`,
`evaluate.wl`).
