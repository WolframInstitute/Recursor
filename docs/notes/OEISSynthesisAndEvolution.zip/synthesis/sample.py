"""Draw a reproducible random sample of corpus sequences for testing the paclet synthesizer.

usage: sample.py SPLIT COUNT SEED OUTPUT    (SPLIT is dev or eval)
Each record carries the recorded terms and what the experiment engine achieved in its four published rounds.
"""
import json, pathlib, random, sqlite3, sys

split, count, seed, output = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
root = pathlib.Path(__file__).resolve().parents[1] / "oeis-corpus-v2"
db = sqlite3.connect("file:%s?mode=ro" % (root / "results.sqlite3"), uri=True)
db.row_factory = sqlite3.Row
identifiers = [row[0] for row in db.execute("select id from sequences where dev=? order by id", (1 if split == "dev" else 0,))]
chosen = set(random.Random(seed).sample(identifiers, count))
engine = {identifier: {} for identifier in chosen}
for row in db.execute("select track, id, train_ok, test_ok, extended_ok from outcomes where round<=4"):
    if row["id"] in chosen:
        engine[row["id"]][row["track"]] = [row["train_ok"] or 0, row["test_ok"] or 0, row["extended_ok"] or 0]
records = []
with open(root / "data" / "sequences.tsv") as handle:
    for line in handle:
        identifier, offset, values = line.rstrip("\n").split("\t")
        if identifier in chosen:
            records.append({"ID": identifier, "Offset": int(offset), "Terms": values.split(","),
                            "P20": engine[identifier].get("p20", [0, 0, 0]), "P8": engine[identifier].get("p8", [0, 0, 0])})
json.dump(records, open(output, "w"))
print(len(records), "sequences;", sum(r["P20"][2] for r in records), "validated by the engine from 20 terms;",
      sum(r["P8"][1] for r in records), "predicted by the engine from 8 terms")
