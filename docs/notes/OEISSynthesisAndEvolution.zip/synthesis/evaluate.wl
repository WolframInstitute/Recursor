(* Run SynthesizeRecursor on a sample of corpus sequences and check each program on later recorded terms.
   usage: wolframscript -file evaluate.wl SAMPLE.json GIVEN OUTPUT.json [option value ...] *)
root = DirectoryName[$InputFileName, 3];
PacletDirectoryLoad[FileNameJoin[{root, "Recursor"}]];
Needs["WolframInstitute`Recursor`"]
{sampleFile, given, outputFile} = {$ScriptCommandLine[[2]], ToExpression[$ScriptCommandLine[[3]]], $ScriptCommandLine[[4]]};
options = Rule @@@ Partition[ToExpression /@ Drop[$ScriptCommandLine, 4], 2];
sample = Import[sampleFile, "RawJSON"];
LaunchKernels[10];
ParallelEvaluate[PacletDirectoryLoad[FileNameJoin[{root, "Recursor"}]]; Needs["WolframInstitute`Recursor`"]];
run[record_] := Module[{terms = FromDigits /@ record["Terms"], pairs, shown, later, seconds, result, program, matched},
	pairs = Transpose[{record["Offset"] + Range[0, Length[terms] - 1], terms}];
	{shown, later} = TakeDrop[pairs, UpTo[given]];
	later = Take[later, UpTo[30]];
	{seconds, result} = AbsoluteTiming[SynthesizeRecursor[shown, Sequence @@ options]];
	program = result["Program"];
	matched = If[MissingQ[program], 0,
		LengthWhile[later, EvaluateRecursor[program, First[#], "MaxSteps" -> 5000000, "TimeLimit" -> 20] === Last[#] &]];
	<|"ID" -> record["ID"], "Seconds" -> Round[seconds, 0.01], "Solved" -> result["Solved"], "Found" -> ! MissingQ[program],
		"Method" -> Lookup[result, "Method", ""], "Cost" -> Lookup[result, "Cost", 0], "Nodes" -> Lookup[result, "Nodes", 0],
		"Later" -> Length[later], "LaterMatched" -> matched, "Evidence" -> Lookup[result, "Evidence", 0.],
		"HeldOutPassed" -> (! MissingQ[program] && Lookup[result, "HeldOutMatches", -1] === result["HeldOutExamples"] && result["HeldOutExamples"] > 0), "Program" -> If[MissingQ[program], "", FormatRecursor[program]],
		"EngineP20" -> record["P20"], "EngineP8" -> record["P8"]|>
];
DistributeDefinitions[run, given, options];
results = ParallelMap[run, sample, Method -> "FinestGrained"];
Export[outputFile, results, "RawJSON"];
solved = Select[results, #Solved &];
checkable = Select[solved, #Later > 0 &];
right = Select[checkable, #LaterMatched === #Later &];
engine = Select[results, If[given >= 20, #EngineP20[[3]], #EngineP8[[3]]] === 1 &];
Print["sequences ", Length[results], " | solved ", Length[solved], " | solved with later terms to check ", Length[checkable],
	" | of those, every checked later term reproduced ", Length[right], " (", Round[100. Length[right]/Max[Length[checkable], 1], 0.1], "%)"];
Print["unconfirmed fits ", Count[results, r_ /; r["Found"] && ! r["Solved"]], " | nothing found ", Count[results, r_ /; ! r["Found"]]];
Print["engine validated ", Length[engine], " | of those the paclet solved ", Count[engine, r_ /; r["Solved"]],
	" | paclet solved beyond the engine ", Count[solved, r_ /; ! MemberQ[engine[[All, "ID"]], r["ID"]]]];
Print["methods of solved: ", KeySort[Counts[solved[[All, "Method"]]]]];
Print["wrong among solved: ", KeySort[Counts[Complement[checkable, right][[All, "Method"]]]]];
Print["seconds: median ", Median[results[[All, "Seconds"]]], ", mean ", Round[Mean[results[[All, "Seconds"]]], 0.1], ", max ", Max[results[[All, "Seconds"]]]];
