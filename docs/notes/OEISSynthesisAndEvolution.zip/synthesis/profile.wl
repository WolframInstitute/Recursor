(* Memory and time of repeated SynthesizeRecursor calls on corpus sequences.
   usage: wolframscript -file profile.wl [COUNT [GIVEN]] *)
root = DirectoryName[$InputFileName, 3];
PacletDirectoryLoad[FileNameJoin[{root, "Recursor"}]];
Needs["WolframInstitute`Recursor`"]
$HistoryLength = 0;
count = If[Length[$ScriptCommandLine] > 1, ToExpression[$ScriptCommandLine[[2]]], 12];
given = If[Length[$ScriptCommandLine] > 2, ToExpression[$ScriptCommandLine[[3]]], 20];
sample = Take[Import[FileNameJoin[{root, "build", "synth", "dev300.json"}], "RawJSON"], count];
before = MemoryInUse[];
names0 = Length[Names["WolframInstitute`Recursor`*`*$*"]];
rows = Table[
	With[{terms = FromDigits /@ record["Terms"]},
		With[{timed = AbsoluteTiming[SynthesizeRecursor[Transpose[{record["Offset"] + Range[0, given - 1], Take[terms, given]}]]]},
			{record["ID"], Round[First[timed], 0.01], Lookup[Last[timed], "Method", "-"], Round[(MemoryInUse[] - before)/2.^20]}
		]
	],
	{record, sample}
];
Print[Grid[rows]];
Print["total seconds ", Total[rows[[All, 2]]], " | MB kept per call ", Round[(MemoryInUse[] - before)/2.^20/count, 0.1],
	" | temporary symbols left ", Length[Names["WolframInstitute`Recursor`*`*$*"]] - names0];
Print["results: ", Hash[rows[[All, {1, 3}]]]];
