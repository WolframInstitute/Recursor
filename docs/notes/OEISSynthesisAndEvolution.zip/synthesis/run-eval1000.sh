#!/bin/zsh
cd "${0:A:h}/../.."
wolframscript -file build/synth/evaluate.wl build/synth/eval1000.json 20 build/synth/eval1000-p20.json 2>&1 | grep -v "shdw\|^From kernel\|^$\|General::stop" > build/synth/eval1000-p20.log
echo done >> build/synth/eval1000-p20.log
