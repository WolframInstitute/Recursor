"""How reliable is Solved, by the number of terms given? Reads the synthesis arms and applies alternative rules.

A record is right when its program reproduces every recorded term after the ones given (counted up to the
first miss, so Primary and Extended both complete). Rules: evidence threshold T and a least number of held-out terms.
"""
import json, pathlib
here = pathlib.Path(__file__).resolve().parent
jobs = {j["ID"]: j for j in json.load(open(here / "jobs.json"))}
for terms in (8, 12, 16, 20):
    path = here / ("synthesis-%d.jsonl" % terms)
    if not path.exists():
        continue
    rows = [json.loads(l) for l in open(path) if l.strip()]
    rows = [r for r in rows if r["Status"] == "Completed"]
    held = terms // 4 if terms >= 8 else 1
    passed = [r for r in rows if r["Training"] == terms]
    def right(r):
        return r["Primary"] == r["PrimaryCount"] and r["Extended"] == r["ExtendedCount"]
    def later(r):
        return len(jobs[r["ID"]]["Terms"]) > terms
    print("== %d terms given (%d held out): %d sequences with a program, %d reproduce the held-out terms" % (terms, held, len(rows), len(passed)))
    for threshold in (16, 24, 32, 40, 48):
        group = [r for r in passed if r["Evidence"] >= threshold and later(r)]
        good = sum(right(r) for r in group)
        print("   evidence >= %2d: %4d with later terms, %4d right (%.1f%%)" % (threshold, len(group), good, 100 * good / max(1, len(group))))
    solved = [r for r in passed if r.get("Solved") and later(r)]
    wrong = [r for r in solved if not right(r)]
    print("   wrong Solved programs break after this many further terms:", sorted(r["Primary"] + r["Extended"] for r in wrong))
