#!/bin/zsh
# The evolution arms, one after another, once the synthesizer measurement on the evaluation split is done.
# Every run is resumable, so this file can be started again after a STOP.
cd "${0:A:h}"
until grep -q '^done' ../synth/eval1000-p20.log 2>/dev/null; do sleep 20; done
run() { wolframscript -file run.wls "$@" 2>&1 | grep --line-buffered -v "shdw\|^From kernel\|^$\|General::stop" >> queue.log; }
run ../oeis-corpus-v1/source/Recursor evolution-0.1.0.jsonl 1 300 9 Evolution
run source-0.2.1 improved-8.jsonl 1 5000 9 Improved
run source-0.2.1 evolution-0.2.1.jsonl 1 5000 9 Evolution
run ../../Recursor synthesis-8.jsonl 1 2000 9 Synthesis
run source-0.2.1 improved-20.jsonl 1 2000 9 Improved 20
run ../../Recursor synthesis-20.jsonl 1 2000 9 Synthesis 20
run source-0.2.1 improved-8-long.jsonl 1 1000 9 Improved 8 100
echo "queue done $(date)" >> queue.log
