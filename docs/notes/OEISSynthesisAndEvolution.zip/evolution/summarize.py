"""Compare the arms with corpus v1 and with the synthesis of corpus v2, sequence by sequence.

One trial per sequence is selected as in v1: most training terms matched, then fewest nodes, then lowest seed.
An arm whose search has a cost of its own (the guided arm) records it, and it takes the place of the nodes.
A sequence is fitted when the selected program reproduces its training terms, predicted when it also reproduces
the recorded terms up to the twentieth, and complete when it reproduces every recorded term.

usage: summarize.py [--v1] [--export]
Prints the comparison. --v1 writes v1-fitted.json, the programs corpus v1 selected for the listed sequences,
for recheck.wls. Where recheck.wls has checked an arm (recheck-NAME.json), its counts of later terms replace
the ones recorded during the run, which used the evaluation budget of corpus v1. --export also writes
docs/notes/data/OEISSynthesisAndEvolution.json.gz, the measurements that the note and the notebook use.
"""
import datetime, gzip, json, math, pathlib, sqlite3, statistics, sys

here = pathlib.Path(__file__).resolve().parent
repository = here.parents[1]
listing = json.load(open(here / "jobs.json"))
jobs = [job["ID"] for job in listing]
json_terms = {job["ID"]: job["Terms"] for job in listing}
order = {identifier: position for position, identifier in enumerate(jobs)}

ARMS = [  # file, label, trials per sequence, kind
    ("evolution-0.2.1.jsonl", "Evolution, paclet 0.2.1 (with Quot and Let)", 3, "Evolution"),
    ("improved-8.jsonl", "Improved evolution", 3, "Evolution"),
    ("improved-8-long.jsonl", "Improved evolution, five times the budget", 3, "Evolution"),
    ("guided-8.jsonl", "Guided evolution", 3, "Evolution"),
    ("synthesis-8.jsonl", "SynthesizeRecursor", 1, "Synthesis"),
    ("synthesis-12.jsonl", "SynthesizeRecursor, twelve terms", 1, "Synthesis"),
    ("synthesis-16.jsonl", "SynthesizeRecursor, sixteen terms", 1, "Synthesis"),
    ("improved-20.jsonl", "Improved evolution, twenty terms", 3, "Evolution"),
    ("synthesis-20.jsonl", "SynthesizeRecursor, twenty terms", 1, "Synthesis"),
]


def interval(k, n):
    """Wilson 95% interval, in percent."""
    if n == 0:
        return "n/a"
    p, z = k / n, 1.96
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return "%.2f%% (%.2f to %.2f)" % (100 * p, 100 * (centre - half), 100 * (centre + half))


def sign_test(a, b):
    """Exact two-sided p-value for a and b discordant pairs under equal odds."""
    n = a + b
    if n == 0:
        return 1.0
    tail = sum(math.comb(n, k) for k in range(0, min(a, b) + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def rechecked(name):
    """Later terms counted again with a generous evaluation budget, by recheck.wls."""
    path = here / ("recheck-%s.json" % name.replace(".jsonl", ""))
    return json.load(open(path)) if path.exists() else {}


def arm(name, trials_per_sequence):
    """The selected trial of every finished sequence of an arm, in the v1 order."""
    path = here / name
    if not path.exists():
        return {}
    again = rechecked(name)
    trials = {}
    for line in open(path):
        if line.strip():
            row = json.loads(line)
            trials.setdefault(row["ID"], []).append(row)
    selected = {}
    for identifier, rows in trials.items():
        if len(rows) < trials_per_sequence:
            continue
        done = [r for r in rows if r["Status"] == "Completed"]
        seconds = sum(r.get("Seconds", 0) for r in rows)
        if not done:
            selected[identifier] = {"Fitted": False, "Predicted": False, "Complete": False, "Matched": 0, "Solved": False, "Seconds": seconds}
            continue
        best = sorted(done, key=lambda r: (-r["Training"], r.get("Cost", r["Nodes"]), r["Seed"]))[0]
        fitted = best["Training"] == best.get("TrainingTerms", 8)
        predicted = fitted and best["Primary"] == best.get("PrimaryCount", 12)
        complete = predicted and best["Extended"] == best["ExtendedCount"]
        if fitted and again.get(identifier, {}).get("Parsed"):
            check = again[identifier]
            predicted = check["Primary"] == check["PrimaryCount"]
            complete = predicted and check["Extended"] == check["ExtendedCount"]
        selected[identifier] = {"Fitted": fitted, "Predicted": predicted, "Complete": complete, "Matched": best["Training"],
                                "Terms": best.get("TrainingTerms", 8), "Solved": bool(best.get("Solved")), "Method": best.get("Method", ""),
                                "Program": best["Program"], "Nodes": best["Nodes"], "Seconds": seconds}
    return {identifier: selected[identifier] for identifier in sorted(selected, key=order.get)}


def flags(record):
    return (record["Fitted"], record["Predicted"], record["Complete"])


v1db = sqlite3.connect("file:%s?mode=ro" % (here.parent / "oeis-corpus-v1" / "results.sqlite3"), uri=True)
v1, v1recorded, baseline, v1programs = {}, {}, {}, []
v1again = rechecked("v1")
for identifier, training, test, extended, program in v1db.execute(
        "select s.id, t.training_exact, t.test_exact, t.extended_exact, t.program from sequences s join trials t on t.job_id = s.selected_trial where s.eligible = 1"):
    if identifier in order:
        v1recorded[identifier] = (bool(training), bool(training and test), bool(training and test and extended))
        v1[identifier] = v1recorded[identifier]
        if training and v1again.get(identifier, {}).get("Parsed"):
            check = v1again[identifier]
            predicted = check["Primary"] == check["PrimaryCount"]
            v1[identifier] = (True, predicted, predicted and check["Extended"] == check["ExtendedCount"])
        if training and order[identifier] < 5000:
            v1programs.append({"ID": identifier, "Program": program, "TrainingTerms": 8})
if "--v1" in sys.argv:
    json.dump(v1programs, open(here / "v1-fitted.json", "w"))
    print("wrote v1-fitted.json: %d programs" % len(v1programs))
for identifier, training, test in v1db.execute("select id, affine_training, affine_test from baselines"):
    if identifier in order:
        baseline[identifier] = (bool(training), bool(training and test))
v2db = sqlite3.connect("file:%s?mode=ro" % (here.parent / "oeis-corpus-v2" / "results.sqlite3"), uri=True)
engine8, engine20 = {}, {}
for track, identifier, training, test, extended in v2db.execute("select track, id, train_ok, test_ok, extended_ok from outcomes where round <= 4"):
    if identifier in order:
        if track == "p8":
            engine8[identifier] = (bool(training), bool(training and test), bool(training and test and extended))
        else:
            engine20[identifier] = (bool(training), bool(training), bool(training and extended))
nothing = (False, False, False)

arms = []
for name, label, trials, kind in ARMS:
    data = arm(name, trials)
    if data:
        arms.append((name, label, kind, data))

for name, label, kind, data in arms:
    common = list(data)
    twenty = "20" in name
    engine = engine20 if twenty else engine8
    print("\n== %s: %d sequences (the first %d of the v1 order)" % (label, len(common), max(order[i] for i in common) + 1))
    for title, column in (("fitted", 0), ("predicted", 1), ("complete", 2)):
        if twenty and column == 1:
            continue
        new = sum(flags(data[i])[column] for i in common)
        old = sum(v1.get(i, nothing)[column] for i in common)
        both = sum(flags(data[i])[column] and v1.get(i, nothing)[column] for i in common)
        synthesized = sum(engine.get(i, nothing)[column] for i in common)
        beyond = sum(flags(data[i])[column] and not engine.get(i, nothing)[column] for i in common)
        print("  %-9s this arm %5d  %s | v1 evolution %5d  %s | both %d, only this arm %d, only v1 %d, p = %.3g | engine %d, this arm beyond the engine %d" % (
            title, new, interval(new, len(common)), old, interval(old, len(common)), both, new - both, old - both,
            sign_test(new - both, old - both), synthesized, beyond))
    if not twenty:
        print("  a straight line through the eight terms: fits %d, predicts %d" % (
            sum(baseline.get(i, (0, 0))[0] for i in common), sum(baseline.get(i, (0, 0))[1] for i in common)))
    if kind == "Synthesis":
        solved = [data[i] for i in common if data[i]["Solved"]]
        print("  marked Solved %d | of those predicted %d, complete %d" % (len(solved), sum(r["Predicted"] for r in solved), sum(r["Complete"] for r in solved)))
    print("  seconds per sequence: median %.1f, mean %.1f" % (statistics.median(data[i]["Seconds"] for i in common), statistics.mean(data[i]["Seconds"] for i in common)))

check = arm("evolution-0.1.0.jsonl", 3)
if check:
    same = sum(flags(check[i]) == v1recorded.get(i) for i in check)
    print("\n== reproduction of corpus v1 with its own source: %d of %d sequences have the recorded outcome" % (same, len(check)))
changed = sum(v1[i] != v1recorded[i] for i in v1)
print("== generous check of the v1 record: %d sequences change outcome" % changed if v1again else "== the v1 record has not been checked again")

if "--tables" in sys.argv:
    by_name = {name: data for name, _, _, data in arms}
    label_of = {name: label for name, label, _, _ in arms}

    def cells(source, identifiers, columns=(0, 1, 2)):
        return [sum(source.get(i, nothing)[c] for i in identifiers) for c in columns]

    def row(label, values, seconds=None):
        return "| %s | %s | %s |" % (label, " | ".join("—" if v is None else "{:,}".format(v) for v in values), "—" if seconds is None else "%.1f" % seconds)

    def own(name, identifiers):
        data = by_name[name]
        return [sum(flags(data[i])[c] for i in identifiers) for c in (0, 1, 2)], statistics.mean(data[i]["Seconds"] for i in identifiers)

    eight = [n for n in ("evolution-0.2.1.jsonl", "improved-8.jsonl", "guided-8.jsonl", "synthesis-8.jsonl") if n in by_name]
    shared = min(len(by_name[n]) for n in eight)
    prefix = jobs[:shared]
    print("\n### Eight terms, the first %s sequences\n" % "{:,}".format(shared))
    print("| Search | Fitted | Predicted | Complete | Seconds per sequence |\n| --- | ---: | ---: | ---: | ---: |")
    print(row("A straight line through the eight terms", [sum(baseline.get(i, (0, 0))[0] for i in prefix), sum(baseline.get(i, (0, 0))[1] for i in prefix), None]))
    print(row("Evolution, paclet 0.1.0 (the record of corpus v1)", cells(v1, prefix)))
    for name in eight:
        values, seconds = own(name, prefix)
        print(row(label_of[name], values, seconds))
    print(row("Search program of corpus v2", cells(engine8, prefix)))
    if "synthesis-8.jsonl" in by_name:
        data = by_name["synthesis-8.jsonl"]
        solved = [i for i in prefix if data[i]["Solved"]]
        print("\nSynthesizeRecursor marked %d of them Solved; %d of those are predicted and %d complete." % (
            len(solved), sum(data[i]["Predicted"] for i in solved), sum(data[i]["Complete"] for i in solved)))

    if "guided-8.jsonl" in by_name and "synthesis-8.jsonl" in by_name:
        guided, synthesis = by_name["guided-8.jsonl"], by_name["synthesis-8.jsonl"]
        print("\n| Predicted by | Sequences |\n| --- | ---: |")
        sets = {"Guided evolution": {i for i in prefix if guided[i]["Predicted"]}, "SynthesizeRecursor": {i for i in prefix if synthesis[i]["Predicted"]},
                "The search program of corpus v2": {i for i in prefix if engine8.get(i, nothing)[1]}}
        print("| Guided evolution and SynthesizeRecursor | %d |" % len(sets["Guided evolution"] & sets["SynthesizeRecursor"]))
        print("| Guided evolution only | %d |" % len(sets["Guided evolution"] - sets["SynthesizeRecursor"]))
        print("| SynthesizeRecursor only | %d |" % len(sets["SynthesizeRecursor"] - sets["Guided evolution"]))
        print("| Guided evolution, not the search program of corpus v2 | %d |" % len(sets["Guided evolution"] - sets["The search program of corpus v2"]))
        print("| Any of the three | %d |" % len(sets["Guided evolution"] | sets["SynthesizeRecursor"] | sets["The search program of corpus v2"]))
        print("\nShare of fitted programs that predict: " + "; ".join(
            "%s %.0f%%" % (label, 100 * sum(by_name[name][i]["Predicted"] for i in prefix) / max(1, sum(by_name[name][i]["Fitted"] for i in prefix)))
            for name, label in (("evolution-0.2.1.jsonl", "evolution 0.2.1"), ("improved-8.jsonl", "improved"), ("guided-8.jsonl", "guided"), ("synthesis-8.jsonl", "SynthesizeRecursor"))
            if name in by_name) + "; search program of corpus v2 %.0f%%." % (100 * sum(engine8.get(i, nothing)[1] for i in prefix) / max(1, sum(engine8.get(i, nothing)[0] for i in prefix))))

    print("\n### Each arm against corpus v1 on its own sequences\n")
    print("| Arm | Sequences | Fitted | v1 fitted | Only this arm | Only v1 | p | Predicted | v1 predicted | Only this arm | Only v1 | p |")
    print("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
    for name in ("evolution-0.2.1.jsonl", "improved-8.jsonl", "improved-8-long.jsonl", "guided-8.jsonl"):
        if name in by_name:
            data = by_name[name]
            parts = []
            for c in (0, 1):
                new = sum(flags(data[i])[c] for i in data)
                old = sum(v1.get(i, nothing)[c] for i in data)
                both = sum(flags(data[i])[c] and v1.get(i, nothing)[c] for i in data)
                p = sign_test(new - both, old - both)
                parts += ["{:,}".format(new), "{:,}".format(old), "{:,}".format(new - both), "{:,}".format(old - both), ("%.2g" % p) if p >= 0.001 else "< 0.001"]
            print("| %s | %s | %s |" % (label_of[name], "{:,}".format(len(data)), " | ".join(parts)))

    if "improved-8-long.jsonl" in by_name:
        longer = by_name["improved-8-long.jsonl"]
        identifiers = [i for i in longer if i in by_name["improved-8.jsonl"]]
        print("\n### Budget, the first %s sequences\n" % "{:,}".format(len(identifiers)))
        print("| Search | Fitted | Predicted | Complete | Seconds per sequence |\n| --- | ---: | ---: | ---: | ---: |")
        for name in ("improved-8.jsonl", "improved-8-long.jsonl"):
            values, seconds = own(name, identifiers)
            print(row(label_of[name], values, seconds))

    twenty = [n for n in ("improved-20.jsonl", "synthesis-20.jsonl") if n in by_name]
    if twenty:
        shared = min(len(by_name[n]) for n in twenty)
        prefix = jobs[:shared]
        print("\n### Twenty terms, the first %s sequences\n" % "{:,}".format(shared))
        print("| Search | Fitted | Every later term | Seconds per sequence |\n| --- | ---: | ---: | ---: |")
        for name in twenty:
            values, seconds = own(name, prefix)
            print("| %s | %s | %s | %.1f |" % (label_of[name], "{:,}".format(values[0]), "{:,}".format(values[2]), seconds))
        print("| Search program of corpus v2 | %s | %s | — |" % ("{:,}".format(sum(engine20.get(i, nothing)[0] for i in prefix)), "{:,}".format(sum(engine20.get(i, nothing)[2] for i in prefix))))
        if "synthesis-20.jsonl" in by_name:
            data = by_name["synthesis-20.jsonl"]
            solved = [i for i in prefix if data[i]["Solved"]]
            later = [i for i in solved if len(json_terms[i]) > 20]
            print("\nSynthesizeRecursor marked %d of them Solved. %d of those have later terms on record, and %d reproduce every one." % (
                len(solved), len(later), sum(data[i]["Complete"] for i in later)))

if "--tables" in sys.argv:
    # the measurement of SynthesizeRecursor on the evaluation sample
    sample = here.parent / "synth" / "eval1000-p20.json"
    if sample.exists():
        rows = json.load(open(sample))

        def right(group):
            later = [r for r in group if r["Later"] > 0]
            good = [r for r in later if r["LaterMatched"] == r["Later"]]
            return len(group), len(later), len(good)

        def line(label, group):
            total, later, good = right(group)
            return "| %s | %s | %s | %s | %s |" % (label, "{:,}".format(total), "{:,}".format(later), "{:,}".format(good), ("%.1f%%" % (100 * good / later)) if later else "—")

        found = [r for r in rows if r["Found"]]
        passed = [r for r in rows if r["HeldOutPassed"]]
        solved = [r for r in rows if r["Solved"]]
        print("\n### SynthesizeRecursor from twenty terms, %s sequences of the evaluation split\n" % "{:,}".format(len(rows)))
        print("| Programs | Sequences | With later terms on record | Reproduce every later term checked | Share |\n| --- | ---: | ---: | ---: | ---: |")
        print(line("Reproduce the fifteen terms of the search", found))
        print(line("…and the five held-out terms", passed))
        print(line("…and have 24 bits of evidence: Solved", solved))
        print(line("Held-out terms reproduced, evidence short", [r for r in passed if not r["Solved"]]))
        print(line("A held-out term missed", [r for r in found if not r["HeldOutPassed"]]))
        print("\nNothing found: %d sequences. Later terms checked per solved program: median %d, at most 30." % (
            sum(not r["Found"] for r in rows), statistics.median(r["Later"] for r in solved if r["Later"] > 0)))
        print("\n| Evidence at least | Programs | With later terms | Reproduce every one | Share |\n| ---: | ---: | ---: | ---: | ---: |")
        for threshold in (0, 8, 16, 24, 32, 40):
            total, later, good = right([r for r in passed if r["Evidence"] >= threshold])
            print("| %d | %d | %d | %d | %.1f%% |" % (threshold, total, later, good, 100 * good / max(later, 1)))
        print("\n| Method | Solved | With later terms | Reproduce every one |\n| --- | ---: | ---: | ---: |")
        methods = {}
        for r in solved:
            methods.setdefault(r["Method"], []).append(r)
        for method, group in sorted(methods.items(), key=lambda item: -len(item[1])):
            print("| %s | %d | %d | %d |" % ((method,) + right(group)))
        engine = [r for r in rows if r["EngineP20"][2] == 1]
        print("\nThe search program of corpus v2 validated %d of these sequences from twenty terms; SynthesizeRecursor solved %d of them and %d others." % (
            len(engine), sum(r["Solved"] for r in engine), sum(r["Solved"] and r["EngineP20"][2] != 1 for r in rows)))
        seconds = [r["Seconds"] for r in rows]
        print("Seconds per sequence: median %.1f, mean %.1f, largest %.1f." % (statistics.median(seconds), statistics.mean(seconds), max(seconds)))

    # SynthesizeRecursor by the number of terms given, on the sequences every such arm has
    series = [(terms, by_name["synthesis-%d.jsonl" % terms]) for terms in (8, 12, 16, 20) if "synthesis-%d.jsonl" % terms in by_name]
    if len(series) > 1:
        shared = min(len(data) for _, data in series)
        prefix = jobs[:shared]
        print("\n### SynthesizeRecursor by the number of terms, the first %s sequences\n" % "{:,}".format(shared))
        print("| Terms given | Held out | Fitted | Every later term | Solved | Solved with later terms | …that reproduce every one |\n| ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
        for terms, data in series:
            solved = [i for i in prefix if data[i]["Solved"]]
            later = [i for i in solved if len(json_terms[i]) > terms]
            print("| %d | %d | %d | %d | %d | %d | %d |" % (terms, terms // 4, sum(data[i]["Fitted"] for i in prefix), sum(data[i]["Complete"] for i in prefix),
                                                   len(solved), len(later), sum(data[i]["Complete"] for i in later)))

if "--export" in sys.argv:
    protocol = json.load(open(here.parent / "oeis-corpus-v1" / "protocol.json"))
    count = max(len(data) for _, _, _, data in arms)
    listed = jobs[:count]

    def column(source, index):
        return [int(source.get(i, nothing)[index]) for i in listed]

    def exported(name, label, kind, data):
        identifiers = list(data)
        return {
            "Name": name.replace(".jsonl", ""), "Label": label, "Kind": kind,
            "TrainingTerms": next(int(part) for part in name.replace(".jsonl", "").split("-") if part.isdigit()) if any(
                part.isdigit() for part in name.replace(".jsonl", "").split("-")) else 8,
            "Sequences": len(identifiers),
            "Fitted": [int(data[i]["Fitted"]) for i in identifiers], "Predicted": [int(data[i]["Predicted"]) for i in identifiers],
            "Complete": [int(data[i]["Complete"]) for i in identifiers], "Matched": [data[i]["Matched"] for i in identifiers],
            "Solved": [int(data[i]["Solved"]) for i in identifiers],
            "Seconds": [round(data[i]["Seconds"], 2) for i in identifiers],
            "Programs": {i: {"Program": data[i]["Program"], "Nodes": data[i]["Nodes"], "Method": data[i]["Method"]} for i in identifiers if data[i]["Fitted"]},
        }

    measured = {}
    for split, name in (("Evaluation", "eval1000-p20.json"), ("Development", "dev1000-p20-final.json")):
        path = here.parent / "synth" / name
        if path.exists():
            measured[split] = [{key: row[key] for key in ("ID", "Solved", "Found", "HeldOutPassed", "Method", "Cost", "Nodes", "Evidence", "Later", "LaterMatched", "Seconds", "Program")}
                               | {"Engine": row["EngineP20"]} for row in json.load(open(path))]
    document = {
        "Study": "Recursor 0.3.0: SynthesizeRecursor and evolution on OEIS sequences",
        "UpdatedUTC": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "Protocol": {"TrainingTerms": protocol["TrainingTerms"], "Seeds": protocol["Seeds"], "SearchOptions": protocol["SearchOptions"]},
        "Sequences": listed,
        "Reference": {
            "EvolutionV1": {"Fitted": column(v1, 0), "Predicted": column(v1, 1), "Complete": column(v1, 2)},
            "StraightLine": {"Fitted": [int(baseline.get(i, (0, 0))[0]) for i in listed], "Predicted": [int(baseline.get(i, (0, 0))[1]) for i in listed]},
            "Engine8": {"Fitted": column(engine8, 0), "Predicted": column(engine8, 1), "Complete": column(engine8, 2)},
            "Engine20": {"Fitted": column(engine20, 0), "Complete": column(engine20, 2)},
        },
        "Arms": [exported(*entry) for entry in arms],
        # recorded terms of the sequences that an evolutionary arm predicts, for the notebook
        "Terms": {job["ID"]: {"Offset": job["Offset"], "Terms": job["Terms"]} for job in listing[:count]
                  if any(kind == "Evolution" and data.get(job["ID"], {}).get("Predicted") for _, _, kind, data in arms)},
        "Reproduction": {"Sequences": len(check), "Same": sum(flags(check[i]) == v1recorded.get(i) for i in check)} if check else {},
        "Synthesis": measured,
    }
    target = repository / "docs" / "notes" / "data" / "OEISSynthesisAndEvolution.json.gz"
    with gzip.GzipFile(target, "wb", mtime=0) as handle:
        handle.write(json.dumps(document, separators=(",", ":"), sort_keys=True).encode())
    print("\nwrote %s (%d bytes)" % (target, target.stat().st_size))
