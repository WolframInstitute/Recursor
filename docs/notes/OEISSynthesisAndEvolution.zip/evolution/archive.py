"""Write docs/notes/OEISSynthesisAndEvolution.zip: the code of the measurements, with checksums.

The archive holds no data. It needs the snapshot and result databases of the corpus experiments beside
it, as their own archives describe. Entries carry a fixed date so that the same code gives the same file.
"""
import hashlib, pathlib, sys, zipfile

here = pathlib.Path(__file__).resolve().parent
build = here.parent
repository = build.parent
entries = {
    "README.md": here / "README.md",
    **{"evolution/" + name: here / name for name in (
        "prepare.py", "run.wls", "improved.wl", "guided.wl", "recheck.wls", "summarize.py", "solved-rule.py", "archive.py",
        "queue.sh", "queue3.sh", "guided-final.sh", "stop-one.sh", "check-guided.wl", "port-check.wl", "tune.sh", "tune.py")},
    **{"synthesis/" + name: build / "synth" / name for name in ("sample.py", "evaluate.wl", "run-eval1000.sh", "profile.wl")},
    **{"notebooks/" + name: build / "notebooks" / name for name in ("build-notebook.wls", "Synthesis-01.md", "Evolution-01.md", "Results-03.md")},
}
missing = [name for name, path in entries.items() if not path.exists()]
if missing:
    sys.exit("missing: " + ", ".join(missing))
private = [name for name, path in entries.items() if (b"/" + b"Users/") in path.read_bytes()]
if private:
    sys.exit("a local path is written in: " + ", ".join(private))
sums = "".join("%s  %s\n" % (hashlib.sha256(path.read_bytes()).hexdigest(), name) for name, path in sorted(entries.items()))
target = repository / "docs" / "notes" / "OEISSynthesisAndEvolution.zip"
with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
    for name, content in sorted([(name, path.read_bytes()) for name, path in entries.items()] + [("SHA256SUMS", sums.encode())]):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 11, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o755 if name.endswith(".sh") else 0o644) << 16
        archive.writestr(info, content)
print("wrote %s: %d files, %d bytes" % (target, len(entries) + 1, target.stat().st_size))
