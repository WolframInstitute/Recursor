"""List the sequences of the evolution rerun, in the fixed random order of corpus v1.

usage: prepare.py COUNT
Writes jobs.json: the first COUNT eligible sequences by v1's sample order, with their terms, and
what corpus v1 recorded for each seed of its Evolution arm. A prefix of that order is a uniform sample.
"""
import json, pathlib, sqlite3, sys

count = int(sys.argv[1])
here = pathlib.Path(__file__).resolve().parent
db = sqlite3.connect("file:%s?mode=ro" % (here.parent / "oeis-corpus-v1" / "results.sqlite3"), uri=True)
db.row_factory = sqlite3.Row
jobs = []
for row in db.execute("select id, offset, terms_json from sequences where eligible=1 order by sample_order limit ?", (count,)):
    jobs.append({"ID": row["id"], "Offset": int(row["offset"]), "Terms": [str(t) for t in json.loads(row["terms_json"])]})
json.dump(jobs, open(here / "jobs.json", "w"))
print(len(jobs), "sequences; first", jobs[0]["ID"], "last", jobs[-1]["ID"])
