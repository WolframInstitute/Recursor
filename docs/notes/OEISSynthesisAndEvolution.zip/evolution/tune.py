"""Outcomes of tuning runs on sequences outside the comparison set. usage: tune.py FILE..."""
import json, pathlib, sqlite3, statistics, sys
here = pathlib.Path(__file__).resolve().parent
def selected(name):
    trials = {}
    for line in open(here / name):
        if line.strip():
            row = json.loads(line)
            trials.setdefault(row["ID"], []).append(row)
    out = {}
    for identifier, rows in trials.items():
        done = [r for r in rows if r["Status"] == "Completed"]
        if not done:
            out[identifier] = None
            continue
        out[identifier] = sorted(done, key=lambda r: (-r["Training"], r.get("Cost", r["Nodes"]), r["Seed"]))[0]
    return out
v1db = sqlite3.connect("file:%s?mode=ro" % (here.parent / "oeis-corpus-v1" / "results.sqlite3"), uri=True)
v2db = sqlite3.connect("file:%s?mode=ro" % (here.parent / "oeis-corpus-v2" / "results.sqlite3"), uri=True)
for name in sys.argv[1:]:
    data = selected(name)
    ids = list(data)
    marks = ",".join("?" * len(ids))
    fitted = [i for i in ids if data[i] and data[i]["Training"] == data[i].get("TrainingTerms", 8)]
    predicted = [i for i in fitted if data[i]["Primary"] == data[i]["PrimaryCount"]]
    complete = [i for i in predicted if data[i]["Extended"] == data[i]["ExtendedCount"]]
    v1 = v1db.execute("select sum(t.training_exact), sum(t.training_exact and t.test_exact) from sequences s join trials t on t.job_id = s.selected_trial where s.id in (%s)" % marks, ids).fetchone()
    line = v1db.execute("select sum(affine_training), sum(affine_training and affine_test) from baselines where id in (%s)" % marks, ids).fetchone()
    engine = v2db.execute("select sum(train_ok), sum(train_ok and test_ok) from outcomes where track='p8' and round<=4 and id in (%s)" % marks, ids).fetchone()
    enginePredicted = {r[0] for r in v2db.execute("select id from outcomes where track='p8' and round<=4 and train_ok and test_ok and id in (%s)" % marks, ids)}
    seconds = [sum(r.get("Seconds", 0) for r in rows) for rows in [[json.loads(l) for l in open(here / name) if l.strip()]]]
    nodes = [data[i]["Nodes"] for i in fitted]
    print("%-28s sequences %d | fitted %d | predicted %d | complete %d | fitted nodes median %s | v1 %s | line %s | engine %s | predicted beyond engine %d, engine beyond %d" % (
        name, len(ids), len(fitted), len(predicted), len(complete), statistics.median(nodes) if nodes else "-", v1, line, engine,
        len(set(predicted) - enginePredicted), len(enginePredicted - set(predicted))))
    print("    seconds per trial: mean %.2f" % (seconds[0] / max(1, sum(1 for l in open(here / name) if l.strip()))))
