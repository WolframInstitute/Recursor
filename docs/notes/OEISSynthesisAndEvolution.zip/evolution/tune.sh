#!/bin/zsh
# Tuning runs of the guided arm on sequences 20001-20300 of the v1 order, which no reported arm uses.
cd "${0:A:h}"
run() { wolframscript -file run.wls "$@" 2>&1 | grep --line-buffered -v "shdw\|^From kernel\|^$\|General::stop" >> tune.log; }
rm -f tune-guided-6s.jsonl tune-guided-7s.jsonl
GUIDED_LIBRARY_COST=6 run ../../Recursor tune-guided-6s.jsonl 20001 20300 3 Guided
GUIDED_LIBRARY_COST=7 run ../../Recursor tune-guided-7s.jsonl 20001 20300 3 Guided
echo "tuning done $(date)" >> tune.log
