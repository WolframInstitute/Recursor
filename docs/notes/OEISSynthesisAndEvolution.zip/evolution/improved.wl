(* An evolutionary search with the proposal budget of EvolveRecursor in corpus v1 (24 initial
   programs, then generations of 22 children) and these changes, following the program synthesis
   literature:
   1. Every training term is a test that a program passes or fails. Fitness is the number passed.
   2. Lexicase selection: a parent is drawn from the programs that pass the tests taken in a random
      order, so a program that alone gets some term right is kept even when its count is low.
   3. One individual per distinct list of values: the population holds no duplicate behaviour.
   4. Variation by small additions and deletions (wrap a subtree in an operation, replace a subtree
      by a small one, or by one of its own parts), with crossover only now and then.
   5. Half of the first population are simple fixed programs; half are random.
   6. A program whose values match after scaling and shifting is completed with that scale and shift.
   Programs are made with the paclet's RandomRecursor, MutateRecursor, CrossoverRecursor,
   RecursorSites and ReplaceRecursorPart. *)

simplePrograms = {Var, Succ[Var], Pred[Var], Half[Var], Add[Var, Var], Mul[Var, Var], Succ[Succ[Var]], Mul[Var, Succ[Var]],
	Mul[Const[3], Var], Half[Mul[Var, Var]], Mul[Var, Mul[Var, Var]], Rem[Var, Const[2]]};

affineProgram[program_, scale_, shift_] := With[{scaled = If[scale === 1, program, Mul[Const[scale], program]]},
	Which[shift > 0, Add[scaled, Const[shift]], shift < 0, Monus[scaled, Const[-shift]], True, scaled]
]

(* scale and shift taking the values to the targets, or None *)
affineFit[values_, targets_] := Module[{at, scale, shift},
	If[! FreeQ[values, Except[_Integer], {1}], Return[None]];
	at = FirstPosition[Differences[values], _?(# =!= 0 &), None, {1}, Heads -> False];
	If[at === None, Return[None]];
	at = First[at];
	If[! Divisible[targets[[at + 1]] - targets[[at]], values[[at + 1]] - values[[at]]], Return[None]];
	scale = Quotient[targets[[at + 1]] - targets[[at]], values[[at + 1]] - values[[at]]];
	shift = First[targets] - scale First[values];
	If[scale >= 1 && scale values + shift === targets && ! (scale === 1 && shift === 0), {scale, shift}, None]
]

(* one small change: wrap a subtree, replace it by a small random program, or by one of its parts *)
wraps = {Succ[#1] &, Pred[#1] &, Half[#1] &, Add[#1, #2] &, Mul[#1, #2] &, Monus[#1, #2] &, Monus[#2, #1] &, Quot[#1, #2] &, Rem[#1, #2] &};
vary[program_, maximumNodes_, randomOptions_] := Module[{sites = RecursorSites[program], site, small, changed},
	site = RandomChoice[sites];
	small = RandomRecursor[RandomInteger[1], Sequence @@ randomOptions];
	changed = Switch[RandomInteger[{1, 3}],
		1, ReplaceRecursorPart[program, site["Path"], RandomChoice[wraps][site["Expression"], small]],
		2, ReplaceRecursorPart[program, site["Path"], small],
		3, With[{parts = Cases[site["Expression"], _Symbol | _Const | _[__], {1}]},
			If[parts === {}, program, ReplaceRecursorPart[program, site["Path"], RandomChoice[parts]]]]
	];
	If[RecursorProgramQ[changed] && RecursorNodeCount[changed] <= maximumNodes, changed, program]
]

improvedEvolve[examples_, options_, seed_] := BlockRandom[SeedRandom[seed]; Module[{
	inputs = examples[[All, 1]], targets = examples[[All, 2]], populationSize, generations, elites, maximumNodes, mutationDepth,
	randomOptions, evaluationOptions, values, individual, complete, rank, select, breed, distinct, population, best, history, proposals = 0
},
	{populationSize, generations, elites, maximumNodes, mutationDepth} =
		Lookup[options, {"PopulationSize", "MaxGenerations", "EliteCount", "MaxNodes", "MutationDepth"}];
	randomOptions = FilterRules[Normal[options], Options[RandomRecursor]];
	evaluationOptions = FilterRules[Normal[options], Options[EvaluateRecursor]];
	values[program_] := values[program] = Quiet[EvaluateRecursor[program, #, Sequence @@ evaluationOptions] & /@ inputs];
	complete[program_] := With[{fit = affineFit[values[program], targets]},
		If[fit === None || RecursorNodeCount[program] + 4 > maximumNodes, program, affineProgram[program, First[fit], Last[fit]]]
	];
	individual[candidate_] := With[{program = complete[candidate]},
		proposals++;
		With[{passed = Boole[MapThread[SameQ, {values[program], targets}]]},
			<|"Program" -> program, "Values" -> values[program], "Size" -> RecursorNodeCount[program], "Passed" -> passed, "Matches" -> Total[passed]|>
		]
	];
	rank[one_] := {one["Matches"], -one["Size"]};
	select[pool_] := Module[{rest = pool},
		Do[
			With[{passing = Select[rest, #["Passed"][[case]] === 1 &]}, If[passing =!= {}, rest = passing]];
			If[Length[rest] === 1, Break[]],
			{case, RandomSample[Range[Length[inputs]]]}
		];
		RandomChoice[rest]
	];
	breed[pool_] := Module[{child = select[pool]["Program"]},
		If[RandomReal[] < 0.2, child = CrossoverRecursor[child, select[pool]["Program"], "MaxNodes" -> maximumNodes]];
		Do[child = vary[child, maximumNodes, randomOptions], {RandomInteger[{1, 2}]}];
		If[RandomReal[] < 0.2, child = MutateRecursor[child, mutationDepth, Sequence @@ randomOptions]];
		individual[child]
	];
	distinct[pool_] := Values[GroupBy[ReverseSortBy[pool, rank], #["Values"] &, First]];
	population = distinct[individual /@ Join[
		Take[simplePrograms, UpTo[Quotient[populationSize, 2]]],
		Table[RandomRecursor[Lookup[options, "InitialDepth"], Sequence @@ randomOptions], {populationSize - Min[Length[simplePrograms], Quotient[populationSize, 2]]}]
	]];
	best = First[MaximalBy[population, rank]];
	history = {best["Matches"]};
	Do[
		population = distinct[Join[Take[ReverseSortBy[population, rank], UpTo[elites]], Table[breed[population], {populationSize - elites}]]];
		best = First[MaximalBy[Append[population, best], rank]];
		AppendTo[history, best["Matches"]],
		{generations}
	];
	<|"Program" -> best["Program"], "Fitness" -> best["Matches"], "FitnessHistory" -> history, "Proposals" -> proposals|>
]]
