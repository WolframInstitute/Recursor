#!/bin/zsh
# The runs that the shutdown cut short, with seven kernels. Every run is resumable.
cd "${0:A:h}"
run() { wolframscript -file run.wls "$@" 2>&1 | grep --line-buffered -v "shdw\|^From kernel\|^$\|General::stop" >> queue.log; }
run ../../Recursor synthesis-16.jsonl 1 1000 7 Synthesis 16
run ../../Recursor synthesis-20.jsonl 1 2000 7 Synthesis 20
run source-0.2.1 improved-8-long.jsonl 1 600 7 Improved 8 100
echo "queue3 done $(date)" >> queue.log
