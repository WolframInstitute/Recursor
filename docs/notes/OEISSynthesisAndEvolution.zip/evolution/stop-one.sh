#!/bin/zsh
# End the run of process PID after its current chunk, and nothing after it: the STOP file is removed
# as soon as that run has exited, before the next arm of the queue looks for it.
cd "${0:A:h}"
touch STOP
while kill -0 "$1" 2>/dev/null; do sleep 0.5; done
rm -f STOP
echo "$(date) stopped run $1 after its chunk" >> queue.log
