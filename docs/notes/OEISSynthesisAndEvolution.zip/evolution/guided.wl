(* Evolution guided by the values the target requires, with the proposal budget of corpus v1 (464 programs
   per run). It follows semantic backpropagation and the random desired operator (Wieloch and Krawiec 2013;
   Pawlak, Wieloch and Krawiec 2015):
   1. A library: the distinct functions of small cost on the training inputs, enumerated once per sequence
      by the class enumeration of SynthesizeRecursor (one program for each distinct list of values).
   2. The first population is drawn from the library by lexicase selection on the training terms.
   3. Variation runs a program backwards. A node is chosen. The targets and the values of the rest of the
      program give, for every training input, the interval in which the node's value must lie for the
      program to be right there. The library program inside most intervals replaces the node.
   4. A parent can first be given an operation with a missing operand, or be joined to a second parent
      under a missing condition. The missing part is found the same way.
   5. Lexicase selection on the training terms, then the smallest of the programs left, so a search that
      already reproduces every term goes on to shrink. One individual is kept per distinct behaviour.
      Fitness is the number of training terms reproduced.
   6. Two searches share the budget. One evolves closed programs of the input. The other evolves the step
      of a recurrence, a(i) from i, a(i-1), a(i-2), a(i-3) and a(floor(i/2)): a step is right at a position
      when it gives the recorded term from the recorded earlier terms. Of the two programs the one that
      reproduces most training terms is returned, and of equals the cheaper: a closed program costs its
      nodes, a recurrence its step, its initial terms as constants and one more, as in SynthesizeRecursor.
   improved.wl must be loaded first (for the completion by a scale and a shift). Needs the paclet source
   of 0.3.0, whose internal enumeration builds the libraries and whose recurrence form wraps a step. *)

$unbounded = 2^200;
setting[name_String, default_] := If[StringQ[Environment[name]], ToExpression[Environment[name]], default];
$guidedLibraryCost = setting["GUIDED_LIBRARY_COST", 6];
$guidedStepCost = setting["GUIDED_STEP_COST", 5];
$guidedSteps = setting["GUIDED_STEPS", 1] === 1;

classesOf[leaves_, maximum_, loops_] := With[{classes = WolframInstitute`Recursor`PackageScope`synthesisClasses[
		leaves, None, maximum, AbsoluteTime[] + 20, loops, False, None &]},
	With[{costs = Sort[Keys[classes["Expressions"]]]},
		<|"Programs" -> Catenate[classes["Expressions"] /@ costs], "Columns" -> Transpose[Catenate[classes["Vectors"] /@ costs]]|>
	]
]

(* closed programs of the input, with bounded loops *)
guidedLibrary[inputs_, maximum_] := classesOf[
	Join[{{Var, inputs}}, Table[{Const[c], ConstantArray[c, Length[inputs]]}, {c, 0, 3}]], maximum,
	<|"Bodies" -> WolframInstitute`Recursor`Synthesis`Synthesis`Private`loopBodies[3, 3, AbsoluteTime[] + 20], "Inputs" -> inputs, "MaxBody" -> 3|>
]

(* recurrence steps: at position j the leaves are the index and the recorded earlier terms *)
earlier = WolframInstitute`Recursor`PackageScope`synthesisEarlier;
halved = WolframInstitute`Recursor`PackageScope`synthesisHalved;
stepEnvironment[offset_, terms_] := With[{positions = Range[3, Length[terms] - 1]},
	<|"Index" -> offset + positions, "Earlier" -> Table[terms[[positions + 1 - k]], {k, 3}],
		"Halved" -> terms[[Clip[Quotient[offset + positions, 2] - offset + 1, {1, Length[terms]}]]]|>
]
stepLibrary[offset_, environment_, maximum_] := classesOf[
	Join[{{Idx, environment["Index"]}}, Table[{earlier[k], environment["Earlier"][[k]]}, {k, 3}],
		If[offset <= 1, {{halved, environment["Halved"]}}, {}],
		Table[{Const[c], ConstantArray[c, Length[environment["Index"]]]}, {c, 0, 3}]],
	maximum, None
]
stepSize[_Const | Idx | _earlier | halved] := 1
stepSize[expression_] := 1 + Total[stepSize /@ List @@ expression]

(* needed[head, k, {lo, hi}, others]: the interval in which argument k must lie, at every training input, for
   head[...] to lie in {lo, hi}, given the values of the other arguments. An interval with lo > hi is empty.
   Where the true set is not an interval, a part of it is given. *)
needed[Succ, 1, {lo_, hi_}, {}] := {Ramp[lo - 1], hi - 1}
needed[Pred, 1, {lo_, hi_}, {}] := {(lo + 1) Unitize[lo], hi + 1}
needed[Half, 1, {lo_, hi_}, {}] := {2 lo, 2 hi + 1}
needed[Add, _, {lo_, hi_}, {b_}] := {Ramp[lo - b], hi - b}
needed[Mul, _, {lo_, hi_}, {b_}] := With[{zero = 1 - Unitize[b], safe = b + (1 - Unitize[b])},
	{(1 - zero) Quotient[lo + safe - 1, safe] + zero Unitize[lo], (1 - zero) Quotient[hi, safe] + zero (1 - Unitize[lo]) $unbounded}
]
needed[Monus, 1, {lo_, hi_}, {b_}] := {(lo + b) Unitize[lo], hi + b}
needed[Monus, 2, {lo_, hi_}, {a_}] := {Ramp[a - hi], Unitize[lo] (a - lo) + (1 - Unitize[lo]) $unbounded}
needed[Quot, 1, {lo_, hi_}, {b_}] := With[{zero = 1 - Unitize[b]},
	{(1 - zero) lo b + zero Unitize[lo], (1 - zero) (hi b + b - 1) + zero (1 - Unitize[lo]) $unbounded}
]
needed[Quot, 2, {lo_, hi_}, {a_}] := {Quotient[a, hi + 1] + 1, Unitize[lo] Quotient[a, lo + (1 - Unitize[lo])] + (1 - Unitize[lo]) $unbounded}
(* Rem[x, 0] is x; otherwise the values below the divisor *)
needed[Rem, 1, {lo_, hi_}, {b_}] := With[{zero = 1 - Unitize[b]}, {lo, zero hi + (1 - zero) (hi - Ramp[hi - (b - 1)])}]
(* a divisor above a leaves a, which helps where a is wanted *)
needed[Rem, 2, {lo_, hi_}, {a_}] := With[{inside = UnitStep[a - lo] UnitStep[hi - a]}, {inside (a + 1) + (1 - inside), inside $unbounded}]
(* the condition: zero where only the zero branch is right, positive where only the other is *)
needed[Ifz, 1, {lo_, hi_}, {z_, p_}] := {1 - UnitStep[z - lo] UnitStep[hi - z], UnitStep[p - lo] UnitStep[hi - p] $unbounded}
needed[Ifz, 2, {lo_, hi_}, {c_, p_}] := With[{taken = 1 - Unitize[c], good = UnitStep[p - lo] UnitStep[hi - p]},
	{taken lo + (1 - taken) (1 - good), taken hi + (1 - taken) good $unbounded}
]
needed[Ifz, 3, {lo_, hi_}, {c_, z_}] := With[{taken = Unitize[c], good = UnitStep[z - lo] UnitStep[hi - z]},
	{taken lo + (1 - taken) (1 - good), taken hi + (1 - taken) good $unbounded}
]

(* Nodes reached from the root through operations that can be run backwards. They lie outside every
   binder, so each is a program of the same leaves. *)
openPaths[expression_, path_ : {}] := Join[{path},
	If[MatchQ[expression, (Succ | Pred | Half | Add | Mul | Monus | Quot | Rem | Ifz)[__]],
		Catenate[MapIndexed[openPaths[#1, Append[path, First[#2]]] &, List @@ expression]], {}]
]

(* The intervals for the node at a path, or None when a value beside the path is not a number. *)
desired[program_, path_, targets_, values_] := Module[{lo = targets, hi = targets, dead = 0 targets, node = program, others, known = True},
	Do[
		others = values /@ Delete[List @@ node, step];
		If[others =!= {} && ! MatrixQ[others, IntegerQ], known = False; Break[]];
		{lo, hi} = needed[Head[node], step, {lo, hi}, others];
		dead = Unitize[dead + UnitStep[lo - hi - 1]];
		lo = (1 - dead) lo;
		hi = (1 - dead) hi;
		node = node[[step]],
		{step, path}
	];
	If[known, {lo + dead, (1 - dead) hi}, None]
]

(* The program with the node at the path replaced by the library program inside most intervals; of several,
   one of the four cheapest. None when no library program helps at any training input. *)
repairAt[program_, path_, targets_, values_, library_] := Module[{need = desired[program, path, targets, values], scores, best, at},
	If[need === None, Return[None]];
	scores = Total[MapThread[UnitStep[#1 - #2] UnitStep[#3 - #1] &, {library["Columns"], First[need], Last[need]}]];
	best = Max[scores];
	If[best === 0, Return[None]];
	at = Flatten[Position[scores, best, {1}, 4, Heads -> False]];
	With[{part = library["Programs"][[RandomChoice[at]]]}, If[path === {}, part, ReplacePart[program, path -> part]]]
]

(* an operation around a parent, with the path of its missing operand *)
extensions = {{Add[#1, #2] &, {2}}, {Mul[#1, #2] &, {2}}, {Monus[#1, #2] &, {2}}, {Monus[#2, #1] &, {1}}, {Quot[#1, #2] &, {2}}, {Rem[#1, #2] &, {2}}};

(* One guided search. values gives the list of values of a program at the cases, size its size, finish a
   last change made to every new program. budget is {first programs, generations, children, elites}. *)
guidedSearch[targets_, library_, values_, size_, finish_, {first_, generations_, children_, elites_}, maximumSize_] := Module[{
	individual, rank, select, pick, breed, distinct, passes, population, best, history, proposals = 0, cases = Range[Length[targets]]
},
	individual[candidate_] := With[{program = finish[candidate]},
		proposals++;
		With[{passed = Boole[MapThread[SameQ, {values[program], targets}]]},
			<|"Program" -> program, "Values" -> values[program], "Size" -> size[program], "Passed" -> passed, "Matches" -> Total[passed]|>
		]
	];
	rank[one_] := {one["Matches"], -one["Size"]};
	select[pool_] := Module[{rest = pool},
		Do[
			With[{passing = Select[rest, #["Passed"][[case]] === 1 &]}, If[passing =!= {}, rest = passing]];
			If[Length[rest] === 1, Break[]],
			{case, RandomSample[cases]}
		];
		RandomChoice[MinimalBy[rest, #["Size"] &]]
	];
	(* lexicase selection in the library itself *)
	passes = Transpose[MapThread[1 - Unitize[#1 - #2] &, {library["Columns"], targets}]];
	pick[] := Module[{rest = Range[Length[passes]]},
		Do[
			With[{passing = Pick[rest, passes[[rest, case]], 1]}, If[passing =!= {}, rest = passing]];
			If[Length[rest] === 1, Break[]],
			{case, RandomSample[cases]}
		];
		library["Programs"][[RandomChoice[Take[rest, UpTo[3]]]]]
	];
	breed[pool_] := Module[{parent = select[pool]["Program"], child, choice = RandomReal[]},
		child = Which[
			choice < 0.45, repairAt[parent, RandomChoice[openPaths[parent]], targets, values, library],
			choice < 0.70, With[{form = RandomChoice[extensions]}, repairAt[First[form][parent, Const[1]], Last[form], targets, values, library]],
			choice < 0.80, repairAt[Ifz[Const[0], parent, select[pool]["Program"]], {1}, targets, values, library],
			True, With[{path = RandomChoice[openPaths[parent]], part = RandomChoice[Take[library["Programs"], UpTo[300]]]},
				If[path === {}, part, ReplacePart[parent, path -> part]]]
		];
		individual[If[child === None || size[child] > maximumSize, parent, child]]
	];
	distinct[pool_] := Values[GroupBy[ReverseSortBy[pool, rank], #["Values"] &, First]];
	population = distinct[individual /@ Take[DeleteDuplicates[Join[Table[pick[], first], Take[library["Programs"], UpTo[first]]]], UpTo[first]]];
	best = First[MaximalBy[population, rank]];
	history = {best["Matches"]};
	Do[
		population = distinct[Join[Take[ReverseSortBy[population, rank], UpTo[elites]], Table[breed[population], {children}]]];
		best = First[MaximalBy[Append[population, best], rank]];
		AppendTo[history, best["Matches"]],
		{generations}
	];
	<|"Best" -> best, "Population" -> ReverseSortBy[Append[population, best], rank], "History" -> history, "Proposals" -> proposals|>
]

guidedEvolve[examples_, options_, seed_] := BlockRandom[SeedRandom[seed]; Module[{
	inputs = examples[[All, 1]], targets = examples[[All, 2]], populationSize, generations, elites, maximumNodes, evaluationOptions,
	values, complete, closed, half, candidates, environment, stepValues, steps, score, chosen
},
	{populationSize, generations, elites, maximumNodes} = Lookup[options, {"PopulationSize", "MaxGenerations", "EliteCount", "MaxNodes"}];
	evaluationOptions = FilterRules[Normal[options], Options[EvaluateRecursor]];
	values[program_] := values[program] = Quiet[EvaluateRecursor[program, #, Sequence @@ evaluationOptions] & /@ inputs];
	complete[program_] := With[{fit = affineFit[values[program], targets]},
		If[fit === None || RecursorNodeCount[program] + 4 > maximumNodes, program, affineProgram[program, First[fit], Last[fit]]]
	];
	steps = $guidedSteps && Length[targets] >= 6 && inputs === Range[First[inputs], Last[inputs]];
	half = If[steps, Quotient[generations, 2], generations];
	closed = guidedSearch[targets, guidedLibrary[inputs, $guidedLibraryCost], values, RecursorNodeCount, complete,
		{populationSize, half, populationSize - elites, elites}, maximumNodes];
	candidates = {{closed["Best"]["Program"], closed["Best"]["Size"]}};
	If[steps,
		environment = stepEnvironment[First[inputs], targets];
		stepValues[step_] := stepValues[step] = Replace[
			WolframInstitute`Recursor`PackageScope`synthesisVectorValue[step, environment], scalar_Integer :> ConstantArray[scalar, Length[targets] - 3]];
		steps = guidedSearch[Drop[targets, 3], stepLibrary[First[inputs], environment, $guidedStepCost], stepValues, stepSize, Identity,
			{populationSize - elites, generations - half - 1, populationSize - elites, elites}, maximumNodes - 20];
		(* the steps right at most positions, as programs with their initial terms *)
		candidates = Join[candidates, Map[
			With[{seeds = WolframInstitute`Recursor`Synthesis`Recurrences`Private`stepSeeds[#, First[inputs], targets]},
				{WolframInstitute`Recursor`Synthesis`Recurrences`Private`recurrenceProgram[#, seeds, First[inputs], targets],
					stepSize[#] + Total[WolframInstitute`Recursor`PackageScope`synthesisConstantCost /@ Take[targets, seeds]] + 1}
			] &,
			Take[Select[steps["Population"], #["Matches"] === steps["Best"]["Matches"] &][[All, "Program"]], UpTo[3]]
		]]
	];
	candidates = Select[candidates, RecursorProgramQ[First[#]] && RecursorNodeCount[First[#]] <= maximumNodes &];
	score[{program_, cost_}] := {Count[MapThread[SameQ, {values[program], targets}], True], -cost};
	chosen = First[MaximalBy[candidates, score]];
	<|"Program" -> First[chosen], "Fitness" -> First[score[chosen]], "Cost" -> Last[chosen], "FitnessHistory" -> closed["History"],
		"StepHistory" -> If[AssociationQ[steps], steps["History"], {}],
		"Proposals" -> closed["Proposals"] + If[AssociationQ[steps], steps["Proposals"], 0]|>
]]
