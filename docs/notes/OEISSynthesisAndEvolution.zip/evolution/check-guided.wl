(* Brute-force check of the backward rules of guided.wl, and a few searches. *)
here = DirectoryName[$InputFileName];
PacletDirectoryLoad[FileNameJoin[{here, "..", "..", "Recursor"}]];
Needs["WolframInstitute`Recursor`"];
Get[FileNameJoin[{here, "improved.wl"}]];
Get[FileNameJoin[{here, "guided.wl"}]];
apply[head_, arguments_] := EvaluateRecursor[head @@ (Const /@ arguments), 0];
range = Range[0, 40];
exactForms = {{Succ, 1}, {Pred, 1}, {Half, 1}, {Add, 1}, {Add, 2}, {Mul, 1}, {Mul, 2}, {Monus, 1}, {Monus, 2}, {Quot, 1}, {Ifz, 1}, {Ifz, 2}, {Ifz, 3}};
soundForms = {{Quot, 2}, {Rem, 1}, {Rem, 2}};
arity[head_] := Switch[head, Succ | Pred | Half, 1, Ifz, 3, _, 2];
SeedRandom[7];
report = Table[
	Module[{head = form[[1]], k = form[[2]], unsound = 0, incomplete = 0, trials = 0},
		Do[
			Module[{others = RandomInteger[{0, 9}, arity[head] - 1], lo = RandomInteger[{0, 12}], hi, need, inside, good},
				hi = lo + RandomChoice[{0, 0, 1, 3, 50}];
				need = needed[head, k, {{lo}, {hi}}, List /@ others];
				inside = Select[range, need[[1, 1]] <= # <= need[[2, 1]] &];
				good = Select[range, lo <= apply[head, Insert[others, #, k]] <= hi &];
				trials++;
				If[! SubsetQ[good, inside], unsound++];
				If[! SubsetQ[inside, good], incomplete++]
			],
			{400}
		];
		{head, k, "trials" -> trials, "unsound" -> unsound, "incomplete" -> incomplete}
	],
	{form, Join[exactForms, soundForms]}
];
Print[Column[report]];
Print["exact forms sound and complete: ", AllTrue[Take[report, Length[exactForms]], #[[4, 2]] === 0 && #[[5, 2]] === 0 &],
	" | other forms sound: ", AllTrue[Drop[report, Length[exactForms]], #[[4, 2]] === 0 &]];
(* a whole path: the node inside a nested program *)
program = Add[Mul[Var, Half[Succ[Var]]], Monus[Const[3], Var]];
values[p_] := EvaluateRecursor[p, #] & /@ Range[0, 7];
targets = values[program];
Print["desired at the Var inside Half[Succ[Var]]: ", desired[program, {1, 2, 1, 1}, targets, values]];
(* searches *)
protocol = Import[FileNameJoin[{here, "..", "oeis-corpus-v1", "protocol.json"}], "RawJSON"];
Do[
	With[{examples = Transpose[{Range[0, 7], terms}]},
		Print[terms, "\n   guided: ", AbsoluteTiming[With[{r = guidedEvolve[examples, protocol["SearchOptions"], 9101]}, {r["Fitness"], r["Proposals"], FormatRecursor[r["Program"]], r["FitnessHistory"], r["StepHistory"]}]],
			"\n   improved: ", AbsoluteTiming[With[{r = improvedEvolve[examples, protocol["SearchOptions"], 9101]}, {r["Fitness"], FormatRecursor[r["Program"]]}]]]
	],
	{terms, {{0, 1, 3, 6, 10, 15, 21, 28}, {1, 2, 5, 10, 17, 26, 37, 50}, {1, 1, 2, 3, 5, 8, 13, 21}, {2, 3, 5, 7, 11, 13, 17, 19}, {1, 3, 7, 15, 31, 63, 127, 255},
		{0, 1, 1, 2, 1, 2, 2, 3}, {1, 5, 14, 30, 55, 91, 140, 204}, {3, 7, 13, 21, 31, 43, 57, 73}, {0, 2, 12, 36, 80, 150, 252, 392}}}
]
