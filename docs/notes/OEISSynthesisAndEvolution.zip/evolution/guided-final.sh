#!/bin/zsh
# The guided arm on the first 2,000 sequences. It waits for the twenty-term evolution arm of the queue to
# begin, so it does not run beside a synthesis arm, whose search is limited by the clock.
cd "${0:A:h}"
until grep -q "arm Improved | sequences 2000" queue.log; do sleep 10; done
GUIDED_LIBRARY_COST=6 wolframscript -file run.wls ../../Recursor guided-8.jsonl 1 2000 5 Guided 2>&1 | grep --line-buffered -v "shdw\|^From kernel\|^$\|General::stop" >> guided.log
echo "guided done $(date)" >> guided.log
