(* The guided method of the paclet against guided.wl on tuning sequences: same budget and seed. *)
here = DirectoryName[$InputFileName];
PacletDirectoryLoad[FileNameJoin[{here, "..", "..", "Recursor"}]];
Needs["WolframInstitute`Recursor`"];
Get[FileNameJoin[{here, "improved.wl"}]]; Get[FileNameJoin[{here, "guided.wl"}]];
protocol = Import[FileNameJoin[{here, "..", "oeis-corpus-v1", "protocol.json"}], "RawJSON"];
jobs = Take[Import[FileNameJoin[{here, "jobs.json"}], "RawJSON"], {20001, 20060}];
rows = Table[
	With[{terms = FromDigits /@ job["Terms"]}, With[{examples = Transpose[{job["Offset"] + Range[0, 7], Take[terms, 8]}], later = Transpose[{job["Offset"] + Range[8, 19], terms[[9 ;; 20]]}]},
		With[{old = guidedEvolve[examples, protocol["SearchOptions"], 9101]["Program"],
			new = EvolveRecursor[examples, Method -> "Guided", "RandomSeed" -> 9101, "PopulationSize" -> 24, "MaxGenerations" -> 20, "StopOnSolve" -> False, "MaxSteps" -> 2000, "TimeLimit" -> 1]["Program"]},
			{ScoreRecursor[old, examples], ScoreRecursor[new, examples], ScoreRecursor[old, later, "MaxSteps" -> 1000000, "TimeLimit" -> 5], ScoreRecursor[new, later, "MaxSteps" -> 1000000, "TimeLimit" -> 5], old === new}]]],
	{job, jobs}];
Print["sequences ", Length[rows], " | fitted old ", Count[rows[[All, 1]], 8], " new ", Count[rows[[All, 2]], 8], " | predicted old ", Count[rows, {8, _, 12, _, _}], " new ", Count[rows, {_, 8, _, 12, _}], " | same program ", Count[rows[[All, 5]], True]];
