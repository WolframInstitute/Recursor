#!/usr/bin/env python3
"""Write docs/notes/OEISCorpusExperimentV2.md from the exported measurements.

Every number in the note comes from docs/notes/data/OEISCorpusV2.json.gz, so
the note, the notebook and the database agree.

  python3 write_note.py
"""
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parent.parent
DATA = REPOSITORY / "docs" / "notes" / "data" / "OEISCorpusV2.json.gz"
NOTE = REPOSITORY / "docs" / "notes" / "OEISCorpusExperimentV2.md"


WILSON = ("Succ[Pred[Iter[Succ[Var], Const[0], Succ[WhileLoop[Acc, Let[Acc, Rem[Succ[Rec[Var, Const[1], "
          "Mul[Acc, Let[Succ[Idx], Var]]]], Succ[Var]]], Succ[Acc]]]]]]")
FERMAT = ("Pred[Iter[Succ[Var], Const[0], Succ[WhileLoop[Acc, Let[Let[Acc, Iter[Var, Var, Succ[Rem[Add[Acc, Acc], Var]]]], "
          "Add[Monus[Var, Const[1]], Monus[Const[1], Var]]], Succ[Acc]]]]]")


def n(value):
    return format(value, ",")


def percent(part, whole):
    return "%.2f%%" % (100.0 * part / whole) if whole else "–"


def main():
    with gzip.open(DATA, "rt") as handle:
        data = json.load(handle)
    eligible = data["Eligible"]
    v1 = data["V1"]
    p8, p20 = data["Protocols"]["P8"], data["Protocols"]["P20"]
    examples = {record["Key"]: record for record in data["Examples"]}
    if len(p8["Rounds"]) == len(p20["Rounds"]):
        rounds = "%d completed rounds per protocol" % len(p8["Rounds"])
    else:
        rounds = "%d completed rounds from eight terms and %d from twenty" % (len(p8["Rounds"]), len(p20["Rounds"]))

    lines = []
    add = lines.append
    add("# OEIS corpus experiment v2")
    add("")
    add("This study repeats the [corpus v1 experiment](OEISCorpusExperiment.md) on the")
    add("same pinned OEIS snapshot with a different search. Corpus v1 evolved 464")
    add("candidate programs per sequence. Corpus v2 enumerates programs once for the")
    add("whole corpus, checks recurrences against the data and solves for constants.")
    add("It uses two additions to the language, `Quot` and `Let`.")
    add("")
    add("These are checkpoint results after %s," % rounds)
    add("exported %s UTC. The campaign keeps running; later rounds add" % data["UpdatedUTC"][:16].replace("T", " "))
    add("sequences.")
    add("")
    add("| Of %s eligible sequences | Corpus v1 | Corpus v2 |" % n(eligible))
    add("| --- | ---: | ---: |")
    add("| Eight terms predict the next twelve | %s | %s |" % (n(v1["PrimaryFits"]), n(p8["TestFits"])))
    add("| …and every later recorded term | %s | %s |" % (n(v1["AllRecordedFits"]), n(p8["AllRecordedFits"])))
    add("| A program reproduces the first twenty terms | not measured | %s |" % n(p20["TrainingFits"]))
    add("| …and every later recorded term | not measured | %s |" % n(p20["AllRecordedFits"]))
    add("")
    add("The first row is the v1 criterion. Corpus v2 passes it for %s of the corpus," % percent(p8["TestFits"], eligible))
    add("%.1f times the v1 count and %.1f times the straight-line baseline of %s." % (
        p8["TestFits"] / v1["PrimaryFits"], p8["TestFits"] / v1["AffineBaseline"], n(v1["AffineBaseline"])))
    add("The figures are in [the results notebook](../../notebooks/Results-02.nb).")
    add("")
    add("## What changed")
    add("")
    add("**Language.** `Quot[a, b]` is the integer quotient. `Let[value, body]`")
    add("evaluates a body with a new input, so a closed program can be applied inside")
    add("another. Sums and products of a subprogram, the n-th number with a property")
    add("and compositions are then ordinary programs. Both constructs are in the")
    add("interpreter, the lambda compiler and the Lean models.")
    add("")
    add("**Search.** Four mechanisms replace evolution.")
    add("")
    add("- *One enumeration for all sequences.* Programs are listed by increasing")
    add("  cost. Two programs with the same values on the inputs 0 to 11 (0 to 23")
    add("  for twenty training terms) count as one, and only the cheapest is kept.")
    add("  Each kept program is looked up against every training window at once.")
    add("  Levels contain arithmetic, conditionals, bounded loops, compositions")
    add("  through `Let`, and transforms of earlier programs: partial sums and")
    add("  products, differences, the n-th number with a property and counts.")
    add("- *Recurrences checked against the data.* A step a(i) = F(i, a(i-1),")
    add("  a(i-2), a(i-3), a(⌊i/2⌋)) is evaluated on the recorded earlier terms at")
    add("  each training position. No candidate is run from its start. Initial")
    add("  terms are read from the data; extra initial terms absorb exceptions.")
    add("- *Exact solving.* Linear algebra modulo a prime finds integer")
    add("  coefficients of recurrences with polynomial coefficients, periodic")
    add("  increments, polynomials and constant tails. Spare training terms must")
    add("  confirm each solution.")
    add("- *A library.* Subprograms shared by the selected programs of several")
    add("  windows, and recurrences found for single windows, become building")
    add("  blocks of the next round. Odd rounds search deeper without the library;")
    add("  even rounds search with it.")
    add("")
    add("**Cost and selection.** Each window keeps the cheapest program found. Cost")
    add("counts the syntax nodes the search chose. A constant up to three costs one")
    add("node and every further two bits cost one more, so initial terms and solved")
    add("constants pay for what they say. A window that has a program keeps it in")
    add("later rounds.")
    add("")
    add("**Two protocols.** P8 is the v1 protocol: search sees eight terms and the")
    add("next twelve are the test. P20 gives search the first twenty terms and tests")
    add("every later recorded term. Eight terms often admit a cheaper explanation")
    add("than the intended one; twenty terms rarely do.")
    add("")
    add("**Isolation.** The search program reads a file that holds training terms")
    add("only. Wolfram kernels then evaluate every proposed program with")
    add("`EvaluateRecursor` and compare it with the recorded terms. Validation")
    add("outcomes never choose programs, build the library or set parameters.")
    add("")
    add("## Data and criteria")
    add("")
    add("The snapshot, the eligibility rule and the %s eligible sequences are those" % n(eligible))
    add("of corpus v1. Each input is the original OEIS index. A sequence counts in")
    add("P8 when its program reproduces the eight training terms and the next twelve.")
    add("It counts as represented in P20 when its program reproduces the first twenty")
    add("terms, and as validated when the program also reproduces every later")
    add("recorded term. Sequences that share a training window share a program and")
    add("are checked separately; they are not independent evidence.")
    add("")
    add("## Results")
    add("")
    for name, entry, label in (("P8", p8, "eight"), ("P20", p20, "twenty")):
        add("### From %s terms" % label)
        add("")
        add("%s sequences have a program that reproduces their training terms, from" % n(entry["TrainingFits"]))
        add("%s distinct training windows and %s distinct programs." % (n(entry["Windows"]), n(entry["DistinctPrograms"])))
        if entry["TestTerms"]:
            add("%s pass the twelve-term test and %s of the %s with later terms reproduce" % (
                n(entry["TestFits"]), n(entry["AllRecordedFits"]), n(entry["WithLaterTerms"])))
            add("every recorded term.")
        else:
            add("%s of the %s with later recorded terms reproduce every one of them." % (n(entry["AllRecordedFits"]), n(entry["WithLaterTerms"])))
        add("")
        passing = "Pass the twelve-term test" if entry["TestTerms"] else "Reproduce every later term"
        add("| Method | Reproduce training terms | %s | Share |" % passing)
        add("| --- | ---: | ---: | ---: |")
        for method in entry["Methods"]:
            add("| %s | %s | %s | %s |" % (method["Method"], n(method["TrainingFits"]), n(method["TestFits"]), percent(method["TestFits"], method["TrainingFits"])))
        add("")
        add("| Round | Library blocks | Search (s) | Validation (s) | Programs proposed | Reproduce training terms | %s |" % passing)
        add("| ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
        for entry_round in entry["Rounds"]:
            add("| %d | %s | %.0f | %.0f | %s | %s | %s |" % (
                entry_round["Round"], n(entry_round["Library"]) if entry_round["Library"] else "none", entry_round["SearchSeconds"],
                entry_round["ValidationSeconds"], n(entry_round["Proposed"]), n(entry_round["TrainingFits"]), n(entry_round["TestFits"])))
        add("")
    add("The columns after the proposals count sequences; several sequences can")
    add("share a training window and its program. Linear, Hypergeometric and")
    add("Holonomic are recurrences with solved coefficients; Recurrence is an")
    add("enumerated step; Closed is an enumerated program without solved constants;")
    add("Affine adds a solved scale and shift. Polynomial, Periodic and Tail are")
    add("solved polynomials, periodic increments and constant tails. Solved")
    add("constants almost always hold on later terms. Enumerated fits to eight")
    add("terms often do not: many windows have a cheap explanation that is not the")
    add("sequence's rule.")
    add("")
    windows = p8["ProposedNotReproduced"] + p20["ProposedNotReproduced"]
    proposed = sum(r["Proposed"] for r in p8["Rounds"]) + sum(r["Proposed"] for r in p20["Rounds"])
    uncounted = proposed - sum(r["Reproduced"] for r in p8["Rounds"]) - sum(r["Reproduced"] for r in p20["Rounds"])
    reasons = {}
    for entry in (p8, p20):
        for reason, amount in entry["NotReproducedReasons"].items():
            reasons[reason] = reasons.get(reason, 0) + amount
    budget = {"StepLimit": "the step limit", "TimeLimit": "the time limit", "MemoryLimit": "the memory limit",
              "ValidationTimeLimit": "the time allowed per program"}
    if uncounted == 0:
        add("The search program and the reference interpreter agree. All %s programs" % n(proposed))
        add("the search proposed reproduced their training terms when the interpreter")
        add("evaluated them.")
    elif all(reason in budget for reason in reasons):
        add("The search program and the reference interpreter never returned different")
        add("values. Of %s proposals over all rounds, %s reproduced their" % (n(proposed), n(proposed - uncounted)))
        add("training terms when the interpreter evaluated them. The other %s, for" % n(uncounted))
        add("%s training windows, reached %s of the interpreter" % (n(windows), " or ".join(budget[reason] for reason in sorted(reasons))))
        add("on a training term. They are not counted, and their windows stay open for")
        add("later rounds.")
    else:
        add("Of %s proposals over all rounds, %s did not reproduce their training" % (n(proposed), n(uncounted)))
        add("terms when the reference interpreter evaluated them. The %s windows still" % n(windows))
        add("open record these reasons: %s." % ", ".join("%s %s" % (reason, n(amount)) for reason, amount in sorted(reasons.items())))
        add("They are not counted, and their windows stay open for later rounds.")
    add("")
    add("### Development and evaluation splits")
    add("")
    add("One sequence in five, chosen by a hash of its identifier, was used for")
    add("diagnostics while the method was built. The other four fifths were not.")
    add("")
    add("| Split | Sequences | P8 held-out test | P20 every later term |")
    add("| --- | ---: | ---: | ---: |")
    for split in ("Evaluation", "Development"):
        a, b = p8["Splits"][split], p20["Splits"][split]
        add("| %s | %s | %s (%s) | %s (%s) |" % (split, n(a["Sequences"]), n(a["TestFits"]), percent(a["TestFits"], a["Sequences"]),
                                               n(b["AllRecordedFits"]), percent(b["AllRecordedFits"], b["Sequences"])))
    add("")
    add("Before the split existed, the first prototypes were scored by aggregate")
    add("held-out counts over the whole corpus, to decide whether enumeration, loops")
    add("and recurrences were worth building. No per-sequence outcome outside the")
    add("development split was inspected and no parameter was tuned on it.")
    add("")
    add("## Programs worth reading")
    add("")

    def reproduced(key):
        record = examples[key]
        total = len(record["Terms"])
        return "all %d recorded terms" % total if record["TermsReproduced"] == total else "%d of %d recorded terms" % (record["TermsReproduced"], total)

    # The descriptions below belong to these programs. A different selection
    # needs a different description, so the texts are checked.
    described = {
        "A000040": WILSON,
        "A000040-P20": FERMAT,
        "A000960": "Succ[Rec[Var, Pred[Var], Add[Acc, Quot[Acc, Monus[Var, Idx]]]]]",
        "A000203": ("Let[Pred[Var], Monus[Let[Succ[Var], Rec[Var, Mul[Var, Var], Succ[Monus[Acc, Rem[Var, Idx]]]]], "
                    "Rec[Var, Mul[Var, Var], Succ[Monus[Acc, Rem[Var, Idx]]]]]]"),
        "A002110": "Rec[Var, Const[1], Mul[Acc, Let[Succ[Idx], %s]]]" % WILSON,
    }
    for key, program in described.items():
        if key in examples and examples[key]["Program"] != program:
            raise SystemExit("the program selected for %s changed; revise its description in write_note.py" % key)
    if "A000040" in examples:
        add("- **Primes from eight terms (A000040).** The selected program returns the")
        add("  n-th m + 1 such that m + 1 divides m! + 1. That is Wilson's theorem, so")
        add("  the program is exact. It reproduces %s." % reproduced("A000040"))
    if "A000040-P20" in examples:
        add("- **Primes from twenty terms.** The selected program tests m by iterating")
        add("  x → 2x mod m + 1. It is Fermat's test in base 2. It reproduces")
        add("  %s and the first 68 primes, then returns" % reproduced("A000040-P20"))
        add("  341 = 11 × 31. Agreement on every recorded term is evidence, not proof.")
    if "A000005" in examples:
        add("- **Number of divisors (A000005).** The difference of two sums of")
        add("  quotients, the identity tau(n) = D(n) - D(n-1). It reproduces")
        add("  %s." % reproduced("A000005"))
    if "A018252" in examples:
        add("- **Nonprime numbers (A018252).** The numbers m that divide the product of")
        add("  ⌈k/2⌉ for k up to m. It reproduces %s." % reproduced("A018252"))
    if "A000960" in examples:
        add("- **Flavius Josephus's sieve (A000960).** A program of %d nodes carries the" % examples["A000960"]["Nodes"])
        add("  index n - 1 back through the sieving steps, j → j + ⌊j/d⌋ for d = n, …, 1.")
        add("  It reproduces %s." % reproduced("A000960"))
    if "A000203" in examples:
        add("- **Sum of divisors (A000203).** Found with the library: sigma(n) = S(n) -")
        add("  S(n-1), where S(m) is m² minus the remainders of m by the numbers below")
        add("  it. It reproduces %s." % reproduced("A000203"))
    if "A001223" in examples:
        add("- **Prime gaps (A001223).** The difference of two copies of a third prime")
        add("  program, which tests m by trial division. The recorded gaps reach past")
        add("  341, where Fermat's test in base 2 fails. It reproduces")
        add("  %s." % reproduced("A001223"))
    if "A002110" in examples:
        add("- **Primorial numbers (A002110).** The product of the first n primes, each")
        add("  computed by the Wilson program that round 1 found for the primes. It")
        add("  reproduces %s." % reproduced("A002110"))
    recurrences = [(key, name) for key, name in (("A000108", "Catalan"), ("A001006", "Motzkin"), ("A005258", "Apéry"), ("A001181", "Baxter")) if key in examples]
    if recurrences:
        add("- **%s numbers.** Recurrences with polynomial" % ", ".join(name for _, name in recurrences).replace(", Baxter", " and Baxter"))
        add("  coefficients, recovered with their coefficients (%s)." % ", ".join(key for key, _ in recurrences))
    add("")
    add("## Limits")
    add("")
    add("- Sequences defined through decimal digits, tables read by rows and")
    add("  digits of constants are almost untouched. Eight or twenty terms of a")
    add("  digit-based sequence often do not reach a second digit.")
    add("- The search program keeps machine integers. A sequence whose training")
    add("  terms exceed 2^62 is out of reach, and a program whose intermediate")
    add("  values overflow is not proposed. The reference interpreter has no such")
    add("  limit.")
    add("- From eight terms, the cheapest program is often not the sequence's")
    add("  rule. The prime-counting function agrees with ⌊(n+1)/2⌋ mod n on its")
    add("  first eight terms.")
    add("- A validation budget failure is recorded with its tag and counts as not")
    add("  reproduced. It never establishes nontermination.")
    add("- Cost is the search's own measure, not `RecursorNodeCount`. Both are")
    add("  recorded.")
    add("")
    add("## Reproducibility")
    add("")
    add("The experiment is in `build/oeis-corpus-v2`. [The experiment archive](OEISCorpusExperimentV2.zip)")
    add("holds its code: the search program in Rust, the controller, the validation")
    add("worker, the dashboard, the protocol and the notebook builder. Its README")
    add("gives the commands. `python3 run.py start` launches the campaign and a")
    add("dashboard at http://127.0.0.1:8765/; no supervision is needed.")
    add("")
    add("`results.sqlite3` records the program of every training window and the")
    add("checks of every sequence. [The exported measurements](data/OEISCorpusV2.json.gz)")
    add("are the numbers in this note and in the notebook. The code hash at export")
    add("was `%s`." % data["CodeSHA256"])
    add("")
    add("OEIS data are copyright the OEIS Foundation Inc. and contributors, under")
    add("CC BY-SA 4.0. The experiment code follows Recursor's MIT license.")
    add("")
    NOTE.write_text("\n".join(lines))
    print("wrote", NOTE)


if __name__ == "__main__":
    main()
