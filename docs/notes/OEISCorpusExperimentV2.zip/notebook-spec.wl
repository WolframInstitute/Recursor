(* Content of notebooks/Results-02.nb: {kind, content} in reading order.
   Captions take their numbers from the exported measurements. *)
Module[{data, p8, p20, v1, n = 0, figure, count, listing, words, example, failure, records},
	data = Import[dataFile, {"GZIP", "RawJSON"}];
	{p8, p20} = Lookup[data["Protocols"], {"P8", "P20"}];
	v1 = data["V1"];
	records = Association[#Key -> # & /@ Join[data["Examples"], data["Failures"]]];
	count[x_] := ToString[NumberForm[x, DigitBlock -> 3, NumberSeparator -> ","]];
	figure[text_] := {"Text", "Figure " <> ToString[++n] <> ". " <> text};
	(* The sequences shown, with a heading and what each program computes. *)
	listing = Import[FileNameJoin[{buildRoot, "notebook-examples.json"}], "RawJSON"];
	words[8] = "eight"; words[20] = "twenty";
	example[item_] := With[{id = item["Key"], heading = item["Heading"], shown = item["Shown"], note = item["Note"], lambda = item["Lambda"],
			record = records[item["Key"]], all = Length[records[item["Key"]]["Terms"]]}, Join[
		{
			{"Subsubsection", heading},
			{"Input", "program[\"" <> id <> "\"]"}
		},
		If[record["Nodes"] <= 40, {
			{"Input", "RecursorProgramTree[program[\"" <> id <> "\"]]"},
			figure["Program found for " <> record["ID"] <> " from " <> words[record["TrainingTerms"]] <> " terms: " <> note]
		}, {
			{"Text", "Found for " <> record["ID"] <> " from " <> words[record["TrainingTerms"]] <> " terms: " <> note}
		}],
		{
			{"Input", "predictionPlot[\"" <> id <> "\", " <> ToString[shown] <> "]"},
			figure[record["ID"] <> ": " <> If[record["TermsReproduced"] === all, "all " <> ToString[all] <> " recorded terms are reproduced", ToString[record["TermsReproduced"]] <> " of " <> ToString[all] <> " recorded terms are reproduced"] <>
				If[shown < all, "; the first " <> ToString[shown] <> " are shown.", "."] <> " The vertical line ends the training terms."]
		},
		If[lambda, {
			{"Input", "LambdaTree[CompileRecursor[program[\"" <> id <> "\"]], PlotTheme -> \"Minimal\"]"},
			figure["Compiled lambda tree for " <> record["ID"] <> "."]
		}, {}]
	]];
	failure[item_] := {
		{"Input", "predictionPlot[\"" <> item["Key"] <> "\", " <> ToString[item["Shown"]] <> "]"},
		figure[records[item["Key"]]["ID"] <> ": " <> item["Note"]]
	};
	Join[
		{
			{"Section", "Code"},
			{"Code", {
				"repository = ParentDirectory[NotebookDirectory[]];",
				"PacletDirectoryLoad[FileNameJoin[{repository, \"Recursor\"}]];",
				"Needs[\"WolframInstitute`Recursor`\"];",
				"Needs[\"Wolfram`Lambda`\"];",
				"data = Import[FileNameJoin[{repository, \"docs\", \"notes\", \"data\", \"OEISCorpusV2.json.gz\"}], {\"GZIP\", \"RawJSON\"}];",
				"{p8, p20} = Lookup[data[\"Protocols\"], {\"P8\", \"P20\"}];",
				"v1 = data[\"V1\"];",
				"records = Association[(#Key -> Join[#, <|\"Terms\" -> FromDigits /@ #Terms, \"Program\" -> ParseRecursor[#Program]|>] &) /@ Join[data[\"Examples\"], data[\"Failures\"]]];",
				"program[id_] := records[id][\"Program\"];",
				"share[count_] := N[100 count/data[\"Eligible\"]];",
				"cumulative[protocol_, key_] := Accumulate[Lookup[protocol[\"Rounds\"], key]];",
				"passing[protocol_] := Association[(#Method -> 100. #TestFits/Max[1, #TrainingFits] &) /@ protocol[\"Methods\"]];",
				"computed[id_, amount_] := Table[EvaluateRecursor[program[id], n, \"MaxSteps\" -> 5000000, \"TimeLimit\" -> 20], {n, records[id][\"Offset\"], records[id][\"Offset\"] + amount - 1}] /. _Failure -> Missing[];",
				"predictionPlot[id_, count_ : All] := Module[{record = records[id], amount, inputs, observed}, amount = If[count === All, Length[record[\"Terms\"]], Min[count, Length[record[\"Terms\"]]]]; inputs = Range[record[\"Offset\"], record[\"Offset\"] + amount - 1]; observed = Take[record[\"Terms\"], amount]; If[Max[observed] > 200 Max[1, Median[observed]], ListLogPlot, ListPlot][{Transpose[{inputs, observed}], Transpose[{inputs, computed[id, amount]}]}, Joined -> {True, False}, PlotMarkers -> {{\"\\[FilledCircle]\", 7}, {\"\\[EmptySquare]\", 13}}, PlotLegends -> {\"OEIS\", \"Recursor\"}, Frame -> True, FrameLabel -> {\"Index n\", \"a(n)\"}, PlotLabel -> record[\"ID\"], GridLines -> {{record[\"Offset\"] + record[\"TrainingTerms\"] - 0.5}, None}, PlotRange -> All]];"
			}},
			{"Section", "Init"},
			{"Input", "metrics = <|\"Eligible\" -> data[\"Eligible\"], \"V1Predicted\" -> v1[\"PrimaryFits\"], \"V2Predicted\" -> p8[\"TestFits\"], \"Gain\" -> N[p8[\"TestFits\"]/v1[\"PrimaryFits\"]], \"V2PredictedPercent\" -> share[p8[\"TestFits\"]], \"V2PredictedEveryTerm\" -> p8[\"AllRecordedFits\"], \"Represented\" -> p20[\"TrainingFits\"], \"RepresentedPercent\" -> share[p20[\"TrainingFits\"]], \"RepresentedEveryLaterTerm\" -> p20[\"AllRecordedFits\"]|>"},

			{"Section", "Results"},
			{"Input", "BarChart[{{v1[\"PrimaryFits\"], p8[\"TestFits\"]}, {v1[\"AllRecordedFits\"], p8[\"AllRecordedFits\"]}}, ChartLabels -> {{\"Eight training +\\ntwelve test terms\", \"Every recorded\\nterm\"}, None}, ChartLegends -> {\"Corpus v1\", \"Corpus v2\"}, LabelingFunction -> Above, AxesLabel -> {None, \"OEIS entries\"}]"},
			figure["From eight terms, Recursor now predicts the next twelve for " <> count[p8["TestFits"]] <> " sequences. Corpus v1 predicted " <> count[v1["PrimaryFits"]] <> "."],
			{"Input", "BarChart[{v1[\"ConstantBaseline\"], v1[\"PrimaryFits\"], v1[\"AffineBaseline\"], p8[\"TestFits\"]}, ChartLabels -> {\"Constant\\nbaseline\", \"Recursor v1\", \"Affine\\nbaseline\", \"Recursor v2\"}, LabelingFunction -> Above, AxesLabel -> {None, \"Training and test fits\"}]"},
			figure["Corpus v1 stayed below a straight-line baseline of " <> count[v1["AffineBaseline"]] <> ". Corpus v2 is " <> ToString[Round[p8["TestFits"]/v1["AffineBaseline"], 0.1]] <> " times above it."],
			{"Input", "BarChart[Round[share /@ {p20[\"TrainingFits\"], p20[\"AllRecordedFits\"], p8[\"TestFits\"], v1[\"PrimaryFits\"]}, 0.01], BarOrigin -> Left, ChartLabels -> {\"v2: 20 terms\", \"v2: 20 terms and every later term\", \"v2: 8 terms and the next 12\", \"v1: 8 terms and the next 12\"}, LabelingFunction -> After, AxesLabel -> {\"Eligible sequences (%)\", None}]"},
			figure["Share of the " <> count[data["Eligible"]] <> " eligible sequences. From twenty terms, " <> count[p20["TrainingFits"]] <> " sequences have a program."],
			{"Input", "BarChart[Lookup[p20, {\"TrainingFits\", \"WithLaterTerms\", \"AllRecordedFits\"}], ChartLabels -> {\"First twenty\\nterms\", \"Later terms\\nrecorded\", \"Every later\\nterm\"}, LabelingFunction -> Above, AxesLabel -> {None, \"OEIS entries\"}]"},
			figure["Of " <> count[p20["WithLaterTerms"]] <> " programs found from twenty terms whose sequences record later terms, " <> count[p20["AllRecordedFits"]] <> " reproduce every later term."],
			{"Input", "BarChart[Reverse[Lookup[p8[\"Methods\"], \"TestFits\"]], BarOrigin -> Left, ChartLabels -> Reverse[Lookup[p8[\"Methods\"], \"Method\"]], LabelingFunction -> After, AxesLabel -> {\"Sequences\", None}]"},
			figure["Sequences predicted from eight terms, by the method that found the program."],
			{"Input", "BarChart[Reverse[Lookup[p20[\"Methods\"], \"AllRecordedFits\"]], BarOrigin -> Left, ChartLabels -> Reverse[Lookup[p20[\"Methods\"], \"Method\"]], LabelingFunction -> After, AxesLabel -> {\"Sequences\", None}]"},
			figure["Sequences found from twenty terms that reproduce every later term, by method."],
			{"Input", "BarChart[Reverse[Transpose[{Lookup[passing[p8], Keys[passing[p20]], 0], Values[passing[p20]]}]], BarOrigin -> Left, ChartLabels -> {Reverse[Keys[passing[p20]]], None}, ChartLegends -> {\"From 8 terms\", \"From 20 terms\"}, AxesLabel -> {\"Training fits that pass (%)\", None}]"},
			figure["How often a program that fits its training terms also passes the held-out test. Solved constants hold; enumerated fits to eight terms often do not."],
			{"Input", "BarChart[Rest[Transpose[{Lookup[p8[\"Rounds\"], \"TestFits\"], Lookup[p20[\"Rounds\"], \"TrainingFits\"], Lookup[p20[\"Rounds\"], \"AllRecordedFits\"]}]], ChartLabels -> {Table[\"Round \" <> ToString[round], {round, 2, Length[p8[\"Rounds\"]]}], None}, ChartLegends -> {\"8 terms and the next 12\", \"20 terms\", \"20 terms and every later term\"}, LabelingFunction -> Above, AxesLabel -> {None, \"Sequences added\"}]"},
			figure["Sequences added after round 1, which finds " <> count[p8["Rounds"][[1, "TestFits"]]] <> ", " <> count[p20["Rounds"][[1, "TrainingFits"]]] <> " and " <> count[p20["Rounds"][[1, "AllRecordedFits"]]] <> ". Even rounds reuse subprograms found earlier as building blocks; odd rounds search deeper."],
			{"Input", "With[{costs = Select[p8[\"Costs\"], #Cost <= 16 &]}, BarChart[Lookup[costs, {\"TrainingFits\", \"TestFits\"}], ChartLabels -> {Lookup[costs, \"Cost\"], None}, ChartLegends -> {\"Training fit\", \"Training + test\"}, AxesLabel -> {\"Cost\", \"Sequences\"}]]"},
			figure["Program cost for fits to eight terms. Cheap programs keep predicting; costly fits rarely do."],
			{"Input", "BarChart[p8[\"HeldOutAgreement\"], ChartLabels -> Range[0, 12], Frame -> True, FrameLabel -> {\"Test terms reproduced before the first failure\", \"Training-fitting programs\"}]"},
			figure["How many of the next twelve terms each eight-term fit reproduces. " <> count[Last[p8["HeldOutAgreement"]]] <> " programs reproduce all twelve."],
			{"Input", "ListLinePlot[{100. p8[\"Horizon\"][\"Agree\"]/p8[\"Horizon\"][\"Cohort\"], 100. p20[\"Horizon\"][\"Agree\"]/p20[\"Horizon\"][\"Cohort\"]}, DataRange -> {0, 40}, PlotLegends -> {\"Found from 8 terms\", \"Found from 20 terms\"}, Frame -> True, FrameLabel -> {\"Terms beyond training\", \"Programs still agreeing (%)\"}, PlotRange -> {0, 100}]"},
			figure["Programs whose sequences record at least forty later terms: the share that reproduces every term up to each distance."],
			{"Input", "BarChart[Transpose[{100. Lookup[p8[\"Keywords\"], \"TestFits\"]/Lookup[p8[\"Keywords\"], \"Sequences\"], 100. Lookup[p20[\"Keywords\"], \"TestFits\"]/Lookup[p20[\"Keywords\"], \"Sequences\"]}], ChartLabels -> {Lookup[p8[\"Keywords\"], \"Keyword\"], None}, ChartLegends -> {\"8 terms, next 12\", \"20 terms, all later\"}, AxesLabel -> {None, \"Sequences with the keyword (%)\"}]"},
			figure["Share of each OEIS keyword's sequences that pass. Digit-based sequences (base), tables (tabl) and constants (cons) stay out of reach."],
			{"Input", "BarChart[{(100. #TestFits/#Sequences &) /@ Lookup[p8[\"Splits\"], {\"Evaluation\", \"Development\"}], (100. #AllRecordedFits/#Sequences &) /@ Lookup[p20[\"Splits\"], {\"Evaluation\", \"Development\"}]}, ChartLabels -> {{\"8 terms, next 12\", \"20 terms, all later\"}, None}, ChartLegends -> {\"Evaluation split\", \"Development split\"}, AxesLabel -> {None, \"Sequences passing (%)\"}]"},
			figure["The development split, used for diagnostics while the method was built, and the untouched evaluation split agree."]
		},
		Catenate[Function[section, Join[{{"Section", section["Title"]}}, Catenate[example /@ section["Examples"]]]] /@ listing["Sections"]],
		{
			{"Section", "Three programs for the primes"},
			{"Input", "program[\"A000040-P20\"]"},
			{"Text", "From twenty terms the search selects a different program for the primes than from eight."},
			{"Input", "test = First[Cases[program[\"A000040-P20\"], Let[Acc, inner_] :> inner, Infinity]]"},
			{"Input", "accepted = Select[Range[2, 700], EvaluateRecursor[test, #] === 1 &];"},
			{"Input", "NumberLinePlot[{Select[accepted, PrimeQ], Select[accepted, ! PrimeQ[#] &]}, PlotLegends -> {\"Prime\", \"Composite\"}]"},
			figure["Numbers below 700 that the test inside the twenty-term program accepts: every prime and three composites, 341, 561 and 645. The search found Fermat's test in base 2."],
			{"Input", "ListPlot[Table[EvaluateRecursor[program[\"A000040-P20\"], n, \"MaxSteps\" -> 20000000, \"TimeLimit\" -> 60], {n, 60, 72}] - Prime[Range[60, 72]], DataRange -> {60, 72}, Filling -> Axis, Frame -> True, FrameLabel -> {\"Index n\", \"Program minus prime(n)\"}]"},
			figure["The twenty-term program gives the first 68 primes, ten more than the OEIS entry records, and then returns 341 = 11 × 31. Agreement on every recorded term is evidence, not proof."],
			{"Input", "Table[EvaluateRecursor[program[\"A000040\"], n], {n, 60, 72}] === Prime[Range[60, 72]]"},
			{"Text", "The eight-term program rests on Wilson's theorem and stays exact."},
			{"Input", "trial = Last[program[\"A001223\"]]"},
			{"Input", "Table[EvaluateRecursor[trial, n], {n, 60, 72}] === Prime[Range[60, 72]]"},
			{"Text", "The prime gaps subtract two copies of a third program, which tests by trial division. It is exact too."},

			{"Section", "Predictions that fail"}
		},
		Catenate[failure /@ listing["Failures"]],
		{
			{"Section", "Search effort"},
			{"Input", "BarChart[{Lookup[p8[\"Rounds\"], \"SearchSeconds\"], Lookup[p20[\"Rounds\"], \"SearchSeconds\"]}, ChartLabels -> {{\"8 terms\", \"20 terms\"}, None}, ChartLegends -> Table[\"Round \" <> ToString[round], {round, Length[p8[\"Rounds\"]]}], LabelingFunction -> (Placed[Round[#], Above] &), AxesLabel -> {None, \"Search time per round (s)\"}]"},
			figure["Search time of each round on twelve threads. One enumeration serves every sequence; corpus v1 ran " <> count[v1["Searches"]] <> " separate searches of " <> count[v1["Candidates"]] <> " candidates."],
			{"Input", "BarChart[{Lookup[p8[\"Rounds\"], \"ValidationSeconds\"], Lookup[p20[\"Rounds\"], \"ValidationSeconds\"]}/60., ChartLabels -> {{\"8 terms\", \"20 terms\"}, None}, ChartLegends -> Table[\"Round \" <> ToString[round], {round, Length[p8[\"Rounds\"]]}], LabelingFunction -> (Placed[NumberForm[#, {4, 1}], Above] &), AxesLabel -> {None, \"Validation time per round (min)\"}]"},
			figure["Time to check every proposed program with the reference interpreter on twelve kernels."]
		}
	]
]
