#!/usr/bin/env python3
"""Monitoring dashboard for the Recursor OEIS corpus v2 campaign.

Serves dashboard.html and a read-only JSON API over results.sqlite3 and
state/status.json on http://127.0.0.1:8765/. Standard library only.

  python3 serve.py [--port 8765] [--host 127.0.0.1]
"""
import argparse
import json
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
DB = ROOT / "results.sqlite3"
V1 = {"held_out": 876, "all_terms": 130, "training": 8626, "label": "corpus v1 (evolutionary search)"}


def database():
    connection = sqlite3.connect("file:%s?mode=ro" % DB, uri=True, timeout=30)
    connection.row_factory = sqlite3.Row
    return connection


def read_status():
    path = ROOT / "state" / "status.json"
    if not path.exists():
        return {"state": "Not started"}
    try:
        status = json.loads(path.read_text())
    except ValueError:
        return {"state": "Unknown"}
    # A controller that stopped without saying so is reported as stale.
    if status.get("state") in ("Running", "Loading", "Starting") and time.time() - status.get("updated", 0) > 6 * 3600:
        status["state"] = "Stale"
    return status


def overview():
    if not DB.exists():
        return {"status": read_status(), "ready": False}
    db = database()
    protocol = json.loads(db.execute("select value from meta where key='protocol'").fetchone()[0])
    eligible = db.execute("select count(*) from sequences").fetchone()[0]
    tracks = {}
    for track, spec in protocol["Tracks"].items():
        row = db.execute(
            """select count(*) n, coalesce(sum(test_ok), 0) test, coalesce(sum(extended_ok), 0) extended,
                      coalesce(sum(extended_ok is not null), 0) later, coalesce(sum(test_ok is not null), 0) testable
               from outcomes where track=? and train_ok=1""", (track,)).fetchone()
        split = {}
        for name, flag in (("development", 1), ("evaluation", 0)):
            part = db.execute(
                """select count(*) n, coalesce(sum(o.test_ok), 0) test, coalesce(sum(o.extended_ok), 0) extended
                   from outcomes o join sequences s on s.id=o.id where o.track=? and o.train_ok=1 and s.dev=?""", (track, flag)).fetchone()
            size = db.execute("select count(*) from sequences where dev=?", (flag,)).fetchone()[0]
            split[name] = {"sequences": size, "training": part["n"], "held_out": part["test"], "all_terms": part["extended"]}
        tracks[track] = {
            "title": spec["Title"], "training_terms": spec["TrainingTerms"], "primary_terms": spec["PrimaryHeldOutTerms"],
            "criterion": spec["Criterion"], "training": row["n"], "held_out": row["test"], "all_terms": row["extended"],
            "with_later_terms": row["later"], "testable": row["testable"], "split": split,
            "windows": db.execute("select count(*) from selections where track=? and train_ok=1", (track,)).fetchone()[0],
        }
    rounds = [dict(row) for row in db.execute(
        """select track, round, state, started, finished, engine_seconds, validation_seconds, proposed, library, config
           from rounds order by started""")]
    for entry in rounds:
        entry["config"] = json.loads(entry["config"]) if entry["config"] else None
        # Live totals from the record, also for a round that is still validating.
        row = db.execute(
            "select count(*), coalesce(sum(test_ok), 0), coalesce(sum(extended_ok), 0) from outcomes where track=? and round=? and train_ok=1",
            (entry["track"], entry["round"])).fetchone()
        entry["train_fits"], entry["test_fits"], entry["extended_fits"] = row[0], row[1], row[2]
    events = [dict(row) for row in db.execute("select at, track, round, kind, message from events order by at desc limit 40")]
    code = db.execute("select value from meta where key='code_sha256'").fetchone()
    return {"ready": True, "status": read_status(), "eligible": eligible, "tracks": tracks, "rounds": rounds, "events": events,
            "v1": V1, "code": code[0] if code else None, "now": time.time()}


def breakdown(track):
    db = database()
    methods = [dict(row) for row in db.execute(
        """select mode method, count(*) training, coalesce(sum(test_ok), 0) held_out, coalesce(sum(extended_ok), 0) all_terms
           from outcomes where track=? and train_ok=1 group by mode order by held_out desc""", (track,))]
    costs = [dict(row) for row in db.execute(
        """select cost, count(*) training, coalesce(sum(test_ok), 0) held_out
           from outcomes where track=? and train_ok=1 group by cost order by cost""", (track,))]
    keywords = []
    for keyword in ("easy", "nice", "core", "mult", "base", "tabl", "cons", "walk", "more", "hard"):
        total = db.execute("select count(*) from sequences where ',' || keywords || ',' like ?", ("%," + keyword + ",%",)).fetchone()[0]
        solved = db.execute(
            """select coalesce(sum(o.test_ok), 0) from outcomes o join sequences s on s.id=o.id
               where o.track=? and o.train_ok=1 and ',' || s.keywords || ',' like ?""", (track, "%," + keyword + ",%")).fetchone()[0]
        keywords.append({"keyword": keyword, "sequences": total, "held_out": solved})
    return {"track": track, "methods": methods, "costs": costs, "keywords": keywords}


def recent(track, limit, offset, method, only):
    db = database()
    clauses, parameters = ["o.track=?", "o.train_ok=1"], [track]
    if only == "held_out":
        clauses.append("o.test_ok=1")
    elif only == "all_terms":
        clauses.append("o.extended_ok=1")
    if method:
        clauses.append("o.mode=?")
        parameters.append(method)
    where = " and ".join(clauses)
    rows = db.execute(
        """select o.id, s.name, s.offset, s.terms, o.round, o.cost, o.mode method, o.nodes, o.matches, o.status, o.test_ok, o.extended_ok,
                  o.validated_at, s.dev from outcomes o join sequences s on s.id=o.id
           where %s order by o.validated_at desc, o.id limit ? offset ?""" % where, parameters + [limit, offset]).fetchall()
    return {"track": track, "rows": [with_program(db, track, dict(row)) for row in rows]}


def training_window(identifier, length):
    with open(ROOT / "data" / "sequences.tsv") as handle:
        for line in handle:
            if line.startswith(identifier + "\t"):
                _, offset, terms = line.rstrip("\n").split("\t")
                values = terms.split(",")
                return int(offset), ",".join(values[:length]), values
    return None


WINDOWS = {}


def window_index(track, length):
    """Sequence id -> (offset, training terms), built once per track."""
    if track not in WINDOWS:
        index = {}
        with open(ROOT / "data" / "sequences.tsv") as handle:
            for line in handle:
                identifier, offset, terms = line.rstrip("\n").split("\t")
                index[identifier] = (int(offset), ",".join(terms.split(",", length)[:length]))
        WINDOWS[track] = index
    return WINDOWS[track]


def with_program(db, track, row):
    length = json.loads(db.execute("select value from meta where key='protocol'").fetchone()[0])["Tracks"][track]["TrainingTerms"]
    key = window_index(track, length).get(row["id"])
    program = None
    if key:
        found = db.execute("select program from selections where track=? and offset=? and train=?", (track, key[0], key[1])).fetchone()
        program = found[0] if found else None
    row["program"] = program
    return row


def sequence(identifier):
    db = database()
    info = db.execute("select * from sequences where id=?", (identifier,)).fetchone()
    if info is None:
        return {"found": False, "id": identifier}
    result = {"found": True, "sequence": dict(info), "tracks": {}}
    window = training_window(identifier, 10 ** 6)
    result["terms"] = window[2][:60] if window else []
    for (track,) in db.execute("select distinct track from rounds"):
        row = db.execute("select * from outcomes where track=? and id=?", (track, identifier)).fetchone()
        result["tracks"][track] = with_program(db, track, dict(row)) if row else None
    return result


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *arguments):
        return

    def reply(self, payload, content="application/json", code=200):
        body = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", content)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urlparse(self.path)
        query = {key: values[0] for key, values in parse_qs(url.query).items()}
        try:
            if url.path in ("/", "/index.html"):
                self.reply((ROOT / "dashboard.html").read_bytes(), "text/html; charset=utf-8")
            elif url.path == "/api/overview":
                self.reply(overview())
            elif url.path == "/api/breakdown":
                self.reply(breakdown(query.get("track", "p8")))
            elif url.path == "/api/recent":
                self.reply(recent(query.get("track", "p8"), min(int(query.get("limit", 50)), 500), int(query.get("offset", 0)),
                                  query.get("method", ""), query.get("only", "held_out")))
            elif url.path == "/api/sequence":
                self.reply(sequence(query.get("id", "").strip().upper()))
            else:
                self.reply({"error": "not found"}, code=404)
        except Exception as error:  # the database may be mid-write or absent
            self.reply({"error": repr(error)}, code=500)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    arguments = parser.parse_args()
    server = ThreadingHTTPServer((arguments.host, arguments.port), Handler)
    print("dashboard: http://%s:%d/" % (arguments.host, arguments.port), flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
