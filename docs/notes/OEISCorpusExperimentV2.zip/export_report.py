#!/usr/bin/env python3
"""Export the measurements behind notebooks/Results-02.nb and the v2 note.

Reads results.sqlite3 (read-only) and data/sequences.tsv and writes
docs/notes/data/OEISCorpusV2.json.gz. Integers that may exceed machine
precision are written as strings. notebook-examples.json names the sequences
exported with their terms and programs.

  python3 export_report.py [--rounds N]
"""
import argparse
import datetime
import gzip
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parent.parent
OUTPUT = REPOSITORY / "docs" / "notes" / "data" / "OEISCorpusV2.json.gz"
V1 = {"TrainingFits": 8626, "PrimaryFits": 876, "AllRecordedFits": 130, "ConstantBaseline": 462, "AffineBaseline": 1341,
      "Candidates": 464, "Searches": 868957}
KEYWORDS = ["easy", "nice", "core", "mult", "base", "tabl", "cons", "walk", "more", "hard"]
NAMES = {"p8": "P8", "p20": "P20"}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--examples", default=str(ROOT / "notebook-examples.json"), help="JSON file naming the sequences to export")
    parser.add_argument("--rounds", type=int, default=None, help="report at most this many completed rounds per protocol")
    parser.add_argument("--root", default=str(ROOT), help="experiment directory (default: this directory)")
    parser.add_argument("--output", default=str(OUTPUT), help="output file")
    arguments = parser.parse_args()
    root, output = Path(arguments.root), Path(arguments.output)
    db = sqlite3.connect("file:%s?mode=ro" % (root / "results.sqlite3"), uri=True)
    db.row_factory = sqlite3.Row
    protocol = json.loads(db.execute("select value from meta where key='protocol'").fetchone()[0])
    eligible = db.execute("select count(*) from sequences").fetchone()[0]
    reasoned = "reason" in [row[1] for row in db.execute("pragma table_info(selections)")]

    terms = {}
    with open(root / "data" / "sequences.tsv") as handle:
        for line in handle:
            identifier, offset, values = line.rstrip("\n").split("\t")
            terms[identifier] = (int(offset), values)

    def program_of(track, identifier):
        length = protocol["Tracks"][track]["TrainingTerms"]
        offset, values = terms[identifier]
        window = ",".join(values.split(",", length)[:length])
        row = db.execute("select program from selections where track=? and offset=? and train=?", (track, offset, window)).fetchone()
        return row[0] if row else None

    def record(track, identifier, key=None):
        row = db.execute(
            """select o.*, s.name, s.offset, s.terms total, s.keywords from outcomes o join sequences s on s.id=o.id
               where o.track=? and o.id=?""", (track, identifier)).fetchone()
        if row is None:
            raise SystemExit("no outcome for %s in %s" % (identifier, track))
        return {"Key": key or identifier, "ID": identifier, "Name": row["name"], "Offset": row["offset"], "Terms": terms[identifier][1].split(","),
                "Protocol": NAMES[track], "TrainingTerms": protocol["Tracks"][track]["TrainingTerms"],
                "Program": program_of(track, identifier), "Method": row["mode"], "Cost": row["cost"], "Nodes": row["nodes"],
                "Round": row["round"], "TermsReproduced": row["matches"], "Status": row["status"],
                "Keywords": row["keywords"].split(",")}

    result = {
        "Study": protocol["Study"],
        "UpdatedUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
        "Eligible": eligible,
        "CodeSHA256": db.execute("select value from meta where key='code_sha256'").fetchone()[0],
        "Data": protocol["Data"],
        "V1": V1,
        "Protocols": {},
    }
    for track, spec in protocol["Tracks"].items():
        training = spec["TrainingTerms"]
        primary = spec["PrimaryHeldOutTerms"]
        last = db.execute("select coalesce(max(round), 0) from rounds where track=? and state='Completed'", (track,)).fetchone()[0]
        if arguments.rounds is not None:
            last = min(last, arguments.rounds)
        base = "from outcomes o join sequences s on s.id=o.id where o.track=? and o.train_ok=1 and o.round <= %d" % last
        total = db.execute(
            "select count(*) n, coalesce(sum(o.test_ok),0) t, coalesce(sum(o.extended_ok),0) e, coalesce(sum(o.extended_ok is not null),0) later " + base,
            (track,)).fetchone()
        entry = {
            "Title": spec["Title"], "TrainingTerms": training, "TestTerms": primary, "Criterion": spec["Criterion"],
            "TrainingFits": total["n"], "TestFits": total["t"], "AllRecordedFits": total["e"], "WithLaterTerms": total["later"],
            "CompletedRounds": last,
            "Windows": db.execute("select count(*) from selections where track=? and train_ok=1 and round <= ?", (track, last)).fetchone()[0],
            "DistinctPrograms": db.execute("select count(distinct program) from selections where track=? and train_ok=1 and round <= ?", (track, last)).fetchone()[0],
            "ProposedNotReproduced": db.execute("select count(*) from selections where track=? and train_ok=0 and round <= ?", (track, last)).fetchone()[0],
            "Splits": {}, "Rounds": [], "Methods": [], "Costs": [], "Nodes": [], "Keywords": [],
        }
        # Why proposals were not counted: "Mismatch" is a differing value, the rest are budget tags.
        entry["NotReproducedReasons"] = {row[0] or "NotRecorded": row[1] for row in db.execute(
            "select %s, count(*) from selections where track=? and train_ok=0 and round <= ? group by 1" % ("reason" if reasoned else "null"), (track, last))}
        for name, flag in (("Evaluation", 0), ("Development", 1)):
            part = db.execute(
                "select count(*) n, coalesce(sum(o.test_ok),0) t, coalesce(sum(o.extended_ok),0) e " + base + " and s.dev=?", (track, flag)).fetchone()
            entry["Splits"][name] = {"Sequences": db.execute("select count(*) from sequences where dev=?", (flag,)).fetchone()[0],
                                     "TrainingFits": part["n"], "TestFits": part["t"], "AllRecordedFits": part["e"]}
        for row in db.execute("select * from rounds where track=? and state='Completed' and round <= ? order by round", (track, last)):
            config = json.loads(row["config"])
            fits = db.execute(
                "select count(*), coalesce(sum(test_ok), 0), coalesce(sum(extended_ok), 0) from outcomes where track=? and round=? and train_ok=1",
                (track, row["round"])).fetchone()
            # Proposals of the round that reproduced their training terms in validation.
            reproduced = db.execute("select count(*) from selections where track=? and round=? and train_ok=1", (track, row["round"])).fetchone()[0]
            entry["Rounds"].append({"Round": row["round"], "Library": row["library"] if config["Library"] else 0,
                                    "SearchSeconds": row["engine_seconds"], "ValidationSeconds": row["validation_seconds"],
                                    "Proposed": row["proposed"], "Reproduced": reproduced, "TrainingFits": fits[0], "TestFits": fits[1],
                                    "AllRecordedFits": fits[2], "Arguments": config["Arguments"]})
        for row in db.execute(
                "select o.mode m, count(*) n, coalesce(sum(o.test_ok),0) t, coalesce(sum(o.extended_ok),0) e " + base + " group by o.mode order by t desc", (track,)):
            entry["Methods"].append({"Method": row["m"], "TrainingFits": row["n"], "TestFits": row["t"], "AllRecordedFits": row["e"]})
        for row in db.execute("select o.cost c, count(*) n, coalesce(sum(o.test_ok),0) t " + base + " group by o.cost order by o.cost", (track,)):
            entry["Costs"].append({"Cost": row["c"], "TrainingFits": row["n"], "TestFits": row["t"]})
        for row in db.execute("select o.nodes c, count(*) n, coalesce(sum(o.test_ok),0) t " + base + " group by o.nodes order by o.nodes", (track,)):
            entry["Nodes"].append({"Nodes": row["c"], "TrainingFits": row["n"], "TestFits": row["t"]})
        for keyword in KEYWORDS:
            like = "%," + keyword + ",%"
            count = db.execute("select count(*) from sequences where ',' || keywords || ',' like ?", (like,)).fetchone()[0]
            part = db.execute("select count(*) n, coalesce(sum(o.test_ok),0) t " + base + " and ',' || s.keywords || ',' like ?", (track, like)).fetchone()
            entry["Keywords"].append({"Keyword": keyword, "Sequences": count, "TrainingFits": part["n"], "TestFits": part["t"]})
        # Number of held-out terms reproduced before the first failure.
        if primary:
            counts = [0] * (primary + 1)
            for (matches,) in db.execute("select matches from outcomes where track=? and train_ok=1 and round <= ?", (track, last)):
                counts[max(0, min(matches - training, primary))] += 1
            entry["HeldOutAgreement"] = counts
        # Of the fits with at least `window` later terms, how many reproduce each further term.
        window = 40
        cohort = [row[0] for row in db.execute(
            "select o.matches " + base + " and s.terms >= ?", (track, training + window))]
        entry["Horizon"] = {"Cohort": len(cohort), "Agree": [sum(1 for m in cohort if m >= training + k) for k in range(window + 1)]}
        entry["Statuses"] = {row[0]: row[1] for row in db.execute(
            "select status, count(*) from outcomes where track=? and train_ok=1 and round <= ? group by status", (track, last))}
        entry["RecordedTerms"] = [row[0] for row in db.execute("select s.terms " + base + " and o.extended_ok=1 order by s.terms", (track,))][::max(1, total["e"] // 2000)]
        result["Protocols"][NAMES[track]] = entry

    listing = json.loads(Path(arguments.examples).read_text())
    shown = [item for section in listing["Sections"] for item in section["Examples"]] + listing.get("Extra", [])
    result["Examples"] = [record(item["Protocol"], item["ID"], item["Key"]) for item in shown]
    result["Failures"] = [record(item["Protocol"], item["ID"], item["Key"]) for item in listing["Failures"]]
    output.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(output, "wt") as handle:
        json.dump(result, handle, separators=(",", ":"))
    print("wrote", output, "with", len(result["Examples"]), "examples")
    for name, entry in result["Protocols"].items():
        print(name, {key: entry[key] for key in ("TrainingFits", "TestFits", "AllRecordedFits", "WithLaterTerms", "Windows")})


if __name__ == "__main__":
    main()
