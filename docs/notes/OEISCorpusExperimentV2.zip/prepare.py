#!/usr/bin/env python3
"""Export the pinned OEIS snapshot used by corpus v1 into flat files for the v2 engine.

The v1 database already holds every sequence record of the pinned snapshot, its
eligibility decision and its terms. v2 reuses exactly that inventory so the two
studies are comparable sequence for sequence.
"""
import json, os, sqlite3, sys, hashlib

HERE = os.path.dirname(os.path.abspath(__file__))
V1 = os.path.join(HERE, "..", "oeis-corpus-v1", "results.sqlite3")
OUT = os.path.join(HERE, "data")

TRAIN = 8

def development_split(id_):
    """One sequence in five is development data; the rest is evaluation data."""
    return int(hashlib.sha256(("Recursor-OEIS-corpus-v2-dev:" + id_).encode()).hexdigest()[:8], 16) % 5 == 0

def main():
    db = sqlite3.connect("file:%s?mode=ro" % os.path.abspath(V1), uri=True)
    os.makedirs(OUT, exist_ok=True)
    digest = hashlib.sha256()
    eligible = 0
    development = 0
    with open(os.path.join(OUT, "sequences.tsv"), "w") as flat, open(os.path.join(OUT, "names.tsv"), "w") as names, \
            open(os.path.join(OUT, "train.tsv"), "w") as train, open(os.path.join(OUT, "dev.tsv"), "w") as dev:
        for id_, name, offset, terms, keywords in db.execute(
                "select id,name,offset,terms_json,keywords_json from sequences where eligible=1 order by id"):
            values = json.loads(terms)
            first = offset.split(",")[0].strip()
            line = "%s\t%s\t%s\n" % (id_, first, ",".join(str(v) for v in values))
            flat.write(line)
            digest.update(line.encode())
            # Search input: training terms only. Held-out terms never reach the engine.
            head = "%s\t%s\t%s\n" % (id_, first, ",".join(str(v) for v in values[:TRAIN]))
            train.write(head)
            # Development diagnostics: full terms for the development split only.
            if development_split(id_):
                dev.write(line)
                development += 1
            else:
                dev.write(head)
            names.write("%s\t%s\t%s\n" % (id_, ",".join(json.loads(keywords)), name.replace("\t", " ").replace("\n", " ")))
            eligible += 1
    meta = {"EligibleSequences": eligible, "DevelopmentSequences": development, "EvaluationSequences": eligible - development,
            "SequencesSHA256": digest.hexdigest(), "Source": "oeis-corpus-v1/results.sqlite3 (pinned snapshot)",
            "DevelopmentRule": "int(sha256('Recursor-OEIS-corpus-v2-dev:' + id)[:8], 16) % 5 == 0"}
    with open(os.path.join(OUT, "inventory.json"), "w") as f:
        json.dump(meta, f, indent=1)
    print(json.dumps(meta))

if __name__ == "__main__":
    main()
