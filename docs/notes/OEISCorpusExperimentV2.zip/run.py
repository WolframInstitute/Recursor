#!/usr/bin/env python3
"""Controller of the Recursor OEIS corpus v2 experiment.

A campaign alternates two tracks, round after round, without supervision:

  engine      the native proposer enumerates programs from training terms only
  validation  Wolfram kernels evaluate each proposed program with the paclet's
              reference interpreter and compare it with the recorded terms
  library     subprograms reused by several selected programs become building
              blocks of the next round

Commands:
  python3 run.py start [--hours H]   launch the campaign and the dashboard, detached
  python3 run.py stop                finish the current step and stop
  python3 run.py status              print the current totals
  python3 run.py run [--hours H]     run the campaign in the foreground
  python3 run.py export              write CSV exports and report.md

Standard library only. See README.md and protocol.json.
"""
import argparse
import csv
import gzip
import hashlib
import json
import os
import queue
import signal
import socket
import sqlite3
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "results.sqlite3"
STATE = ROOT / "state"
ROUNDS = ROOT / "rounds"
LOGS = ROOT / "logs"
STOP = ROOT / "STOP"
KERNEL = os.environ.get("RECURSOR_CORPUS_KERNEL", "/Applications/Wolfram Latest.app/Contents/MacOS/WolframKernel")
PROTOCOL = json.loads((ROOT / "protocol.json").read_text())
TRACKS = list(PROTOCOL["Tracks"])

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS sequences(
  id TEXT PRIMARY KEY, offset INTEGER, terms INTEGER, name TEXT, keywords TEXT, dev INTEGER);
CREATE TABLE IF NOT EXISTS selections(
  track TEXT, offset INTEGER, train TEXT, round INTEGER, cost INTEGER, mode TEXT, nodes INTEGER,
  program TEXT, train_ok INTEGER, selected_at REAL, reason TEXT, PRIMARY KEY(track, offset, train));
CREATE TABLE IF NOT EXISTS outcomes(
  track TEXT, id TEXT, round INTEGER, cost INTEGER, mode TEXT, nodes INTEGER, matches INTEGER, status TEXT,
  train_ok INTEGER, test_ok INTEGER, extended_ok INTEGER, extended_terms INTEGER, validated_at REAL,
  PRIMARY KEY(track, id));
CREATE INDEX IF NOT EXISTS outcome_fits ON outcomes(track, train_ok, test_ok);
CREATE INDEX IF NOT EXISTS outcome_time ON outcomes(validated_at);
CREATE TABLE IF NOT EXISTS rounds(
  track TEXT, round INTEGER, state TEXT, started REAL, finished REAL, config TEXT,
  engine_seconds REAL, validation_seconds REAL, windows INTEGER, proposed INTEGER, library INTEGER,
  train_fits INTEGER, test_fits INTEGER, extended_fits INTEGER, PRIMARY KEY(track, round));
CREATE TABLE IF NOT EXISTS events(at REAL, track TEXT, round INTEGER, kind TEXT, message TEXT);
"""


def connect():
    db = sqlite3.connect(DB, timeout=60)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=NORMAL")
    return db


def development(identifier):
    """One sequence in five is development data (see protocol.json)."""
    return int(hashlib.sha256(("Recursor-OEIS-corpus-v2-dev:" + identifier).encode()).hexdigest()[:8], 16) % 5 == 0


def code_digest():
    """Hash of everything that defines the experiment's behaviour."""
    digest = hashlib.sha256()
    files = [ROOT / "protocol.json", ROOT / "validate.wls", ROOT / "run.py", ROOT / "engine" / "Cargo.toml"]
    files += sorted((ROOT / "engine" / "src").glob("*.rs"))
    files += sorted((ROOT.parent.parent / "Recursor" / "Kernel").rglob("*.wl"))
    for path in files:
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


class Corpus:
    """Recorded terms, read by validation only, and names for the reports."""

    def __init__(self):
        self.ids, self.offsets, self.terms = [], [], []
        with open(ROOT / "data" / "sequences.tsv") as handle:
            for line in handle:
                identifier, offset, terms = line.rstrip("\n").split("\t")
                self.ids.append(identifier)
                self.offsets.append(int(offset))
                self.terms.append(terms)
        self.windows = {}
        for track in TRACKS:
            length = PROTOCOL["Tracks"][track]["TrainingTerms"]
            index = {}
            for position, terms in enumerate(self.terms):
                parts = terms.split(",", length)
                if len(parts) >= length:
                    index.setdefault((self.offsets[position], ",".join(parts[:length])), []).append(position)
            self.windows[track] = index


def initialize():
    for directory in (STATE, ROUNDS, LOGS):
        directory.mkdir(exist_ok=True)
    db = connect()
    db.executescript(SCHEMA)
    # Records made before proposals kept the reason they were not counted.
    if "reason" not in [row[1] for row in db.execute("pragma table_info(selections)")]:
        db.execute("alter table selections add column reason TEXT")
    if db.execute("select count(*) from sequences").fetchone()[0] == 0:
        counts = {}
        with open(ROOT / "data" / "sequences.tsv") as handle:
            for line in handle:
                identifier, offset, terms = line.rstrip("\n").split("\t")
                counts[identifier] = (int(offset), terms.count(",") + 1)
        rows = []
        with open(ROOT / "data" / "names.tsv") as handle:
            for line in handle:
                identifier, keywords, name = line.rstrip("\n").split("\t", 2)
                offset, terms = counts[identifier]
                rows.append((identifier, offset, terms, name, keywords, int(development(identifier))))
        db.executemany("insert into sequences values(?,?,?,?,?,?)", rows)
    db.execute("insert or replace into meta values('protocol', ?)", (json.dumps(PROTOCOL),))
    db.execute("insert or replace into meta values('code_sha256', ?)", (code_digest(),))
    db.commit()
    return db


def event(db, track, round_number, kind, message):
    db.execute("insert into events values(?,?,?,?,?)", (time.time(), track, round_number, kind, message))
    db.commit()
    print(time.strftime("%H:%M:%S"), track or "-", round_number or "-", kind, message, flush=True)


class Interrupted(Exception):
    """A stop was requested while the engine was searching."""


STATUS = {"state": "Starting", "pid": os.getpid(), "started": time.time()}


def publish(**fields):
    STATUS.update(fields)
    STATUS["updated"] = time.time()
    temporary = STATE / "status.json.tmp"
    temporary.write_text(json.dumps(STATUS))
    temporary.replace(STATE / "status.json")


class Kernel:
    """One Wolfram kernel running validate.wls."""

    def __init__(self, name):
        self.name = name
        self.lines = queue.Queue()
        self.log = open(LOGS / ("kernel-%s.log" % name), "a", buffering=1)
        environment = dict(os.environ, OMP_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1")
        self.process = subprocess.Popen(
            [KERNEL, "-noprompt", "-script", str(ROOT / "validate.wls")],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.log, text=True, bufsize=1,
            env=environment, start_new_session=True)
        threading.Thread(target=self._read, daemon=True).start()
        self._receive("READY", 180)

    def _read(self):
        for line in self.process.stdout:
            self.lines.put(line.rstrip("\n"))
        self.lines.put(None)

    def _receive(self, prefix, timeout):
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("kernel response deadline exceeded")
            line = self.lines.get(timeout=remaining)
            if line is None:
                raise RuntimeError("kernel exited with code %s" % self.process.poll())
            if line.startswith(prefix):
                return line[len(prefix):].strip()
            self.log.write(line + "\n")

    def request(self, payload, timeout):
        self.process.stdin.write(json.dumps(payload, separators=(",", ":")) + "\n")
        self.process.stdin.flush()
        return json.loads(self._receive("RESULT ", timeout))

    def close(self):
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
        self.log.close()


def validation_worker(name, jobs, results):
    """Serve validation jobs; restart the kernel after a failure."""
    kernel = None
    budget = PROTOCOL["Validation"]["ProgramBudgetSeconds"] + 90
    while True:
        job = jobs.get()
        if job is None:
            break
        response = None
        for attempt in range(2):
            try:
                if kernel is None:
                    kernel = Kernel(name)
                response = kernel.request(job["request"], budget)
                break
            except Exception as error:  # a hung or dead kernel: replace it
                response = {"Status": "WorkerFailure", "Detail": str(error)}
                if kernel is not None:
                    kernel.close()
                kernel = None
        results.put((job, response))
    if kernel is not None:
        kernel.close()


def round_config(track, number):
    """The frozen schedule, continued by deepening once it is exhausted."""
    schedule = PROTOCOL["Rounds"][track]
    if number <= len(schedule):
        return schedule[number - 1]
    base = [entry for entry in schedule if not entry["Library"]][-1]
    library = [entry for entry in schedule if entry["Library"]][-1]
    extra = (number - len(schedule) + 1) // 2
    if (number - len(schedule)) % 2 == 1:
        arguments = dict(base["Arguments"])
        for key in ("max-size", "store-size", "rec-size", "bin-size", "open-max"):
            arguments[key] += extra
        return {"Library": False, "Arguments": arguments}
    arguments = dict(library["Arguments"])
    for key in ("max-size", "store-size"):
        arguments[key] += extra
    return {"Library": True, "Arguments": arguments}


def build_library(track, before_round, path):
    """Rank building blocks from the training fits of earlier rounds."""
    classes, recurrences = {}, {}
    for number in range(1, before_round):
        source = ROUNDS / ("%s-r%d" % (track, number)) / "library-candidates.tsv"
        if not source.exists():
            continue
        with open(source) as handle:
            for line in handle:
                references, cost, kind, program = line.rstrip("\n").split("\t", 3)
                if kind == "Class":
                    previous = classes.get(program, (0, 10 ** 9))
                    classes[program] = (previous[0] + int(references), min(previous[1], int(cost)))
                else:
                    recurrences[program] = min(recurrences.get(program, 10 ** 9), int(cost))
    policy = PROTOCOL["LibraryPolicy"]
    ranked = sorted(classes.items(), key=lambda item: (-item[1][0], item[1][1], item[0]))
    chosen, seen = [], set()
    for position, (program, _) in enumerate(ranked[: policy["ClassesAtCost3"] + policy["ClassesAtCost4"]]):
        seen.add(program)
        chosen.append((3 if position < policy["ClassesAtCost3"] else 4, program))
    for program, _ in sorted(recurrences.items(), key=lambda item: (item[1], item[0])):
        if len(chosen) >= policy["ClassesAtCost3"] + policy["ClassesAtCost4"] + policy["RecurrencesAtCost5"]:
            break
        if program not in seen:
            seen.add(program)
            chosen.append((5, program))
    with open(path, "w") as handle:
        for cost, program in chosen:
            handle.write("%d\t%s\n" % (cost, program))
    return len(chosen)


def run_engine(track, number, config, directory, db):
    arguments = dict(config["Arguments"])
    arguments.update(PROTOCOL["EngineGuards"][track])
    command = [str(ROOT / PROTOCOL["Tracks"][track]["Engine"]), "--data", str(ROOT / PROTOCOL["Tracks"][track]["Input"]),
               "--out", str(directory / "programs.tsv"), "--library-out", str(directory / "library-candidates.tsv"),
               "--solved", str(directory / "solved.tsv"), "--threads", str(PROTOCOL["EngineThreads"])]
    library = 0
    if config["Library"]:
        library = build_library(track, number, directory / "library.tsv")
        command += ["--library", str(directory / "library.tsv")]
    for key, value in arguments.items():
        command += ["--" + key, str(value)]
    (directory / "command.json").write_text(json.dumps(command))
    started = time.time()
    with open(directory / "engine.log", "w") as log:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, cwd=ROOT)

        def watch():
            # A stop request ends a long search at once; the round is redone on resume.
            while process.poll() is None:
                if STOP.exists():
                    process.terminate()
                    return
                time.sleep(2)

        threading.Thread(target=watch, daemon=True).start()
        for line in process.stdout:
            log.write(line)
            if line.startswith("@status "):
                try:
                    publish(engine=json.loads(line[len("@status "):]))
                except ValueError:
                    pass
        code = process.wait()
    if STOP.exists():
        raise Interrupted()
    if code != 0:
        raise RuntimeError("engine exited with code %d; see %s" % (code, directory / "engine.log"))
    return time.time() - started, library


def run_round(db, corpus, track, number):
    config = round_config(track, number)
    directory = ROUNDS / ("%s-r%d" % (track, number))
    directory.mkdir(parents=True, exist_ok=True)
    training = PROTOCOL["Tracks"][track]["TrainingTerms"]
    primary = PROTOCOL["Tracks"][track]["PrimaryHeldOutTerms"]
    # A round that was interrupted is resumed: it keeps its start and the
    # time already spent, and searches only the windows still unsolved.
    earlier = db.execute("select started, engine_seconds, validation_seconds from rounds where track=? and round=?", (track, number)).fetchone()
    begun, engine_before, validation_before = earlier or (None, None, None)
    engine_before, validation_before = engine_before or 0.0, validation_before or 0.0
    db.execute("insert or replace into rounds(track, round, state, started, config, engine_seconds, validation_seconds) values(?,?,?,?,?,?,?)",
               (track, number, "Engine", begun or time.time(), json.dumps(config), engine_before, validation_before))
    db.commit()
    # Windows that already have a program reproducing their training terms.
    solved = db.execute("select offset, train from selections where track=? and train_ok=1", (track,)).fetchall()
    with open(directory / "solved.tsv", "w") as handle:
        for offset, train in solved:
            handle.write("%d\t%s\n" % (offset, train))
    publish(state="Running", track=track, round=number, stage="engine", config=config, engine=None, validation=None)
    event(db, track, number, "engine", "search started: %s" % json.dumps(config["Arguments"], sort_keys=True))
    engine_seconds, library = run_engine(track, number, config, directory, db)

    proposals = []
    with open(directory / "programs.tsv") as handle:
        for line in handle:
            offset, train, cost, mode, nodes, program = line.rstrip("\n").split("\t", 5)
            proposals.append((int(offset), train, int(cost), mode, int(nodes), program))
    event(db, track, number, "engine", "search finished in %.0f s: %d windows have a candidate program" % (engine_seconds, len(proposals)))
    db.execute("update rounds set state='Validation', engine_seconds=?, proposed=?, library=?, windows=? where track=? and round=?",
               (engine_before + engine_seconds, len(proposals), library, len(corpus.windows[track]), track, number))
    db.commit()

    # Validation with the reference interpreter. Held-out terms are read here only.
    jobs, results = queue.Queue(), queue.Queue()
    workers = [threading.Thread(target=validation_worker, args=("%s-%d" % (track, index), jobs, results), daemon=True)
               for index in range(PROTOCOL["Validation"]["Workers"])]
    for worker in workers:
        worker.start()
    submitted = 0
    for offset, train, cost, mode, nodes, program in proposals:
        members = corpus.windows[track].get((offset, train), [])
        if not members:
            continue
        request = {"Operation": "Validate", "Program": program, "Offset": offset,
                   "Sequences": [{"ID": corpus.ids[m], "Terms": corpus.terms[m].split(",")} for m in members]}
        jobs.put({"request": request, "key": (offset, train), "cost": cost, "mode": mode, "nodes": nodes, "program": program})
        submitted += 1
    for _ in workers:
        jobs.put(None)
    started = reported = time.time()
    done = train_fits = test_fits = extended_fits = failures = 0
    while done < submitted:
        job, response = results.get()
        done += 1
        offset, train = job["key"]
        now = time.time()
        if response.get("Status") != "Completed":
            failures += 1
            db.execute("insert or replace into selections values(?,?,?,?,?,?,?,?,?,?,?)",
                       (track, offset, train, number, job["cost"], job["mode"], job["nodes"], job["program"], 0, now, response.get("Status", "Unknown")))
        else:
            reproduced = all(result["Matches"] >= training for result in response["Results"])
            # Why a proposal is not counted: a value that differs ("Mismatch") or a budget tag.
            reason = None if reproduced else "/".join(sorted({result["Status"] for result in response["Results"] if result["Matches"] < training}))
            failures += not reproduced
            db.execute("insert or replace into selections values(?,?,?,?,?,?,?,?,?,?,?)",
                       (track, offset, train, number, job["cost"], job["mode"], response.get("Nodes", job["nodes"]), job["program"], int(reproduced), now, reason))
            if reproduced:
                for result, member in zip(response["Results"], corpus.windows[track][(offset, train)]):
                    total = corpus.terms[member].count(",") + 1
                    matches = result["Matches"]
                    later = total - training - primary
                    test_ok = None
                    if primary:
                        test_ok = int(matches >= training + primary)
                    elif total > training:
                        test_ok = int(matches == total)
                    extended_ok = int(matches == total) if later > 0 else None
                    train_fits += 1
                    test_fits += test_ok or 0
                    extended_fits += extended_ok or 0
                    db.execute("insert or replace into outcomes values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                               (track, result["ID"], number, job["cost"], job["mode"], response.get("Nodes", job["nodes"]), matches,
                                result["Status"], 1, test_ok, extended_ok, max(later, 0), now))
        if done % 100 == 0 or done == submitted:
            db.execute("update rounds set validation_seconds=? where track=? and round=?",
                       (validation_before + time.time() - started, track, number))
            db.commit()
        if done % 25 == 0 or done == submitted or time.time() - reported > 5:
            reported = time.time()
            publish(stage="validation", validation={"done": done, "total": submitted, "train_fits": train_fits,
                                                    "test_fits": test_fits, "extended_fits": extended_fits, "failures": failures,
                                                    "seconds": time.time() - started})
    for worker in workers:
        worker.join(timeout=30)
    validation_seconds = validation_before + time.time() - started
    # Totals of the round come from the record, so a round that was
    # interrupted and resumed still counts everything it validated.
    train_fits, test_fits, extended_fits = db.execute(
        "select count(*), coalesce(sum(test_ok), 0), coalesce(sum(extended_ok), 0) from outcomes where track=? and round=? and train_ok=1",
        (track, number)).fetchone()
    proposed = db.execute("select count(*) from selections where track=? and round=?", (track, number)).fetchone()[0]
    db.execute("update rounds set state='Completed', finished=?, validation_seconds=?, proposed=?, train_fits=?, test_fits=?, extended_fits=? where track=? and round=?",
               (time.time(), validation_seconds, proposed, train_fits, test_fits, extended_fits, track, number))
    db.commit()
    event(db, track, number, "validation",
          "validated %d programs in %.0f s: %d sequences reproduced on training terms, %d on the held-out test, %d on every recorded term"
          % (proposed, validation_seconds, train_fits, test_fits, extended_fits))


def running_controller():
    """The pid of a live controller other than this process, or None."""
    path = STATE / "controller.pid"
    if path.exists():
        try:
            pid = int(path.read_text())
            if pid != os.getpid():
                os.kill(pid, 0)
                return pid
        except (ValueError, OSError):
            pass
    return None


def campaign(hours):
    STATE.mkdir(exist_ok=True)
    other = running_controller()
    if other:
        raise SystemExit("a controller is already running (pid %d); stop it with: python3 run.py stop" % other)
    (STATE / "controller.pid").write_text(str(os.getpid()))
    db = initialize()
    if STOP.exists():
        STOP.unlink()
    deadline = time.time() + hours * 3600 if hours else None
    publish(state="Loading", track=None, round=None, stage="loading corpus")
    corpus = Corpus()
    event(db, None, None, "campaign", "campaign started (pid %d, code %s)" % (os.getpid(), code_digest()[:12]))
    try:
        while True:
            # Next round: the track with the fewest completed rounds goes first.
            completed = {track: db.execute("select count(*) from rounds where track=? and state='Completed'", (track,)).fetchone()[0] for track in TRACKS}
            track = min(TRACKS, key=lambda name: (completed[name], TRACKS.index(name)))
            if STOP.exists() or (deadline and time.time() > deadline):
                break
            run_round(db, corpus, track, completed[track] + 1)
    except Interrupted:
        event(db, None, None, "campaign", "stop requested during a search; that round will be redone")
    except Exception as error:
        event(db, None, None, "error", repr(error))
        publish(state="Failed", error=repr(error))
        raise
    publish(state="Stopped", stage=None)
    event(db, None, None, "campaign", "campaign stopped")
    (STATE / "controller.pid").unlink(missing_ok=True)


def totals(db):
    rows = {}
    for track in TRACKS:
        row = db.execute(
            "select count(*), sum(test_ok), sum(extended_ok), sum(extended_ok is not null) from outcomes where track=? and train_ok=1", (track,)).fetchone()
        rows[track] = {"train_fits": row[0] or 0, "test_fits": row[1] or 0, "extended_fits": row[2] or 0, "with_extended_terms": row[3] or 0,
                       "rounds": db.execute("select count(*) from rounds where track=? and state='Completed'", (track,)).fetchone()[0]}
    return rows


def status():
    db = connect()
    eligible = db.execute("select count(*) from sequences").fetchone()[0]
    print("eligible sequences:", eligible)
    for track, row in totals(db).items():
        print("%-4s rounds=%d reproduced-training=%d held-out-test=%d (%.2f%%) all-recorded-terms=%d of %d with later terms" % (
            track, row["rounds"], row["train_fits"], row["test_fits"], 100.0 * row["test_fits"] / eligible, row["extended_fits"], row["with_extended_terms"]))
    if (STATE / "status.json").exists():
        print(json.dumps(json.loads((STATE / "status.json").read_text()), indent=1)[:1500])


def export():
    db = connect()
    with gzip.open(ROOT / "sequence-results.csv.gz", "wt", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Track", "OEIS_ID", "Name", "Offset", "Development", "Round", "Cost", "Method", "Nodes", "TermsReproduced", "Status",
                         "HeldOutTest", "AllRecordedTerms", "LaterTerms", "RecursorProgram"])
        query = """select o.track, o.id, s.name, s.offset, s.dev, o.round, o.cost, o.mode, o.nodes, o.matches, o.status, o.test_ok, o.extended_ok,
                          o.extended_terms from outcomes o join sequences s on s.id=o.id order by o.track, o.id"""
        programs = {}
        for track, offset, train, program in db.execute("select track, offset, train, program from selections where train_ok=1"):
            programs[(track, offset, train)] = program
        corpus = Corpus()
        position = {identifier: index for index, identifier in enumerate(corpus.ids)}
        for row in db.execute(query):
            track, identifier = row[0], row[1]
            length = PROTOCOL["Tracks"][track]["TrainingTerms"]
            terms = corpus.terms[position[identifier]].split(",", length)
            writer.writerow(list(row) + [programs.get((track, row[3], ",".join(terms[:length])), "")])
    (ROOT / "summary.json").write_text(json.dumps({"UpdatedUnix": time.time(), "Totals": totals(db)}, indent=1))
    print("wrote sequence-results.csv.gz and summary.json")


def start(hours):
    LOGS.mkdir(exist_ok=True)
    STATE.mkdir(exist_ok=True)
    other = running_controller()
    if other:
        raise SystemExit("a controller is already running (pid %d); stop it with: python3 run.py stop" % other)
    if STOP.exists():
        STOP.unlink()
    command = [sys.executable, str(ROOT / "run.py"), "run"] + (["--hours", str(hours)] if hours else [])
    with open(LOGS / "controller.log", "a") as log:
        controller = subprocess.Popen(command, stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True, cwd=ROOT)
    pids = {"controller": controller.pid}
    try:
        socket.create_connection(("127.0.0.1", 8765), timeout=1).close()
        previous = json.loads((STATE / "pids.json").read_text()) if (STATE / "pids.json").exists() else {}
        pids["dashboard"] = previous.get("dashboard")
        print("controller pid %d; the dashboard is already running" % controller.pid)
    except OSError:
        with open(LOGS / "dashboard.log", "a") as log:
            dashboard = subprocess.Popen([sys.executable, str(ROOT / "serve.py")], stdout=log, stderr=log, stdin=subprocess.DEVNULL,
                                         start_new_session=True, cwd=ROOT)
        pids["dashboard"] = dashboard.pid
        print("controller pid %d, dashboard pid %d" % (controller.pid, dashboard.pid))
    (STATE / "pids.json").write_text(json.dumps(pids))
    print("dashboard: http://127.0.0.1:8765/")


def stop():
    STOP.write_text("stop requested %s\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
    print("stop requested; the controller finishes its current step. The dashboard keeps running.")
    print("to stop the dashboard as well: kill %s" % json.loads((STATE / "pids.json").read_text()).get("dashboard", "<pid>") if (STATE / "pids.json").exists() else "")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("command", choices=["start", "stop", "status", "run", "export", "init"])
    parser.add_argument("--hours", type=float, default=0, help="stop dispatching rounds after this many hours (default: no limit)")
    arguments = parser.parse_args()
    if arguments.command == "init":
        initialize()
    elif arguments.command == "run":
        signal.signal(signal.SIGTERM, lambda *_: STOP.write_text("terminated\n"))
        campaign(arguments.hours)
    elif arguments.command == "start":
        start(arguments.hours)
    elif arguments.command == "stop":
        stop()
    elif arguments.command == "status":
        status()
    elif arguments.command == "export":
        export()


if __name__ == "__main__":
    main()
