# Recursor OEIS corpus experiment v2

This study replaces the evolutionary search of [corpus v1](../oeis-corpus-v1)
with deterministic synthesis and runs it over the same pinned OEIS snapshot.
A campaign runs without supervision and can be watched in a browser.

## Run and watch

From this directory, with Python 3.9 or later:

```sh
python3 run.py start        # launch the campaign and the dashboard, detached
python3 run.py status       # print current totals
python3 run.py stop         # stop after the current step
python3 run.py export       # write sequence-results.csv.gz and summary.json
```

The dashboard is at <http://127.0.0.1:8765/>. It refreshes itself. Add
`?theme=light` or `?theme=dark` to override the system appearance.
`python3 serve.py` starts the dashboard alone.

`python3 run.py start` resumes where a stopped campaign left off. A stop
request interrupts a running search at once; that round is redone on resume.
Validation of a finished search always completes, so a stop can take a while:
late rounds propose slow programs, and each may use its full budget of two
minutes. `--hours H` ends the campaign after H hours.

One controller runs at a time; its process number is in
`state/controller.pid`, and a second `start` is refused. Sending the
controller a termination signal is the same stop request. If it is killed
outright, the next `start` resumes the interrupted round: it keeps every
program already validated and searches the windows still without one.

## What runs

A campaign alternates two protocols, round after round:

| Protocol | Search sees | A sequence counts when its program also reproduces |
| --- | --- | --- |
| P8, prediction | the first 8 terms | the next 12 terms (the v1 criterion) |
| P20, representation | the first 20 terms | every later recorded term |

Each round has three steps.

1. **Search.** `engine/` is a native proposer. It enumerates Recursor programs
   by increasing cost, keeps one program per distinct list of values
   (observational equivalence) and looks every program up against all training
   windows at once. It also checks recurrences against the training terms and
   solves for constants exactly. It reads `data/train.tsv` or
   `data/train20.tsv`, which hold training terms only.
2. **Validation.** Twelve Wolfram kernels run `validate.wls`. Each proposed
   program is evaluated with the paclet's reference interpreter,
   `EvaluateRecursor`, and compared with the recorded terms. Only programs that
   reproduce their training terms here are counted.
3. **Library.** Subprograms that several selected programs share, and
   recurrences found for single windows, become building blocks of later
   rounds. Their ranking uses training fits only.

A window that has a program keeps it; later rounds search the windows that have
none. Odd rounds search deeper without a library; even rounds search with the
library. After the listed rounds the schedule keeps deepening. Guards in the
engine bound memory and time, so a deeper request ends as a shallower
completed round.

`protocol.json` fixes the data, criteria, selection rule, validation budgets
and schedule. `results.sqlite3` is the record: `selections` holds the program
of every training window, and the reason when a proposed program is not
counted (`Mismatch` for a differing value, otherwise a budget tag); `outcomes`
holds the checks of every sequence, `rounds` and `events` the history. `rounds/<protocol>-r<n>/` keeps each search's
command, log, proposals and library.

## Report

```sh
python3 export_report.py
wolframscript -file build-notebook.wls
python3 write_note.py
```

`export_report.py` writes `docs/notes/data/OEISCorpusV2.json.gz`: totals of
the completed rounds, breakdowns, and the sequences named in
`notebook-examples.json` with their terms and programs. `build-notebook.wls`
evaluates `notebook-spec.wl` on that file and writes
`notebooks/Results-02.nb`. `write_note.py` writes
`docs/notes/OEISCorpusExperimentV2.md` from the same file. A campaign may keep
running meanwhile: a report covers the rounds completed when it was exported,
or the first N of them with `--rounds N`.

## Reading the numbers

- A program that reproduces twenty or sixty terms is evidence for a rule. It
  is not a proof of an infinite identity.
- A budget failure in validation is recorded with its tag and counts as not
  reproduced. It never establishes nontermination.
- Sequences that share a training window share a program. They are checked
  separately and are not independent evidence.
- The engine keeps machine integers. A sequence whose training terms exceed
  2^62 is out of its reach, and a program whose intermediate values overflow
  is not proposed.
- Cost is the search's own measure, described in `protocol.json`. It is not
  the paclet's node count; both are recorded.

## How the method was developed

The search method was built on this corpus. One sequence in five, chosen by a
hash of its identifier, forms a development split. Diagnostics during
development read held-out terms of that split only, through `data/dev.tsv`.
Before the split was introduced, the first engine prototypes were scored by
aggregate held-out counts over the whole corpus, to decide whether exhaustive
enumeration, loops and recurrences were worth building. No per-sequence
outcome outside the development split was inspected, and no parameter was
tuned on it. The dashboard and the report give the evaluation split, the
development split and the whole corpus separately.

## Reproduce

```sh
python3 prepare.py                                   # export the pinned snapshot from corpus v1
cut -f1,2 data/sequences.tsv | paste - <(cut -f3 data/sequences.tsv | cut -d, -f1-20) > data/train20.tsv
(cd engine && cargo build --release && cargo build --release --features p20 --target-dir target-p20)
python3 run.py start
```

`prepare.py` reads `../oeis-corpus-v1/results.sqlite3`, which holds the pinned
snapshot (see `protocol.json`). The engine needs Rust 1.70 or later and no
other dependency. Validation needs a Wolfram kernel; set
`RECURSOR_CORPUS_KERNEL` if it is not at the default macOS path. The paclet
is loaded from this repository's working tree, and a hash of its kernel
sources, the engine sources and the protocol is stored with the results.

OEIS data are copyright the OEIS Foundation Inc. and contributors, under
CC BY-SA 4.0. The experiment code follows Recursor's MIT license.
