//! Mode I: one bottom-up enumeration of closed programs, shared by every
//! target.
//!
//! Programs are grouped by their values on n = 0..NC-1 (observational
//! equivalence) and only the cheapest member of each class is kept. A level
//! holds the classes of one cost. Candidates of a level are generated on all
//! threads, deduplicated in hash shards, then merged in a canonical order, so
//! the result does not depend on thread timing or thread count.
//!
//! Besides arithmetic, conditionals and bounded loops, a level contains
//! sequence transforms of earlier classes (partial sums and products,
//! differences, "n-th number such that", counting functions), compositions
//! through Let, and library programs selected in earlier rounds.

use crate::corpus::*;
use crate::lang::*;
use crate::universe::{all_bot, pattern, Universe, COMMUTATIVE, ORDERED, UNARY};
use std::collections::hash_map::Entry;
use std::hash::{Hash, Hasher};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::Instant;

pub const NC: usize = TRAIN + 4;
/// Inputs kept for classes that feed transforms and compositions.
#[cfg(not(feature = "p20"))]
pub const M: usize = 64;
#[cfg(feature = "p20")]
pub const M: usize = 128;
pub type CV = [V; NC];
pub type EV = [V; M];
/// Sample environments for loop bodies.
pub const NE: usize = 16;
pub type OV = [V; NE];

pub const SAMPLE_N: [V; NE] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 3, 5, 7, 9];
pub const SAMPLE_IDX: [V; NE] = [0, 0, 1, 2, 0, 3, 5, 1, 6, 4, 9, 7, 3, 4, 2, 8];
pub const SAMPLE_ACC: [V; NE] = [0, 1, 3, 2, 7, 12, 5, 24, 1, 64, 10, 120, 0, 31, 100, 720];

pub const K_SUM_EX: u8 = 64;
pub const K_SUM_IN: u8 = 65;
pub const K_PROD: u8 = 66;
pub const K_DIFF: u8 = 67;
/// K_NTH0 + p: the n-th (from zero) m with predicate p on x(m).
pub const K_NTH0: u8 = 72;
/// K_NTH1 + p: the n-th (from one) m with predicate p on x(m).
pub const K_NTH1: u8 = 76;
/// K_COUNT + p: the number of k <= n with predicate p on x(k).
pub const K_COUNT: u8 = 80;
pub const K_LIBRARY: u8 = 96;
/// Predicates: x = 0, x != 0, x = 1, x = 2.
pub const PREDICATES: u8 = 4;

const ALL_OPS: [Op; 21] = [
    Op::Var,
    Op::Acc,
    Op::Idx,
    Op::Const,
    Op::Succ,
    Op::Pred,
    Op::Half,
    Op::Add,
    Op::Mul,
    Op::Monus,
    Op::Rem,
    Op::Quot,
    Op::Ifz,
    Op::Iter,
    Op::Rec,
    Op::While,
    Op::CoRec,
    Op::CGet,
    Op::Let,
    Op::Prev,
    Op::PH,
];

#[derive(Clone, Copy)]
pub struct Cand {
    pub vec: CV,
    pub kind: u8,
    pub a: u32,
    pub b: u32,
    pub c: u32,
}

impl Cand {
    #[inline(always)]
    pub fn key(&self) -> (u8, u32, u32, u32) {
        (self.kind, self.a, self.b, self.c)
    }
    /// Closed classes this candidate is built from. The third slot of a
    /// loop is an open body, not a closed class.
    pub fn kids(&self) -> [u32; 3] {
        if self.kind < 64 && matches!(ALL_OPS[self.kind as usize], Op::Iter | Op::Rec) {
            [self.a, self.b, NIL]
        } else {
            [self.a, self.b, self.c]
        }
    }
}

#[derive(Clone, Copy)]
struct TransientHit {
    ti: u32,
    cost: u16,
    cand: Cand,
}

#[derive(Clone, Copy)]
struct StoredHit {
    ti: u32,
    cost: u16,
    class: u32,
    /// c1 = 1 and c0 = 0 for an exact match.
    c1: i128,
    c0: i128,
}

enum Unit {
    Unary(u32),
    /// Outer class in the larger level, partner level.
    Pair(u32, usize),
    /// Fixed zero branch: condition level, positive level.
    IfzZero(u32, usize, usize),
    /// Fixed positive branch: condition level, zero level.
    IfzPositive(u32, usize, usize),
    /// Open body class, count level, base level.
    Body(u32, usize, usize),
    /// Opaque body class, argument level.
    LetBody(u32, usize),
    Transform(u32),
}

pub struct Closed {
    pub vecs: Vec<CV>,
    pub node: Vec<u32>,
    pub cost: Vec<u16>,
    /// Slot of the extended vector, or NIL.
    pub ext: Vec<u32>,
    /// Contains a loop, a transform or a library program.
    pub opaque: Vec<bool>,
    /// Closed classes this class was built from.
    pub kids: Vec<[u32; 3]>,
    pub ext_data: Vec<EV>,
    pub levels: Vec<(usize, usize)>,
    pub index: FxMap<CV, u32>,
    pub cond: Vec<Vec<u32>>,
    pub patterns: FxMap<(u32, u32), u32>,
}

impl Closed {
    pub fn new() -> Self {
        Closed {
            vecs: Vec::new(),
            node: Vec::new(),
            cost: Vec::new(),
            ext: Vec::new(),
            opaque: Vec::new(),
            kids: Vec::new(),
            ext_data: Vec::new(),
            levels: vec![(0, 0)],
            index: FxMap::default(),
            cond: vec![Vec::new()],
            patterns: FxMap::default(),
        }
    }
    pub fn len(&self) -> usize {
        self.vecs.len()
    }
    pub fn range(&self, s: usize) -> (usize, usize) {
        if s < self.levels.len() {
            self.levels[s]
        } else {
            (0, 0)
        }
    }
    fn insert(&mut self, v: CV, cost: usize, node: u32, opaque: bool) -> u32 {
        let id = self.vecs.len() as u32;
        self.vecs.push(v);
        self.node.push(node);
        self.cost.push(cost as u16);
        self.ext.push(NIL);
        self.opaque.push(opaque);
        self.kids.push([NIL; 3]);
        self.index.insert(v, id);
        let p = pattern(&v);
        let full: u32 = (1u32 << NC) - 1;
        if p.0 != 0 && (p.0 | p.1) != full && !self.patterns.contains_key(&p) {
            self.patterns.insert(p, id);
            while self.cond.len() <= cost {
                self.cond.push(Vec::new());
            }
            self.cond[cost].push(id);
        }
        id
    }
    fn set_ext(&mut self, class: u32, e: EV) {
        self.ext[class as usize] = self.ext_data.len() as u32;
        self.ext_data.push(e);
    }
    #[inline(always)]
    fn ext_of(&self, class: u32) -> Option<&EV> {
        let slot = self.ext[class as usize];
        if slot == NIL {
            None
        } else {
            Some(&self.ext_data[slot as usize])
        }
    }
}

pub struct Config {
    pub max_const: i64,
    pub open_max: usize,
    pub count_max: usize,
    pub base_max: usize,
    pub loop_fuel: i64,
    pub loops: bool,
    /// Classes up to this cost keep extended vectors.
    pub ext_max: usize,
    /// Classes up to this cost are transformed.
    pub transform_max: usize,
    pub transforms: bool,
    /// Largest cost of a Let argument.
    pub let_max: usize,
    pub lets: bool,
    /// Classes up to this cost also try the closure c1*x + c0.
    pub affine_max: usize,
    pub threads: usize,
}

pub struct Search {
    pub arena: Arena,
    pub corpus: Corpus,
    pub closed: Closed,
    pub open: Universe<NE>,
    pub cfg: Config,
    pub started: Instant,
    pub fuel: i64,
    pub candidates: u64,
    /// Library programs by cost, inserted at the start of their level.
    pub library: Vec<Vec<u32>>,
}

#[inline(always)]
fn holds(p: u8, v: V) -> bool {
    match p {
        0 => v == 0,
        1 => v != 0,
        2 => v == 1,
        _ => v == 2,
    }
}

/// Apply a sequence transform to the values of a class on 0..M-1.
pub fn transform(kind: u8, e: &EV) -> EV {
    let mut out = [BOT; M];
    match kind {
        K_SUM_EX | K_SUM_IN => {
            let mut acc: V = 0;
            let mut ok = true;
            for n in 0..M {
                if kind == K_SUM_EX {
                    out[n] = if ok { acc } else { BOT };
                }
                if ok {
                    acc = v2(Op::Add, acc, e[n]);
                    ok = acc != BOT;
                }
                if kind == K_SUM_IN {
                    out[n] = if ok { acc } else { BOT };
                }
            }
        }
        K_PROD => {
            let mut acc: V = 1;
            let mut ok = true;
            out[0] = 1;
            for n in 1..M {
                if ok {
                    acc = v2(Op::Mul, acc, e[n]);
                    ok = acc != BOT;
                }
                out[n] = if ok { acc } else { BOT };
            }
        }
        K_DIFF => {
            for n in 0..M - 1 {
                out[n] = v2(Op::Monus, e[n + 1], e[n]);
            }
        }
        k if (K_NTH0..K_NTH0 + PREDICATES).contains(&k) || (K_NTH1..K_NTH1 + PREDICATES).contains(&k) => {
            let one = k >= K_NTH1;
            let p = if one { k - K_NTH1 } else { k - K_NTH0 };
            let mut hits = 0usize;
            if one {
                out[0] = 0;
            }
            for m in 0..M {
                if e[m] == BOT {
                    break;
                }
                if holds(p, e[m]) {
                    let slot = if one { hits + 1 } else { hits };
                    if slot < M {
                        out[slot] = m as V;
                    }
                    hits += 1;
                }
            }
        }
        k if (K_COUNT..K_COUNT + PREDICATES).contains(&k) => {
            let p = k - K_COUNT;
            let mut acc: V = 0;
            for n in 0..M {
                if e[n] == BOT {
                    break;
                }
                if holds(p, e[n]) {
                    acc += 1;
                }
                out[n] = acc;
            }
        }
        _ => {}
    }
    out
}

/// Cost added by a transform on top of its argument.
pub fn overhead(kind: u8) -> usize {
    match kind {
        K_SUM_EX | K_SUM_IN | K_PROD | K_DIFF => 2,
        k if k == K_NTH0 || k == K_NTH1 || k == K_COUNT => 2,
        _ => 3,
    }
}

pub const TRANSFORMS: [u8; 16] = [
    K_SUM_EX,
    K_SUM_IN,
    K_PROD,
    K_DIFF,
    K_NTH0,
    K_NTH0 + 1,
    K_NTH0 + 2,
    K_NTH0 + 3,
    K_NTH1,
    K_NTH1 + 1,
    K_NTH1 + 2,
    K_NTH1 + 3,
    K_COUNT,
    K_COUNT + 1,
    K_COUNT + 2,
    K_COUNT + 3,
];

/// Compare a program's values with a sequence's held-out terms.
/// `Some(true)`: every compared term agrees. `None`: nothing to compare, or
/// a term could not be evaluated or compared exactly.
pub fn verdict(values: &[Option<i128>], seq: &Seq) -> Option<bool> {
    let available = seq.terms.len().min(TRAIN + TEST);
    if available <= TRAIN || (TEST_EXACT && seq.terms.len() < TRAIN + TEST) {
        return None;
    }
    let mut unknown = false;
    for j in TRAIN..available {
        match values[j] {
            Some(v) if seq.terms[j] != BIG => {
                if v != seq.terms[j] {
                    return Some(false);
                }
            }
            _ => unknown = true,
        }
    }
    if unknown {
        None
    } else {
        Some(true)
    }
}

#[inline(always)]
fn head(e: &EV) -> CV {
    let mut v = [0 as V; NC];
    v.copy_from_slice(&e[..NC]);
    v
}

#[inline(always)]
fn shard_of(v: &CV, shards: usize) -> usize {
    let mut h = Fx::default();
    v.hash(&mut h);
    (h.finish() >> 20) as usize % shards
}

impl Search {
    pub fn new(corpus: Corpus, cfg: Config, fuel: i64) -> Self {
        Search {
            arena: Arena::new(),
            corpus,
            closed: Closed::new(),
            open: Universe::new(),
            cfg,
            started: Instant::now(),
            fuel,
            candidates: 0,
            library: Vec::new(),
        }
    }

    /// Constant targets need no search: Const[c] is one node.
    pub fn constants(&mut self) {
        for ti in 0..self.corpus.targets.len() {
            let t = &self.corpus.targets[ti];
            if t.train.iter().all(|x| *x == t.train[0]) {
                let c = t.train[0];
                let node = self.arena.konst(c);
                self.corpus.offer(ti as u32, const_cost(c as i128), node, Mode::Constant);
            }
        }
    }

    pub fn build_open(&mut self) {
        let mut leaves: Vec<(Op, i64, OV)> = vec![(Op::Var, 0, SAMPLE_N), (Op::Acc, 0, SAMPLE_ACC), (Op::Idx, 0, SAMPLE_IDX)];
        for k in 0..=self.cfg.max_const {
            leaves.push((Op::Const, k, [k as V; NE]));
        }
        self.open = crate::universe::build_open(&mut self.arena, &leaves, self.cfg.open_max);
    }

    pub fn add_library(&mut self, cost: usize, node: u32) {
        while self.library.len() <= cost {
            self.library.push(Vec::new());
        }
        self.library[cost].push(node);
    }

    fn interpret(&self, node: u32, len: usize, fuel: i64) -> Vec<V> {
        (0..len)
            .map(|n| match Interp::run(&self.arena.nodes, node, n as i128, fuel) {
                Some(x) => clamp(x),
                None => BOT,
            })
            .collect()
    }

    fn begin_level(&mut self, s: usize) {
        let n = self.closed.len();
        while self.closed.levels.len() <= s {
            self.closed.levels.push((n, n));
        }
        self.closed.levels[s] = (n, n);
        while self.closed.cond.len() <= s {
            self.closed.cond.push(Vec::new());
        }
    }

    fn end_level(&mut self, s: usize) {
        self.closed.levels[s].1 = self.closed.len();
    }

    pub fn leaves(&mut self) {
        self.begin_level(1);
        let lo = self.closed.len();
        let mut e = [0 as V; M];
        for (n, x) in e.iter_mut().enumerate() {
            *x = n as V;
        }
        let node = self.arena.leaf(Op::Var);
        let id = self.closed.insert(head(&e), 1, node, false);
        self.closed.set_ext(id, e);
        for k in 0..=self.cfg.max_const {
            let e = [k as V; M];
            if !self.closed.index.contains_key(&head(&e)) {
                let node = self.arena.konst(k);
                let id = self.closed.insert(head(&e), 1, node, false);
                self.closed.set_ext(id, e);
            }
        }
        self.insert_library(1);
        self.end_level(1);
        self.match_stored(lo, self.closed.len());
    }

    fn insert_library(&mut self, s: usize) {
        if s >= self.library.len() {
            return;
        }
        let nodes: Vec<u32> = self.library[s].clone();
        for node in nodes {
            let v = self.interpret(node, NC, self.fuel);
            let mut cv = [BOT; NC];
            cv.copy_from_slice(&v);
            if all_bot(&cv) || self.closed.index.contains_key(&cv) {
                continue;
            }
            let id = self.closed.insert(cv, s, node, true);
            if s <= self.cfg.ext_max {
                let full = self.interpret(node, M, self.fuel);
                let mut e = [BOT; M];
                e.copy_from_slice(&full);
                self.closed.set_ext(id, e);
            }
        }
    }

    /// All programs of cost exactly `s` built from stored classes.
    pub fn level(&mut self, s: usize, store: bool) {
        self.begin_level(s);
        let lo = self.closed.len();
        if store {
            self.insert_library(s);
        }
        let units = self.units(s);
        let (cands, transient, count) = self.generate(s, store, &units);
        self.candidates += count;
        if store {
            self.merge(s, cands);
        }
        self.end_level(s);
        if store {
            self.match_stored(lo, self.closed.len());
        } else {
            self.apply_transient(transient);
        }
    }

    fn units(&self, s: usize) -> Vec<Unit> {
        let c = &self.closed;
        let mut units: Vec<Unit> = Vec::new();
        let (lo, hi) = c.range(s - 1);
        for x in lo..hi {
            units.push(Unit::Unary(x as u32));
        }
        if s >= 3 {
            for i in 1..=(s - 1) / 2 {
                let j = s - 1 - i;
                let (jlo, jhi) = c.range(j);
                for y in jlo..jhi {
                    units.push(Unit::Pair(y as u32, i));
                }
            }
        }
        if s >= 4 {
            for i in 1..=(s - 3) {
                if i >= c.cond.len() || c.cond[i].is_empty() {
                    continue;
                }
                for j in 1..=(s - 2 - i) {
                    let k = s - 1 - i - j;
                    let (jlo, jhi) = c.range(j);
                    let (klo, khi) = c.range(k);
                    if jhi - jlo >= khi - klo {
                        for z in jlo..jhi {
                            units.push(Unit::IfzZero(z as u32, i, k));
                        }
                    } else {
                        for p in klo..khi {
                            units.push(Unit::IfzPositive(p as u32, i, j));
                        }
                    }
                }
            }
        }
        if self.cfg.loops && s >= 4 {
            for sc in 1..=self.cfg.count_max.min(s - 3) {
                for sb in 1..=self.cfg.base_max.min(s - 2 - sc) {
                    let ss = s - 1 - sc - sb;
                    if ss < 1 || ss > self.cfg.open_max {
                        continue;
                    }
                    let (olo, ohi) = self.open.range(ss);
                    for o in olo..ohi {
                        if self.arena.flags(self.open.node[o]) & F_ACC != 0 {
                            units.push(Unit::Body(o as u32, sc, sb));
                        }
                    }
                }
            }
        }
        if self.cfg.lets && s >= 4 {
            for sy in 2..=self.cfg.let_max.min(s - 2) {
                let sx = s - 1 - sy;
                if sx > self.cfg.ext_max {
                    continue;
                }
                let (xlo, xhi) = c.range(sx);
                for x in xlo..xhi {
                    if c.opaque[x] && c.ext[x] != NIL {
                        units.push(Unit::LetBody(x as u32, sy));
                    }
                }
            }
        }
        if self.cfg.transforms && s >= 3 {
            for extra in 2..=3usize {
                if s <= extra {
                    continue;
                }
                let sx = s - extra;
                if sx > self.cfg.transform_max {
                    continue;
                }
                let (xlo, xhi) = c.range(sx);
                for x in xlo..xhi {
                    if c.ext[x] != NIL {
                        units.push(Unit::Transform(x as u32));
                    }
                }
            }
        }
        units
    }

    fn generate(&self, s: usize, store: bool, units: &[Unit]) -> (Vec<Cand>, Vec<TransientHit>, u64) {
        let threads = self.cfg.threads.max(1);
        let nshards = 512usize;
        let shards: Vec<Mutex<FxMap<CV, Cand>>> = (0..nshards).map(|_| Mutex::new(FxMap::default())).collect();
        let hits: Mutex<Vec<TransientHit>> = Mutex::new(Vec::new());
        let next = AtomicUsize::new(0);
        let total = AtomicU64::new(0);
        std::thread::scope(|scope| {
            for _ in 0..threads {
                scope.spawn(|| {
                    let mut local: Vec<TransientHit> = Vec::new();
                    let mut count = 0u64;
                    loop {
                        let u = next.fetch_add(1, Ordering::Relaxed);
                        if u >= units.len() {
                            break;
                        }
                        self.process(&units[u], s, store, &shards, &mut local, &mut count);
                    }
                    hits.lock().unwrap().extend(local);
                    total.fetch_add(count, Ordering::Relaxed);
                });
            }
        });
        let mut cands: Vec<Cand> = Vec::new();
        for sh in shards {
            cands.extend(sh.into_inner().unwrap().into_values());
        }
        cands.sort_unstable_by_key(|c| c.key());
        (cands, hits.into_inner().unwrap(), total.load(Ordering::Relaxed))
    }

    #[inline(always)]
    fn emit(&self, cand: Cand, s: usize, store: bool, shards: &[Mutex<FxMap<CV, Cand>>], hits: &mut Vec<TransientHit>, count: &mut u64) {
        *count += 1;
        if all_bot(&cand.vec) {
            return;
        }
        if store {
            if self.closed.index.contains_key(&cand.vec) {
                return;
            }
            let mut guard = shards[shard_of(&cand.vec, shards.len())].lock().unwrap();
            match guard.entry(cand.vec) {
                Entry::Occupied(mut e) => {
                    if cand.key() < e.get().key() {
                        e.insert(cand);
                    }
                }
                Entry::Vacant(e) => {
                    e.insert(cand);
                }
            }
        } else {
            for o in 0..=self.corpus.max_window {
                let mut w = [0 as V; TRAIN];
                w.copy_from_slice(&cand.vec[o..o + TRAIN]);
                if w.iter().any(|x| *x == BOT) {
                    continue;
                }
                if let Some(list) = self.corpus.exact.get(&(o as u8, w)) {
                    for &ti in list {
                        let t = &self.corpus.targets[ti as usize];
                        let cost = (s as u16) + shift_cost(t.shift);
                        if cost < t.cost {
                            hits.push(TransientHit { ti, cost, cand });
                        }
                    }
                }
            }
        }
    }

    fn process(&self, unit: &Unit, s: usize, store: bool, shards: &[Mutex<FxMap<CV, Cand>>], hits: &mut Vec<TransientHit>, count: &mut u64) {
        let c = &self.closed;
        match *unit {
            Unit::Unary(x) => {
                let xv = c.vecs[x as usize];
                for op in UNARY {
                    let mut v = [0 as V; NC];
                    for t in 0..NC {
                        v[t] = v1(op, xv[t]);
                    }
                    self.emit(Cand { vec: v, kind: op as u8, a: x, b: NIL, c: NIL }, s, store, shards, hits, count);
                }
            }
            Unit::Pair(y, i) => {
                let yv = c.vecs[y as usize];
                let j = c.cost[y as usize] as usize;
                let (ilo, ihi) = c.range(i);
                let hi = if i == j { (y as usize + 1).min(ihi) } else { ihi };
                for x in ilo..hi {
                    let xv = c.vecs[x];
                    let x = x as u32;
                    for op in COMMUTATIVE {
                        let mut v = [0 as V; NC];
                        for t in 0..NC {
                            v[t] = v2(op, xv[t], yv[t]);
                        }
                        self.emit(Cand { vec: v, kind: op as u8, a: x, b: y, c: NIL }, s, store, shards, hits, count);
                    }
                    for op in ORDERED {
                        let mut v = [0 as V; NC];
                        for t in 0..NC {
                            v[t] = v2(op, xv[t], yv[t]);
                        }
                        self.emit(Cand { vec: v, kind: op as u8, a: x, b: y, c: NIL }, s, store, shards, hits, count);
                        if x != y {
                            let mut v = [0 as V; NC];
                            for t in 0..NC {
                                v[t] = v2(op, yv[t], xv[t]);
                            }
                            self.emit(Cand { vec: v, kind: op as u8, a: y, b: x, c: NIL }, s, store, shards, hits, count);
                        }
                    }
                }
            }
            Unit::IfzZero(z, i, k) => {
                let zv = c.vecs[z as usize];
                let (klo, khi) = c.range(k);
                for &ci in &c.cond[i] {
                    let cv = c.vecs[ci as usize];
                    for p in klo..khi {
                        if p as u32 == z {
                            continue;
                        }
                        let pv = c.vecs[p];
                        let mut v = [0 as V; NC];
                        for t in 0..NC {
                            v[t] = if cv[t] == BOT {
                                BOT
                            } else if cv[t] == 0 {
                                zv[t]
                            } else {
                                pv[t]
                            };
                        }
                        self.emit(Cand { vec: v, kind: Op::Ifz as u8, a: ci, b: z, c: p as u32 }, s, store, shards, hits, count);
                    }
                }
            }
            Unit::IfzPositive(p, i, j) => {
                let pv = c.vecs[p as usize];
                let (jlo, jhi) = c.range(j);
                for &ci in &c.cond[i] {
                    let cv = c.vecs[ci as usize];
                    for z in jlo..jhi {
                        if z as u32 == p {
                            continue;
                        }
                        let zv = c.vecs[z];
                        let mut v = [0 as V; NC];
                        for t in 0..NC {
                            v[t] = if cv[t] == BOT {
                                BOT
                            } else if cv[t] == 0 {
                                zv[t]
                            } else {
                                pv[t]
                            };
                        }
                        self.emit(Cand { vec: v, kind: Op::Ifz as u8, a: ci, b: z as u32, c: p }, s, store, shards, hits, count);
                    }
                }
            }
            Unit::Body(o, sc, sb) => {
                let on = self.open.node[o as usize];
                let op = if self.arena.flags(on) & F_IDX != 0 { Op::Rec } else { Op::Iter };
                let (clo, chi) = c.range(sc);
                let (blo, bhi) = c.range(sb);
                for ci in clo..chi {
                    let cv = c.vecs[ci];
                    // A constant count only unrolls a fixed composition.
                    if cv.iter().all(|x| *x == cv[0]) {
                        continue;
                    }
                    for bi in blo..bhi {
                        let bv = c.vecs[bi];
                        let mut v = [BOT; NC];
                        for n in 0..NC {
                            v[n] = self.run_loop(on, n as i128, cv[n], bv[n]);
                        }
                        self.emit(Cand { vec: v, kind: op as u8, a: ci as u32, b: bi as u32, c: o }, s, store, shards, hits, count);
                    }
                }
            }
            Unit::LetBody(x, sy) => {
                let xe = c.ext_of(x).unwrap();
                let (ylo, yhi) = c.range(sy);
                for y in ylo..yhi {
                    let yv = c.vecs[y];
                    if yv.iter().all(|t| *t == yv[0]) {
                        continue;
                    }
                    let mut v = [BOT; NC];
                    for n in 0..NC {
                        if yv[n] != BOT && (yv[n] as usize) < M {
                            v[n] = xe[yv[n] as usize];
                        }
                    }
                    self.emit(Cand { vec: v, kind: Op::Let as u8, a: y as u32, b: x, c: NIL }, s, store, shards, hits, count);
                }
            }
            Unit::Transform(x) => {
                let xv = c.vecs[x as usize];
                if xv.iter().all(|t| *t == xv[0]) {
                    return;
                }
                let extra = s - c.cost[x as usize] as usize;
                let xe = c.ext_of(x).unwrap();
                for kind in TRANSFORMS {
                    if overhead(kind) != extra {
                        continue;
                    }
                    let e = transform(kind, xe);
                    self.emit(Cand { vec: head(&e), kind, a: x, b: NIL, c: NIL }, s, store, shards, hits, count);
                }
            }
        }
    }

    #[inline]
    fn run_loop(&self, body: u32, n: i128, count: V, base: V) -> V {
        if count == BOT || base == BOT {
            return BOT;
        }
        let mut it = Interp::new(&self.arena.nodes, self.cfg.loop_fuel);
        let mut acc = base as i128;
        let mut i: i128 = 0;
        while i < count as i128 {
            match it.ev(body, &Env { n, acc, idx: i }, &[]) {
                Some(x) => acc = x,
                None => return BOT,
            }
            i += 1;
        }
        clamp(acc)
    }

    /// The condition "predicate p holds for x at `at`", zero when it holds.
    fn condition(&mut self, p: u8, at: u32, x: u32) -> u32 {
        let call = self.arena.bin(Op::Let, at, x);
        match p {
            0 => call,
            1 => {
                let one = self.arena.konst(1);
                let zero = self.arena.konst(0);
                self.arena.tri(Op::Ifz, call, one, zero)
            }
            _ => {
                let k = (p - 1) as i64;
                let var = self.arena.leaf(Op::Var);
                let k1 = self.arena.konst(k);
                let above = self.arena.bin(Op::Monus, var, k1);
                let k2 = self.arena.konst(k);
                let var2 = self.arena.leaf(Op::Var);
                let below = self.arena.bin(Op::Monus, k2, var2);
                let distance = self.arena.bin(Op::Add, above, below);
                self.arena.bin(Op::Let, call, distance)
            }
        }
    }

    /// Build the Recursor program of a candidate.
    fn materialize(&mut self, cand: &Cand) -> u32 {
        let node = |cl: u32, c: &Closed| c.node[cl as usize];
        let (a, b, cc) = (cand.a, cand.b, cand.c);
        if cand.kind < 64 {
            let op = ALL_OPS[cand.kind as usize];
            return match op {
                Op::Succ | Op::Pred | Op::Half => {
                    let x = node(a, &self.closed);
                    self.arena.un(op, x)
                }
                Op::Ifz => {
                    let (x, y, z) = (node(a, &self.closed), node(b, &self.closed), node(cc, &self.closed));
                    self.arena.tri(op, x, y, z)
                }
                Op::Iter | Op::Rec => {
                    let (x, y) = (node(a, &self.closed), node(b, &self.closed));
                    let body = self.open.node[cc as usize];
                    self.arena.tri(op, x, y, body)
                }
                _ => {
                    let (x, y) = (node(a, &self.closed), node(b, &self.closed));
                    self.arena.bin(op, x, y)
                }
            };
        }
        let x = node(a, &self.closed);
        let var = self.arena.leaf(Op::Var);
        let acc = self.arena.leaf(Op::Acc);
        let idx = self.arena.leaf(Op::Idx);
        match cand.kind {
            K_SUM_EX | K_SUM_IN => {
                let count = if cand.kind == K_SUM_EX { var } else { self.arena.un(Op::Succ, var) };
                let zero = self.arena.konst(0);
                let call = self.arena.bin(Op::Let, idx, x);
                let step = self.arena.bin(Op::Add, acc, call);
                self.arena.tri(Op::Rec, count, zero, step)
            }
            K_PROD => {
                let one = self.arena.konst(1);
                let next = self.arena.un(Op::Succ, idx);
                let call = self.arena.bin(Op::Let, next, x);
                let step = self.arena.bin(Op::Mul, acc, call);
                self.arena.tri(Op::Rec, var, one, step)
            }
            K_DIFF => {
                let next = self.arena.un(Op::Succ, var);
                let call = self.arena.bin(Op::Let, next, x);
                self.arena.bin(Op::Monus, call, x)
            }
            k if (K_NTH0..K_NTH1 + PREDICATES).contains(&k) => {
                let one = k >= K_NTH1;
                let p = if one { k - K_NTH1 } else { k - K_NTH0 };
                let cond = self.condition(p, acc, x);
                let advance = self.arena.un(Op::Succ, acc);
                let seek = self.arena.tri(Op::While, acc, cond, advance);
                let step = self.arena.un(Op::Succ, seek);
                let count = if one { var } else { self.arena.un(Op::Succ, var) };
                let zero = self.arena.konst(0);
                let iter = self.arena.tri(Op::Iter, count, zero, step);
                self.arena.un(Op::Pred, iter)
            }
            _ => {
                let p = cand.kind - K_COUNT;
                let cond = self.condition(p, idx, x);
                let bump = self.arena.un(Op::Succ, acc);
                let step = self.arena.tri(Op::Ifz, cond, bump, acc);
                let count = self.arena.un(Op::Succ, var);
                let zero = self.arena.konst(0);
                self.arena.tri(Op::Rec, count, zero, step)
            }
        }
    }

    /// Extended values of a freshly inserted class.
    fn extend(&self, cand: &Cand, node: u32) -> EV {
        let c = &self.closed;
        let mut e = [BOT; M];
        if cand.kind < 64 {
            let op = ALL_OPS[cand.kind as usize];
            match op {
                Op::Succ | Op::Pred | Op::Half => {
                    let x = c.ext_of(cand.a).unwrap();
                    for n in 0..M {
                        e[n] = v1(op, x[n]);
                    }
                }
                Op::Add | Op::Mul | Op::Monus | Op::Rem | Op::Quot => {
                    let x = c.ext_of(cand.a).unwrap();
                    let y = c.ext_of(cand.b).unwrap();
                    for n in 0..M {
                        e[n] = v2(op, x[n], y[n]);
                    }
                }
                Op::Ifz => {
                    let x = c.ext_of(cand.a).unwrap();
                    let y = c.ext_of(cand.b).unwrap();
                    let z = c.ext_of(cand.c).unwrap();
                    for n in 0..M {
                        e[n] = if x[n] == BOT {
                            BOT
                        } else if x[n] == 0 {
                            y[n]
                        } else {
                            z[n]
                        };
                    }
                }
                Op::Let => {
                    let y = c.ext_of(cand.a).unwrap();
                    let x = c.ext_of(cand.b).unwrap();
                    for n in 0..M {
                        if y[n] != BOT && (y[n] as usize) < M {
                            e[n] = x[y[n] as usize];
                        }
                    }
                }
                _ => {
                    // Loops: evaluate the stored program exactly.
                    for n in 0..M {
                        e[n] = match Interp::run(&self.arena.nodes, node, n as i128, self.cfg.loop_fuel * 8) {
                            Some(x) => clamp(x),
                            None => BOT,
                        };
                    }
                }
            }
        } else {
            e = transform(cand.kind, c.ext_of(cand.a).unwrap());
        }
        e
    }

    fn merge(&mut self, s: usize, cands: Vec<Cand>) {
        let lo = self.closed.len();
        let mut fresh: Vec<(Cand, u32)> = Vec::with_capacity(cands.len());
        for cand in cands {
            let node = self.materialize(&cand);
            let opaque = if cand.kind >= 64 {
                true
            } else if matches!(ALL_OPS[cand.kind as usize], Op::Iter | Op::Rec | Op::Let) {
                true
            } else {
                [cand.a, cand.b, cand.c].iter().any(|&ch| ch != NIL && self.closed.opaque[ch as usize])
            };
            let id = self.closed.insert(cand.vec, s, node, opaque);
            self.closed.kids[id as usize] = cand.kids();
            fresh.push((cand, node));
        }
        if s <= self.cfg.ext_max && !fresh.is_empty() {
            let threads = self.cfg.threads.max(1);
            let chunk = (fresh.len() + threads - 1) / threads;
            let this: &Search = self;
            let parts: Vec<Vec<EV>> = std::thread::scope(|scope| {
                let handles: Vec<_> = fresh
                    .chunks(chunk)
                    .map(|part| scope.spawn(move || part.iter().map(|(cand, node)| this.extend(cand, *node)).collect::<Vec<EV>>()))
                    .collect();
                handles.into_iter().map(|h| h.join().unwrap()).collect()
            });
            let mut class = lo as u32;
            for part in parts {
                for e in part {
                    self.closed.set_ext(class, e);
                    class += 1;
                }
            }
        }
    }

    fn affine_hits(&self, class: u32, o: usize, w: &[V; TRAIN], out: &mut Vec<StoredHit>) {
        let (norm, sx) = match normalize(w) {
            Some(x) => x,
            None => return,
        };
        let list = match self.corpus.affine.get(&(o as u8, norm)) {
            Some(l) => l,
            None => return,
        };
        let size = self.closed.cost[class as usize] as usize;
        for &ti in list {
            let t = &self.corpus.targets[ti as usize];
            let (_, st) = normalize(&t.train).unwrap();
            if st % sx != 0 {
                continue;
            }
            let c1 = st / sx;
            let c0 = t.train[0] as i128 - c1 * w[0] as i128;
            if (c1 == 1 && c0 == 0) || c1.abs() >= VMAX as i128 || c0.abs() >= VMAX as i128 {
                continue;
            }
            let scaled = size + if c1.abs() != 1 { 1 + const_cost(c1) as usize } else { 0 };
            let mut total = if c1 > 0 {
                scaled + if c0 != 0 { 1 + const_cost(c0) as usize } else { 0 }
            } else {
                if c0 <= 0 {
                    continue;
                }
                scaled + 1 + const_cost(c0) as usize
            };
            total += shift_cost(t.shift) as usize;
            if total < t.cost as usize {
                out.push(StoredHit { ti, cost: total as u16, class, c1, c0 });
            }
        }
    }

    /// Look the classes lo..hi up against every training window.
    fn match_stored(&mut self, lo: usize, hi: usize) {
        if hi <= lo {
            return;
        }
        let threads = self.cfg.threads.max(1);
        let chunk = (hi - lo + threads - 1) / threads;
        let this: &Search = self;
        let mut hits: Vec<StoredHit> = std::thread::scope(|scope| {
            let handles: Vec<_> = (0..threads)
                .map(|w| {
                    scope.spawn(move || {
                        let mut out: Vec<StoredHit> = Vec::new();
                        let start = (lo + w * chunk).min(hi);
                        let end = (lo + (w + 1) * chunk).min(hi);
                        for class in start..end {
                            let vec = this.closed.vecs[class];
                            let size = this.closed.cost[class] as usize;
                            for o in 0..=this.corpus.max_window {
                                let mut win = [0 as V; TRAIN];
                                win.copy_from_slice(&vec[o..o + TRAIN]);
                                if win.iter().any(|x| *x == BOT) {
                                    continue;
                                }
                                if let Some(list) = this.corpus.exact.get(&(o as u8, win)) {
                                    for &ti in list {
                                        let t = &this.corpus.targets[ti as usize];
                                        let cost = size + shift_cost(t.shift) as usize;
                                        if cost < t.cost as usize {
                                            out.push(StoredHit { ti, cost: cost as u16, class: class as u32, c1: 1, c0: 0 });
                                        }
                                    }
                                }
                                if size <= this.cfg.affine_max {
                                    this.affine_hits(class as u32, o, &win, &mut out);
                                }
                            }
                        }
                        out
                    })
                })
                .collect();
            handles.into_iter().flat_map(|h| h.join().unwrap()).collect()
        });
        hits.sort_unstable_by_key(|h| (h.ti, h.cost, h.class, h.c1, h.c0));
        for h in hits {
            let (best, shift) = {
                let t = &self.corpus.targets[h.ti as usize];
                (t.cost, t.shift)
            };
            if h.cost >= best {
                continue;
            }
            let node = self.closed.node[h.class as usize];
            let (program, mode) = if h.c1 == 1 && h.c0 == 0 {
                (node, Mode::Closed)
            } else {
                let m = if h.c1.abs() != 1 {
                    let k = self.arena.konst(h.c1.abs() as i64);
                    self.arena.bin(Op::Mul, k, node)
                } else {
                    node
                };
                let p = if h.c1 > 0 {
                    if h.c0 > 0 {
                        let k = self.arena.konst(h.c0 as i64);
                        self.arena.bin(Op::Add, m, k)
                    } else if h.c0 < 0 {
                        let k = self.arena.konst((-h.c0) as i64);
                        self.arena.bin(Op::Monus, m, k)
                    } else {
                        m
                    }
                } else {
                    let k = self.arena.konst(h.c0 as i64);
                    self.arena.bin(Op::Monus, k, m)
                };
                (p, Mode::Affine)
            };
            let program = shifted(&mut self.arena, program, shift);
            if self.corpus.offer(h.ti, h.cost, program, mode) {
                self.corpus.targets[h.ti as usize].from = [h.class, NIL, NIL];
            }
        }
    }

    fn apply_transient(&mut self, mut hits: Vec<TransientHit>) {
        hits.sort_unstable_by_key(|h| (h.ti, h.cost, h.cand.key()));
        for h in hits {
            let (best, shift) = {
                let t = &self.corpus.targets[h.ti as usize];
                (t.cost, t.shift)
            };
            if h.cost >= best {
                continue;
            }
            let node = self.materialize(&h.cand);
            let program = shifted(&mut self.arena, node, shift);
            if self.corpus.offer(h.ti, h.cost, program, Mode::Closed) {
                self.corpus.targets[h.ti as usize].from = h.cand.kids();
            }
        }
    }

    /// For every closed class, the number of targets whose selected program
    /// is built from it. Classes reused by many targets are library material.
    pub fn references(&self) -> Vec<u32> {
        let n = self.closed.len();
        let mut refs = vec![0u32; n];
        let mut stamp = vec![u32::MAX; n];
        let mut stack: Vec<u32> = Vec::new();
        for (ti, t) in self.corpus.targets.iter().enumerate() {
            if t.node == NIL {
                continue;
            }
            stack.clear();
            stack.extend(t.from.iter().copied().filter(|c| *c != NIL));
            while let Some(c) = stack.pop() {
                if stamp[c as usize] == ti as u32 {
                    continue;
                }
                stamp[c as usize] = ti as u32;
                refs[c as usize] += 1;
                stack.extend(self.closed.kids[c as usize].iter().copied().filter(|k| *k != NIL));
            }
        }
        refs
    }

    /// Diagnostic score against held-out terms, when the input carries them.
    /// It never feeds anything back into selection.
    pub fn score(&self, verbose: bool) -> Score {
        let threads = self.cfg.threads.max(1);
        let n = self.corpus.targets.len();
        let chunk = (n + threads - 1) / threads;
        let this: &Search = self;
        let parts: Vec<Score> = std::thread::scope(|scope| {
            let handles: Vec<_> = (0..threads)
                .map(|w| {
                    scope.spawn(move || {
                        let mut sc = Score::default();
                        for ti in (w * chunk).min(n)..((w + 1) * chunk).min(n) {
                            let t = &this.corpus.targets[ti];
                            if t.node == NIL {
                                continue;
                            }
                            sc.targets_fit += 1;
                            let values: Vec<Option<i128>> = (0..(TRAIN + TEST))
                                .map(|j| Interp::run(&this.arena.nodes, t.node, t.offset as i128 + j as i128, this.fuel))
                                .collect();
                            if !(0..TRAIN).all(|j| values[j] == Some(t.train[j] as i128)) {
                                sc.inconsistent += 1;
                                if verbose && sc.inconsistent <= 3 {
                                    eprintln!("INCONSISTENT {:?} {} -> {:?}", t.train, this.arena.text(t.node), &values[..TRAIN]);
                                }
                                continue;
                            }
                            for &si in &t.seqs {
                                let seq = &this.corpus.seqs[si as usize];
                                sc.train_fit += 1;
                                match verdict(&values, seq) {
                                    Some(true) => sc.joint_fit += 1,
                                    Some(false) => {}
                                    None => sc.unverified += 1,
                                }
                            }
                        }
                        sc
                    })
                })
                .collect();
            handles.into_iter().map(|h| h.join().unwrap()).collect()
        });
        let mut total = Score::default();
        for p in parts {
            total.targets_fit += p.targets_fit;
            total.train_fit += p.train_fit;
            total.joint_fit += p.joint_fit;
            total.unverified += p.unverified;
            total.inconsistent += p.inconsistent;
        }
        total
    }

    pub fn report(&self, label: &str, score: bool) {
        let fit = self.corpus.targets.iter().filter(|t| t.node != NIL).count();
        if score {
            let sc = self.score(true);
            println!(
                "[{:7.1}s] {:<20} classes={:>10} cand={:>13} | targets={:>6} train={:>6} joint={:>6} unverified={:>4} inconsistent={}",
                self.started.elapsed().as_secs_f64(),
                label,
                self.closed.len(),
                self.candidates,
                sc.targets_fit,
                sc.train_fit,
                sc.joint_fit,
                sc.unverified,
                sc.inconsistent
            );
        } else {
            println!(
                "[{:7.1}s] {:<20} classes={:>10} cand={:>13} | targets={:>6}",
                self.started.elapsed().as_secs_f64(),
                label,
                self.closed.len(),
                self.candidates,
                fit
            );
        }
        println!(
            "@status {{\"elapsed\":{:.1},\"stage\":\"{}\",\"classes\":{},\"candidates\":{},\"targets\":{}}}",
            self.started.elapsed().as_secs_f64(),
            label,
            self.closed.len(),
            self.candidates,
            fit
        );
    }
}
