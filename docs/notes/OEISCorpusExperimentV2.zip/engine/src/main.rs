//! recursor-engine: a proposer of Recursor programs for integer sequences.
//!
//! Input: a tab-separated file `id <TAB> offset <TAB> comma-separated terms`.
//! Only the first eight terms of each line are used for search and
//! selection. Later terms, when present, feed the optional diagnostic score.
//!
//! Output: one line per training target with the cheapest program found.
//! Every program is revalidated by the paclet's reference interpreter.

mod closed;
mod corpus;
mod lang;
mod recur;
mod solve;
mod universe;

use closed::*;
use corpus::*;
use std::io::{BufRead, Write};

fn arg<T: std::str::FromStr>(args: &[String], name: &str, default: T) -> T {
    args.iter()
        .position(|a| a == name)
        .and_then(|i| args.get(i + 1))
        .and_then(|v| v.parse().ok())
        .unwrap_or(default)
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.iter().any(|a| a == "--help" || a == "-h") {
        println!("{}", include_str!("../USAGE.txt"));
        return;
    }
    let data: String = arg(&args, "--data", "data/sequences.tsv".to_string());
    let max_size: usize = arg(&args, "--max-size", 9);
    let store_size: usize = arg(&args, "--store-size", max_size);
    let out: String = arg(&args, "--out", String::new());
    let verdicts: String = arg(&args, "--verdicts", String::new());
    let library: String = arg(&args, "--library", String::new());
    let score: bool = arg(&args, "--score", 0) != 0;
    let rec_size: usize = arg(&args, "--rec-size", 6);
    let bin_size: usize = arg(&args, "--bin-size", 6);
    let rec_const: i64 = arg(&args, "--rec-const", 3);
    let solvers: bool = arg(&args, "--solvers", 1) != 0;
    let cfg = Config {
        max_const: arg(&args, "--max-const", 3),
        open_max: arg(&args, "--open-max", 6),
        count_max: arg(&args, "--count-max", 3),
        base_max: arg(&args, "--base-max", 3),
        loop_fuel: arg(&args, "--loop-fuel", 4000),
        loops: arg(&args, "--loops", 1) != 0,
        ext_max: arg(&args, "--ext-max", 9),
        transform_max: arg(&args, "--transform-max", 8),
        transforms: arg(&args, "--transforms", 1) != 0,
        let_max: arg(&args, "--let-max", 3),
        lets: arg(&args, "--lets", 1) != 0,
        affine_max: arg(&args, "--affine-max", 9),
        threads: arg(&args, "--threads", 12),
    };
    let threads = cfg.threads;

    let solved_file: String = arg(&args, "--solved", String::new());
    let mut solved: std::collections::HashSet<String> = std::collections::HashSet::new();
    if !solved_file.is_empty() {
        let file = std::fs::File::open(&solved_file).unwrap_or_else(|e| panic!("cannot open {}: {}", solved_file, e));
        for line in std::io::BufReader::new(file).lines() {
            solved.insert(line.unwrap());
        }
    }
    let max_classes: usize = arg(&args, "--max-classes", 40_000_000);
    let time_limit: f64 = arg(&args, "--time-limit", 1.0e12);
    let corpus = Corpus::load(&data, NC - TRAIN, &solved);
    println!(
        "sequences={} targets={} unreachable={} already_solved={}",
        corpus.seqs.len(),
        corpus.targets.len(),
        corpus.unreachable,
        corpus.solved
    );
    let mut s = Search::new(corpus, cfg, arg(&args, "--fuel", 2_000_000));

    s.constants();
    s.report("constants", score);

    if solvers {
        let fuel = s.fuel;
        let improved = solve::search(&mut s.arena, &mut s.corpus, fuel, threads);
        let summary: Vec<String> = improved.iter().map(|(mode, count)| format!("{}={}", mode.name(), count)).collect();
        println!("solvers: {}", summary.join(" "));
        s.report("solvers", score);
    }

    for (family, size, label) in [(recur::Family::Linear, rec_size, "recurrences"), (recur::Family::Binary, bin_size, "binary recurrences")] {
        if size == 0 {
            continue;
        }
        let bodies = recur::build_bodies(&mut s.arena, family, rec_const, size);
        let dag = recur::build_dag(&s.arena, &bodies, family);
        let improved = recur::search(&mut s.arena, &mut s.corpus, &dag, threads);
        println!("{}: {} bodies, selected for {} targets", label, bodies.len(), improved);
        s.report(label, score);
    }

    if !library.is_empty() {
        let file = std::fs::File::open(&library).unwrap_or_else(|e| panic!("cannot open {}: {}", library, e));
        let (mut loaded, mut bad) = (0usize, 0usize);
        for line in std::io::BufReader::new(file).lines() {
            let line = line.unwrap();
            let mut parts = line.splitn(2, '\t');
            let cost: usize = match parts.next().and_then(|c| c.parse().ok()) {
                Some(c) => c,
                None => continue,
            };
            match parts.next().and_then(|text| lang::parse(&mut s.arena, text)) {
                Some(node) if cost >= 1 && cost <= store_size => {
                    s.add_library(cost, node);
                    loaded += 1;
                }
                _ => bad += 1,
            }
        }
        println!("library: {} programs loaded, {} skipped", loaded, bad);
    }

    if max_size >= 1 {
        if s.cfg.loops {
            s.build_open();
            let sizes: Vec<usize> = (1..s.open.levels.len()).map(|k| s.open.levels[k].1 - s.open.levels[k].0).collect();
            println!("loop bodies: {} classes, by size {:?}", s.open.len(), sizes);
        }
        s.leaves();
        s.report("cost 1", score);
        let mut sizes: Vec<usize> = vec![s.closed.len()];
        for size in 2..=max_size {
            // The level after the last stored one is matched without being
            // kept; nothing can be built beyond it. A level is kept only if
            // its projected size, from the growth of the last two levels,
            // fits the class budget.
            let last = *sizes.last().unwrap();
            let growth = if sizes.len() >= 2 && sizes[sizes.len() - 2] > 0 { last as f64 / sizes[sizes.len() - 2] as f64 } else { 4.0 };
            let projected = s.closed.len() as f64 + last as f64 * growth.max(1.0);
            let store = size <= store_size && projected < max_classes as f64 && s.started.elapsed().as_secs_f64() < time_limit;
            let before = s.closed.len();
            s.level(size, store);
            sizes.push(s.closed.len() - before);
            s.report(&format!("cost {}{}", size, if store { "" } else { " (unstored)" }), score);
            if !store {
                break;
            }
        }
    }

    if !out.is_empty() {
        let mut f = std::io::BufWriter::new(std::fs::File::create(&out).unwrap());
        for t in &s.corpus.targets {
            if t.node == lang::NIL {
                continue;
            }
            let train: Vec<String> = t.train.iter().map(|x| x.to_string()).collect();
            writeln!(f, "{}\t{}\t{}\t{}\t{}\t{}", t.offset, train.join(","), t.cost, t.mode.name(), s.arena.size(t.node), s.arena.text(t.node)).unwrap();
        }
    }
    let candidates: String = arg(&args, "--library-out", String::new());
    if !candidates.is_empty() {
        // Building blocks for the next round: closed classes reused by
        // several selected programs, and recurrences found for single targets.
        let refs = s.references();
        let mut f = std::io::BufWriter::new(std::fs::File::create(&candidates).unwrap());
        for class in 0..s.closed.len() {
            if refs[class] >= 2 && s.closed.opaque[class] && s.closed.cost[class] >= 4 {
                writeln!(f, "{}\t{}\tClass\t{}", refs[class], s.closed.cost[class], s.arena.text(s.closed.node[class])).unwrap();
            }
        }
        for t in &s.corpus.targets {
            if t.node != lang::NIL && matches!(t.mode, Mode::Recurrence | Mode::Linear | Mode::Hypergeometric | Mode::Holonomic) {
                writeln!(f, "{}\t{}\t{}\t{}", t.seqs.len(), t.cost, t.mode.name(), s.arena.text(t.node)).unwrap();
            }
        }
    }
    if !verdicts.is_empty() {
        let mut f = std::io::BufWriter::new(std::fs::File::create(&verdicts).unwrap());
        for t in &s.corpus.targets {
            if t.node == lang::NIL {
                continue;
            }
            let program = s.arena.text(t.node);
            let values: Vec<Option<i128>> = (0..(TRAIN + TEST)).map(|j| lang::Interp::run(&s.arena.nodes, t.node, t.offset as i128 + j as i128, s.fuel)).collect();
            for &si in &t.seqs {
                let seq = &s.corpus.seqs[si as usize];
                let verdict = match closed::verdict(&values, seq) {
                    Some(true) => "1",
                    Some(false) => "0",
                    None => "?",
                };
                writeln!(f, "{}\t{}\t{}\t{}\t{}", seq.id, t.cost, t.mode.name(), verdict, program).unwrap();
            }
        }
    }
    println!("@done {{\"elapsed\":{:.1}}}", s.started.elapsed().as_secs_f64());
}
