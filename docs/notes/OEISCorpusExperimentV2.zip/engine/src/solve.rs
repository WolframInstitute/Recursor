//! Algebraic sketches: constants determined by exact linear algebra.
//!
//! Enumeration only reaches small constants. These sketches solve for
//! arbitrary integer constants and keep a result only when spare training
//! terms confirm it:
//!
//! - P-recursive recurrences sum_k p_k(i) a(i-k) = c with polynomial
//!   coefficients. Degree zero gives linear recurrences with constant
//!   coefficients; order one gives hypergeometric terms.
//! - Periodic increments a(i) = a(i-k) + m.
//! - Polynomials in Newton form.
//! - A constant tail after exceptional initial terms.
//!
//! The linear algebra runs modulo a prime. Integer coefficients are
//! recovered from the residues and every emitted program is then checked
//! exactly against the training window by the interpreter.

use crate::corpus::*;
use crate::lang::*;
use crate::recur;

const P: u64 = (1u64 << 61) - 1;
/// Largest recovered coefficient magnitude.
const BOUND: i128 = 1i128 << 40;
/// Largest scale tried when clearing the denominator of the null vector.
const SCALES: u64 = 4096;

#[inline(always)]
fn mulmod(a: u64, b: u64) -> u64 {
    ((a as u128 * b as u128) % P as u128) as u64
}

fn powmod(mut a: u64, mut e: u64) -> u64 {
    let mut r = 1u64;
    while e > 0 {
        if e & 1 == 1 {
            r = mulmod(r, a);
        }
        a = mulmod(a, a);
        e >>= 1;
    }
    r
}

#[inline(always)]
fn residue(x: i128) -> u64 {
    (((x % P as i128) + P as i128) % P as i128) as u64
}

/// The representative of a residue closest to zero.
#[inline(always)]
fn centered(x: u64) -> i128 {
    if x > P / 2 {
        x as i128 - P as i128
    } else {
        x as i128
    }
}

/// Row-reduce modulo P in place. Returns the pivot column of each pivot row.
fn reduce(m: &mut [Vec<u64>], cols: usize) -> Vec<usize> {
    let rows = m.len();
    let mut pivots = Vec::new();
    let mut r = 0;
    for c in 0..cols {
        if r == rows {
            break;
        }
        let p = match (r..rows).find(|&i| m[i][c] != 0) {
            Some(p) => p,
            None => continue,
        };
        m.swap(r, p);
        let inv = powmod(m[r][c], P - 2);
        for x in m[r].iter_mut() {
            *x = mulmod(*x, inv);
        }
        for i in 0..rows {
            if i != r && m[i][c] != 0 {
                let f = m[i][c];
                for k in c..cols {
                    let delta = mulmod(f, m[r][k]);
                    m[i][k] = (m[i][k] + P - delta) % P;
                }
            }
        }
        pivots.push(c);
        r += 1;
    }
    pivots
}

/// The one-dimensional integer null space of a matrix, or `None`.
fn null_vector(mut m: Vec<Vec<u64>>, cols: usize) -> Option<Vec<i128>> {
    let pivots = reduce(&mut m, cols);
    if pivots.len() + 1 != cols {
        return None;
    }
    let free = (0..cols).find(|c| !pivots.contains(c))?;
    let mut x = vec![0u64; cols];
    x[free] = 1;
    for (r, &c) in pivots.iter().enumerate() {
        x[c] = (P - m[r][free]) % P;
    }
    for scale in 1..=SCALES {
        let v: Vec<i128> = x.iter().map(|&xi| centered(mulmod(xi, scale))).collect();
        if v.iter().all(|c| c.abs() <= BOUND) {
            let g = v.iter().fold(0i128, |a, b| gcd(a, *b)).max(1);
            return Some(v.iter().map(|c| c / g).collect());
        }
    }
    None
}

fn sum(arena: &mut Arena, terms: &[u32]) -> u32 {
    let mut acc = terms[0];
    for &t in &terms[1..] {
        acc = arena.bin(Op::Add, acc, t);
    }
    acc
}

fn scaled(arena: &mut Arena, c: i128, x: u32) -> u32 {
    if c.abs() == 1 {
        x
    } else {
        let k = arena.konst(c.abs() as i64);
        arena.bin(Op::Mul, k, x)
    }
}

/// positive - negative with truncated subtraction; `None` when nothing is
/// positive.
fn signed(arena: &mut Arena, pos: &[u32], neg: &[u32]) -> Option<u32> {
    if pos.is_empty() {
        return None;
    }
    let p = sum(arena, pos);
    if neg.is_empty() {
        Some(p)
    } else {
        let n = sum(arena, neg);
        Some(arena.bin(Op::Monus, p, n))
    }
}

/// Idx^e as a product; `None` for e = 0.
fn index_power(arena: &mut Arena, e: usize) -> Option<u32> {
    if e == 0 {
        return None;
    }
    let mut power = arena.leaf(Op::Idx);
    for _ in 1..e {
        let i = arena.leaf(Op::Idx);
        power = arena.bin(Op::Mul, power, i);
    }
    Some(power)
}

fn poly_value(coefficients: &[i128], i: i128) -> Option<i128> {
    let mut acc: i128 = 0;
    let mut power: i128 = 1;
    for &c in coefficients {
        acc = acc.checked_add(c.checked_mul(power)?)?;
        power = power.checked_mul(i)?;
    }
    Some(acc)
}

struct Shape {
    order: usize,
    degree: usize,
    constant: bool,
    skip: usize,
}

impl Shape {
    fn unknowns(&self) -> usize {
        (self.order + 1) * (self.degree + 1) + self.constant as usize
    }
    fn equations(&self) -> usize {
        TRAIN - self.order - self.skip
    }
}

/// Recurrence shapes confirmed by enough spare equations, simplest first.
fn shapes() -> Vec<Shape> {
    let mut all = Vec::new();
    for order in 1..=9usize {
        for degree in 0..=5usize {
            for constant in [false, true] {
                if constant && (degree > 0 || cfg!(feature = "p20")) {
                    continue;
                }
                for skip in 0..=2usize {
                    if order + skip >= TRAIN {
                        continue;
                    }
                    let s = Shape { order, degree, constant, skip };
                    if s.equations() >= s.unknowns() - 1 + SPARE && order + skip <= recur::MAX_SEEDS {
                        all.push(s);
                    }
                }
            }
        }
    }
    all.sort_by_key(|s| (s.unknowns() + s.skip, s.order, s.degree, s.skip));
    all
}

/// sum_{k=0..r} p_k(i) a(i-k) + c = 0 with polynomial p_k.
fn precursive(arena: &mut Arena, t: &Target, shapes: &[Shape], fuel: i64) -> Option<(u32, u16, Mode)> {
    let tr = &t.train;
    let mut best: Option<(u32, u16, Mode)> = None;
    for shape in shapes {
        let (r, d) = (shape.order, shape.degree);
        let seeds = r + shape.skip;
        let cols = shape.unknowns();
        // Columns: a(i-r)..a(i-1) blocks (degree high to low), the constant,
        // then the a(i) block; the last column is the constant term of p_0.
        let mut m: Vec<Vec<u64>> = Vec::with_capacity(TRAIN - seeds);
        for j in seeds..TRAIN {
            let i = residue(t.offset as i128 + j as i128);
            let mut powers = vec![1u64; d + 1];
            for e in 1..=d {
                powers[e] = mulmod(powers[e - 1], i);
            }
            let mut row = Vec::with_capacity(cols);
            for k in (1..=r).rev() {
                let v = residue(tr[j - k] as i128);
                for e in (0..=d).rev() {
                    row.push(mulmod(powers[e], v));
                }
            }
            if shape.constant {
                row.push(1);
            }
            let v = residue(tr[j] as i128);
            for e in (0..=d).rev() {
                row.push(mulmod(powers[e], v));
            }
            m.push(row);
        }
        let null = match null_vector(m, cols) {
            Some(v) => v,
            None => continue,
        };
        // Unpack: coefficient[k][e] of i^e a(i-k).
        let mut coefficient = vec![vec![0i128; d + 1]; r + 1];
        let mut at = 0;
        for k in (1..=r).rev() {
            for e in (0..=d).rev() {
                coefficient[k][e] = null[at];
                at += 1;
            }
        }
        let mut constant = 0i128;
        if shape.constant {
            constant = null[at];
            at += 1;
        }
        for e in (0..=d).rev() {
            coefficient[0][e] = null[at];
            at += 1;
        }
        // Make the leading polynomial positive on the checked positions.
        let first = t.offset as i128 + seeds as i128;
        let sign = match poly_value(&coefficient[0], first) {
            Some(x) if x > 0 => 1,
            Some(x) if x < 0 => -1,
            _ => continue,
        };
        if sign < 0 {
            for row in coefficient.iter_mut() {
                for c in row.iter_mut() {
                    *c = -*c;
                }
            }
            constant = -constant;
        }
        if !(seeds..TRAIN).all(|j| matches!(poly_value(&coefficient[0], t.offset as i128 + j as i128), Some(x) if x > 0)) {
            continue;
        }
        // a(i) = (-sum_{k>=1} p_k(i) a(i-k) - c) / p_0(i)
        let mut pos = Vec::new();
        let mut neg = Vec::new();
        let mut cost: u16 = 1 + recur::seed_cost(tr, seeds);
        let mut lag = 0;
        for k in 1..=r {
            for e in 0..=d {
                let c = -coefficient[k][e];
                if c == 0 {
                    continue;
                }
                lag = lag.max(k);
                cost += const_cost(c) + e as u16 + 1;
                let mut term = arena.mk(Op::Prev, k as i64, NIL, NIL, NIL);
                if let Some(power) = index_power(arena, e) {
                    term = arena.bin(Op::Mul, power, term);
                }
                let term = scaled(arena, c, term);
                if c > 0 {
                    pos.push(term)
                } else {
                    neg.push(term)
                }
            }
        }
        if lag == 0 {
            continue;
        }
        if constant != 0 {
            cost += const_cost(constant) + 1;
            let node = arena.konst(constant.abs() as i64);
            if -constant > 0 {
                pos.push(node)
            } else {
                neg.push(node)
            }
        }
        let numerator = match signed(arena, &pos, &neg) {
            Some(n) => n,
            None => continue,
        };
        let monic = coefficient[0][0] == 1 && coefficient[0][1..].iter().all(|c| *c == 0);
        let body = if monic {
            numerator
        } else {
            let mut dpos = Vec::new();
            let mut dneg = Vec::new();
            for e in 0..=d {
                let c = coefficient[0][e];
                if c == 0 {
                    continue;
                }
                cost += const_cost(c) + e as u16 + 1;
                let term = match index_power(arena, e) {
                    Some(power) => scaled(arena, c, power),
                    None => arena.konst(c.abs() as i64),
                };
                if c > 0 {
                    dpos.push(term)
                } else {
                    dneg.push(term)
                }
            }
            let denominator = match signed(arena, &dpos, &dneg) {
                Some(n) => n,
                None => continue,
            };
            arena.bin(Op::Quot, numerator, denominator)
        };
        if best.as_ref().map_or(false, |b| cost >= b.1) || cost >= t.cost {
            continue;
        }
        let program = recur::emit(arena, body, seeds, t.offset, tr);
        if !recur::reproduces(&arena.nodes, program, t.offset, tr, fuel) {
            continue;
        }
        let mode = if d == 0 {
            Mode::Linear
        } else if r == 1 {
            Mode::Hypergeometric
        } else {
            Mode::Holonomic
        };
        best = Some((program, cost, mode));
    }
    best
}

/// a(i) = a(i-k) + m for a fixed lag k: periodic sequences and periodic
/// increments such as residue-class lists.
fn periodic(arena: &mut Arena, t: &Target, fuel: i64) -> Option<(u32, u16, Mode)> {
    let tr = &t.train;
    for k in 2..=recur::MAX_SEEDS {
        let m = tr[k] as i128 - tr[0] as i128;
        if m < 0 || !(k..TRAIN).all(|j| tr[j] as i128 - tr[j - k] as i128 == m) {
            continue;
        }
        let back = recur::previous(arena, k);
        let step = if m == 0 {
            back
        } else {
            let c = arena.konst(m as i64);
            arena.bin(Op::Add, back, c)
        };
        let cost = (if m == 0 { 1 } else { 2 + const_cost(m) }) + recur::seed_cost(tr, k) + 1;
        let program = recur::seeded(arena, step, k, t.offset, tr);
        if cost < t.cost && recur::reproduces(&arena.nodes, program, t.offset, tr, fuel) {
            return Some((program, cost, Mode::Periodic));
        }
        return None;
    }
    None
}

/// A polynomial of degree two or more in Newton form, confirmed by spare
/// vanishing differences.
fn polynomial(arena: &mut Arena, t: &Target, fuel: i64) -> Option<(u32, u16, Mode)> {
    let mut table: Vec<Vec<i128>> = vec![t.train.iter().map(|x| *x as i128).collect()];
    while table.last().unwrap().len() > 1 {
        let last = table.last().unwrap();
        let next: Vec<i128> = last.windows(2).map(|w| w[1] - w[0]).collect();
        table.push(next);
    }
    for d in 2..=(TRAIN - 1 - SPARE).min(7) {
        if !table[d + 1].iter().all(|x| *x == 0) || table[d][0] == 0 {
            continue;
        }
        let coefficients: Vec<i128> = (0..=d).map(|j| table[j][0]).collect();
        if coefficients.iter().any(|c| c.abs() >= VMAX as i128) {
            return None;
        }
        let mut pos = Vec::new();
        let mut neg = Vec::new();
        let mut factorial: i64 = 1;
        let mut cost: u16 = 1;
        for (j, &c) in coefficients.iter().enumerate() {
            if j > 0 {
                factorial *= j as i64;
            }
            if c == 0 {
                continue;
            }
            cost += const_cost(c) + j as u16;
            let term = if j == 0 {
                arena.konst(c.abs() as i64)
            } else {
                // Var (Var-1) ... (Var-j+1) / j!
                let mut falling = arena.leaf(Op::Var);
                for back in 1..j {
                    let mut factor = arena.leaf(Op::Var);
                    for _ in 0..back {
                        factor = arena.un(Op::Pred, factor);
                    }
                    falling = arena.bin(Op::Mul, falling, factor);
                }
                let binomial = if j == 1 {
                    falling
                } else {
                    let f = arena.konst(factorial);
                    arena.bin(Op::Quot, falling, f)
                };
                scaled(arena, c, binomial)
            };
            if c > 0 {
                pos.push(term)
            } else {
                neg.push(term)
            }
        }
        let body = signed(arena, &pos, &neg)?;
        let program = shifted(arena, body, t.offset as i64);
        cost += shift_cost(t.offset as i64);
        if cost < t.cost && recur::reproduces(&arena.nodes, program, t.offset, &t.train, fuel) {
            return Some((program, cost, Mode::Polynomial));
        }
        return None;
    }
    None
}

/// A constant after a few exceptional initial terms.
fn tail(arena: &mut Arena, t: &Target, fuel: i64) -> Option<(u32, u16, Mode)> {
    let tr = &t.train;
    let last = tr[TRAIN - 1];
    let mut s = TRAIN - 1;
    while s > 0 && tr[s - 1] == last {
        s -= 1;
    }
    if s == 0 || s > recur::MAX_SEEDS {
        return None;
    }
    let mut chain = arena.konst(last);
    for j in (0..s).rev() {
        let var = arena.leaf(Op::Var);
        let test = recur::at_most(arena, var, t.offset as i64 + j as i64);
        let seed = arena.konst(tr[j]);
        chain = arena.tri(Op::Ifz, test, seed, chain);
    }
    let cost = const_cost(last as i128) + recur::seed_cost(tr, s) + 1;
    if cost < t.cost && recur::reproduces(&arena.nodes, chain, t.offset, tr, fuel) {
        Some((chain, cost, Mode::Tail))
    } else {
        None
    }
}

/// Run every sketch on every target. Returns the improved targets by mode.
///
/// Worker threads build candidates in private arenas and hand back program
/// text; the main arena only receives programs that are offered.
pub fn search(arena: &mut Arena, corpus: &mut Corpus, fuel: i64, threads: usize) -> Vec<(Mode, usize)> {
    let shapes = shapes();
    let n = corpus.targets.len();
    let threads = threads.max(1);
    let chunk = (n + threads - 1) / threads;
    let mut found: Vec<(u32, u16, Mode, String)> = {
        let targets = &corpus.targets;
        let shapes = &shapes;
        std::thread::scope(|scope| {
            let handles: Vec<_> = (0..threads)
                .map(|w| {
                    scope.spawn(move || {
                        let mut local = Arena::new();
                        let mut out: Vec<(u32, u16, Mode, String)> = Vec::new();
                        for ti in (w * chunk).min(n)..((w + 1) * chunk).min(n) {
                            let t = &targets[ti];
                            if t.train.iter().all(|x| *x == t.train[0]) {
                                continue;
                            }
                            local.nodes.clear();
                            let results = [tail(&mut local, t, fuel), periodic(&mut local, t, fuel), polynomial(&mut local, t, fuel), precursive(&mut local, t, shapes, fuel)];
                            if let Some((program, cost, mode)) = results.into_iter().flatten().min_by_key(|r| r.1) {
                                out.push((ti as u32, cost, mode, local.text(program)));
                            }
                        }
                        out
                    })
                })
                .collect();
            handles.into_iter().flat_map(|h| h.join().unwrap()).collect()
        })
    };
    found.sort_unstable_by(|x, y| (x.0, x.1).cmp(&(y.0, y.1)));
    let mut improved: Vec<(Mode, usize)> = Vec::new();
    for (ti, cost, mode, text) in found {
        if cost >= corpus.targets[ti as usize].cost {
            continue;
        }
        let program = match parse(arena, &text) {
            Some(p) => p,
            None => continue,
        };
        if corpus.offer(ti, cost, program, mode) {
            match improved.iter_mut().find(|(m, _)| *m == mode) {
                Some(entry) => entry.1 += 1,
                None => improved.push((mode, 1)),
            }
        }
    }
    improved
}

#[cfg(test)]
mod tests {
    use super::*;

    fn target(offset: u32, terms: &[V]) -> Target {
        let mut train = [0 as V; TRAIN];
        train.copy_from_slice(&terms[..TRAIN]);
        Target { offset, window: offset as u8, shift: 0, train, seqs: vec![], cost: u16::MAX, node: NIL, mode: Mode::None, from: [NIL; 3] }
    }

    fn check(offset: u32, terms: &[V], expected: Mode) {
        let mut arena = Arena::new();
        let t = target(offset, terms);
        let found = precursive(&mut arena, &t, &shapes(), 1_000_000).unwrap_or_else(|| panic!("no recurrence for {:?}", terms));
        assert_eq!(found.2, expected);
        for (j, &v) in terms.iter().enumerate() {
            assert_eq!(Interp::run(&arena.nodes, found.0, offset as i128 + j as i128, 1_000_000), Some(v as i128), "term {} of {}", j, arena.text(found.0));
        }
    }

    #[test]
    fn linear_recurrences() {
        check(0, &[0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946], Mode::Linear);
        check(0, &[0, 2, 20, 198, 1960, 19402, 192060, 1901198, 18819920, 186298002, 1844160100, 18255302998, 180708869880, 1788833395802, 17707625088140, 175287417485598, 1735166549767840, 17176378080192802, 170028614252160180, 1683109764441408998], Mode::Linear);
    }

    #[test]
    fn hypergeometric_terms() {
        check(0, &[1, 1, 2, 5, 14, 42, 132, 429, 1430, 4862, 16796, 58786, 208012, 742900, 2674440, 9694845, 35357670, 129644790, 477638700, 1767263190, 6564120420, 24466267020], Mode::Hypergeometric);
        check(0, &[1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800, 39916800, 479001600, 6227020800, 87178291200, 1307674368000, 20922789888000, 355687428096000, 6402373705728000, 121645100408832000], Mode::Hypergeometric);
    }

    #[test]
    fn unrelated_terms_have_no_recurrence() {
        let mut arena = Arena::new();
        let t = target(1, &[3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8, 9, 7, 9, 3, 2, 3, 8, 4, 6, 2]);
        assert!(precursive(&mut arena, &t, &shapes(), 1_000_000).is_none());
    }
}
