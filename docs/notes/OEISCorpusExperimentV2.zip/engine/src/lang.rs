//! Recursor syntax, a compact program arena and an exact interpreter.
//!
//! The interpreter mirrors the paclet's reference semantics on natural
//! numbers. It is only a proposer: every program the engine reports is
//! validated again by `EvaluateRecursor` in the Wolfram Language paclet.

use std::hash::{BuildHasherDefault, Hasher};

/// Machine value used for observational-equivalence vectors.
pub type V = i64;
/// "No value": overflow of the machine range or an exhausted budget.
pub const BOT: V = i64::MIN;
/// Largest magnitude kept in a vector. Leaves headroom for one addition.
pub const VMAX: V = 1 << 62;
pub const NIL: u32 = u32::MAX;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
#[repr(u8)]
pub enum Op {
    Var,
    Acc,
    Idx,
    Const,
    Succ,
    Pred,
    Half,
    Add,
    Mul,
    Monus,
    Rem,
    Quot,
    Ifz,
    Iter,
    Rec,
    While,
    CoRec,
    CGet,
    Let,
    /// Teacher-forced earlier term a(i-k), with k in the node constant. Search-only.
    Prev,
    /// Teacher-forced a(floor(i/2)). Search-only.
    PH,
}

pub const F_ACC: u8 = 1;
pub const F_IDX: u8 = 2;
pub const F_GET: u8 = 4;
pub const F_PREV: u8 = 8;

impl Op {
    pub fn name(self) -> &'static str {
        match self {
            Op::Var => "Var",
            Op::Acc => "Acc",
            Op::Idx => "Idx",
            Op::Const => "Const",
            Op::Succ => "Succ",
            Op::Pred => "Pred",
            Op::Half => "Half",
            Op::Add => "Add",
            Op::Mul => "Mul",
            Op::Monus => "Monus",
            Op::Rem => "Rem",
            Op::Quot => "Quot",
            Op::Ifz => "Ifz",
            Op::Iter => "Iter",
            Op::Rec => "Rec",
            Op::While => "WhileLoop",
            Op::CoRec => "CoRec",
            Op::CGet => "CGet",
            Op::Let => "Let",
            Op::Prev => "Prev",
            Op::PH => "PH",
        }
    }
    pub fn arity(self) -> usize {
        match self {
            Op::Var | Op::Acc | Op::Idx | Op::Const | Op::Prev | Op::PH => 0,
            Op::Succ | Op::Pred | Op::Half | Op::CGet => 1,
            Op::Add | Op::Mul | Op::Monus | Op::Rem | Op::Quot | Op::CoRec | Op::Let => 2,
            Op::Ifz | Op::Iter | Op::Rec | Op::While => 3,
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Node {
    pub op: Op,
    /// Free binder references: F_ACC | F_IDX | F_GET | F_PREV.
    pub flags: u8,
    pub size: u16,
    pub a: u32,
    pub b: u32,
    pub c: u32,
    pub k: i64,
}

#[derive(Default)]
pub struct Arena {
    pub nodes: Vec<Node>,
}

impl Arena {
    pub fn new() -> Self {
        Arena { nodes: Vec::new() }
    }
    pub fn get(&self, id: u32) -> &Node {
        &self.nodes[id as usize]
    }
    pub fn size(&self, id: u32) -> u16 {
        self.nodes[id as usize].size
    }
    pub fn flags(&self, id: u32) -> u8 {
        self.nodes[id as usize].flags
    }
    pub fn mk(&mut self, op: Op, k: i64, a: u32, b: u32, c: u32) -> u32 {
        let f = |x: u32, nodes: &Vec<Node>| if x == NIL { 0 } else { nodes[x as usize].flags };
        let s = |x: u32, nodes: &Vec<Node>| if x == NIL { 0 } else { nodes[x as usize].size };
        let (fa, fb, fc) = (f(a, &self.nodes), f(b, &self.nodes), f(c, &self.nodes));
        let flags = match op {
            Op::Acc => F_ACC,
            Op::Idx => F_IDX,
            Op::Prev | Op::PH => F_PREV,
            Op::CGet => F_GET | fa,
            Op::Iter => fa | fb | (fc & !F_ACC),
            Op::Rec => fa | fb | (fc & !(F_ACC | F_IDX)),
            Op::While => fa | ((fb | fc) & !F_ACC),
            Op::CoRec => fa | (fb & !(F_IDX | F_GET)),
            _ => fa | fb | fc,
        };
        let size = 1 + s(a, &self.nodes) + s(b, &self.nodes) + s(c, &self.nodes);
        self.nodes.push(Node { op, flags, size, a, b, c, k });
        (self.nodes.len() - 1) as u32
    }
    pub fn leaf(&mut self, op: Op) -> u32 {
        self.mk(op, 0, NIL, NIL, NIL)
    }
    pub fn konst(&mut self, k: i64) -> u32 {
        self.mk(Op::Const, k, NIL, NIL, NIL)
    }
    pub fn un(&mut self, op: Op, a: u32) -> u32 {
        self.mk(op, 0, a, NIL, NIL)
    }
    pub fn bin(&mut self, op: Op, a: u32, b: u32) -> u32 {
        self.mk(op, 0, a, b, NIL)
    }
    pub fn tri(&mut self, op: Op, a: u32, b: u32, c: u32) -> u32 {
        self.mk(op, 0, a, b, c)
    }
    pub fn write(&self, id: u32, out: &mut String) {
        let n = self.nodes[id as usize];
        out.push_str(n.op.name());
        match n.op.arity() {
            0 => {
                if n.op == Op::Const || n.op == Op::Prev {
                    out.push('[');
                    out.push_str(&n.k.to_string());
                    out.push(']');
                }
            }
            1 => {
                out.push('[');
                self.write(n.a, out);
                out.push(']');
            }
            2 => {
                out.push('[');
                self.write(n.a, out);
                out.push_str(", ");
                self.write(n.b, out);
                out.push(']');
            }
            _ => {
                out.push('[');
                self.write(n.a, out);
                out.push_str(", ");
                self.write(n.b, out);
                out.push_str(", ");
                self.write(n.c, out);
                out.push(']');
            }
        }
    }
    pub fn text(&self, id: u32) -> String {
        let mut s = String::new();
        self.write(id, &mut s);
        s
    }
}

/// Exact values beyond this magnitude are reported as "no value".
pub const CAP: i128 = 1i128 << 110;

#[derive(Clone, Copy, Debug)]
pub struct Env {
    pub n: i128,
    pub acc: i128,
    pub idx: i128,
}

impl Env {
    pub fn input(n: i128) -> Env {
        Env { n, acc: 0, idx: 0 }
    }
}

/// Largest lag a teacher-forced body may read.
pub const LAGS: usize = 12;

pub struct Interp<'a> {
    pub nodes: &'a [Node],
    pub fuel: i64,
    /// Teacher-forced a(i-1), a(i-2), ... for recurrence bodies.
    pub prev: [i128; LAGS],
    /// Teacher-forced a(floor(i/2)).
    pub half: i128,
}

impl<'a> Interp<'a> {
    pub fn new(nodes: &'a [Node], fuel: i64) -> Self {
        Interp { nodes, fuel, prev: [0; LAGS], half: 0 }
    }

    /// Evaluate a node. `None` means the budget or the exact range ran out;
    /// it never asserts nontermination.
    pub fn ev(&mut self, id: u32, e: &Env, h: &[i128]) -> Option<i128> {
        self.fuel -= 1;
        if self.fuel < 0 {
            return None;
        }
        let nd = self.nodes[id as usize];
        let r = match nd.op {
            Op::Var => e.n,
            Op::Acc => e.acc,
            Op::Idx => e.idx,
            Op::Const => nd.k as i128,
            Op::Prev => self.prev[(nd.k - 1) as usize],
            Op::PH => self.half,
            Op::Succ => self.ev(nd.a, e, h)? + 1,
            Op::Pred => {
                let x = self.ev(nd.a, e, h)?;
                if x > 0 {
                    x - 1
                } else {
                    0
                }
            }
            Op::Half => self.ev(nd.a, e, h)? / 2,
            Op::Add => self.ev(nd.a, e, h)? + self.ev(nd.b, e, h)?,
            Op::Mul => {
                let x = self.ev(nd.a, e, h)?;
                let y = self.ev(nd.b, e, h)?;
                x.checked_mul(y)?
            }
            Op::Monus => {
                let x = self.ev(nd.a, e, h)?;
                let y = self.ev(nd.b, e, h)?;
                if x > y {
                    x - y
                } else {
                    0
                }
            }
            Op::Rem => {
                let x = self.ev(nd.a, e, h)?;
                let y = self.ev(nd.b, e, h)?;
                if y == 0 {
                    x
                } else {
                    x % y
                }
            }
            Op::Quot => {
                let x = self.ev(nd.a, e, h)?;
                let y = self.ev(nd.b, e, h)?;
                if y == 0 {
                    0
                } else {
                    x / y
                }
            }
            Op::Ifz => {
                if self.ev(nd.a, e, h)? == 0 {
                    self.ev(nd.b, e, h)?
                } else {
                    self.ev(nd.c, e, h)?
                }
            }
            Op::Iter => {
                let count = self.ev(nd.a, e, h)?;
                let mut acc = self.ev(nd.b, e, h)?;
                let mut i: i128 = 0;
                while i < count {
                    acc = self.ev(nd.c, &Env { acc, ..*e }, h)?;
                    i += 1;
                }
                acc
            }
            Op::Rec => {
                let count = self.ev(nd.a, e, h)?;
                let mut acc = self.ev(nd.b, e, h)?;
                let mut i: i128 = 0;
                while i < count {
                    acc = self.ev(nd.c, &Env { acc, idx: i, ..*e }, h)?;
                    i += 1;
                }
                acc
            }
            Op::While => {
                let mut acc = self.ev(nd.a, e, h)?;
                loop {
                    if self.ev(nd.b, &Env { acc, ..*e }, h)? == 0 {
                        break;
                    }
                    acc = self.ev(nd.c, &Env { acc, ..*e }, h)?;
                }
                acc
            }
            Op::CoRec => {
                let last = self.ev(nd.a, e, h)?;
                if last > (self.fuel as i128) {
                    self.fuel = -1;
                    return None;
                }
                let mut hist: Vec<i128> = Vec::with_capacity(last as usize + 1);
                while (hist.len() as i128) <= last {
                    let v = self.ev(nd.b, &Env { idx: hist.len() as i128, ..*e }, &hist)?;
                    hist.push(v);
                }
                hist[last as usize]
            }
            Op::CGet => {
                let j = self.ev(nd.a, e, h)?;
                if j < h.len() as i128 {
                    h[j as usize]
                } else {
                    0
                }
            }
            Op::Let => {
                let v = self.ev(nd.a, e, h)?;
                self.ev(nd.b, &Env { n: v, ..*e }, h)?
            }
        };
        if r > CAP {
            None
        } else {
            Some(r)
        }
    }

    pub fn run(nodes: &'a [Node], id: u32, n: i128, fuel: i64) -> Option<i128> {
        let mut it = Interp::new(nodes, fuel);
        it.ev(id, &Env::input(n), &[])
    }
}

#[inline(always)]
pub fn clamp(x: i128) -> V {
    if x >= 0 && x < VMAX as i128 {
        x as V
    } else {
        BOT
    }
}

#[inline(always)]
pub fn v1(op: Op, x: V) -> V {
    if x == BOT {
        return BOT;
    }
    match op {
        Op::Succ => {
            if x + 1 < VMAX {
                x + 1
            } else {
                BOT
            }
        }
        Op::Pred => {
            if x > 0 {
                x - 1
            } else {
                0
            }
        }
        Op::Half => x / 2,
        _ => BOT,
    }
}

#[inline(always)]
pub fn v2(op: Op, x: V, y: V) -> V {
    if x == BOT || y == BOT {
        return BOT;
    }
    match op {
        Op::Add => {
            let s = x + y;
            if s < VMAX {
                s
            } else {
                BOT
            }
        }
        Op::Mul => match x.checked_mul(y) {
            Some(p) if p < VMAX => p,
            _ => BOT,
        },
        Op::Monus => {
            if x > y {
                x - y
            } else {
                0
            }
        }
        Op::Rem => {
            if y == 0 {
                x
            } else {
                x % y
            }
        }
        Op::Quot => {
            if y == 0 {
                0
            } else {
                x / y
            }
        }
        _ => BOT,
    }
}

/// A fast, well-mixed hasher for fixed-size integer keys.
#[derive(Default, Clone, Copy)]
pub struct Fx(u64);

impl Hasher for Fx {
    #[inline]
    fn write(&mut self, bytes: &[u8]) {
        let mut chunks = bytes.chunks_exact(8);
        for c in &mut chunks {
            self.write_u64(u64::from_le_bytes([c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]]));
        }
        let rest = chunks.remainder();
        if !rest.is_empty() {
            let mut b = [0u8; 8];
            b[..rest.len()].copy_from_slice(rest);
            self.write_u64(u64::from_le_bytes(b));
        }
    }
    #[inline]
    fn write_u64(&mut self, v: u64) {
        self.0 = (self.0.rotate_left(5) ^ v).wrapping_mul(0x517c_c1b7_2722_0a95);
    }
    #[inline]
    fn write_i64(&mut self, v: i64) {
        self.write_u64(v as u64)
    }
    #[inline]
    fn write_u8(&mut self, v: u8) {
        self.write_u64(v as u64)
    }
    #[inline]
    fn write_u32(&mut self, v: u32) {
        self.write_u64(v as u64)
    }
    #[inline]
    fn write_usize(&mut self, v: usize) {
        self.write_u64(v as u64)
    }
    #[inline]
    fn finish(&self) -> u64 {
        let x = self.0;
        let x = (x ^ (x >> 32)).wrapping_mul(0x9e37_79b9_7f4a_7c15);
        x ^ (x >> 29)
    }
}

pub type FxBuild = BuildHasherDefault<Fx>;
pub type FxMap<K, T> = std::collections::HashMap<K, T, FxBuild>;

pub fn gcd(mut a: i128, mut b: i128) -> i128 {
    a = a.abs();
    b = b.abs();
    while b != 0 {
        let t = a % b;
        a = b;
        b = t;
    }
    a
}

/// Parse Recursor source text into the arena. `None` for malformed text.
pub fn parse(arena: &mut Arena, text: &str) -> Option<u32> {
    let b = text.as_bytes();
    let mut pos = 0usize;
    let node = parse_expr(arena, b, &mut pos)?;
    skip_ws(b, &mut pos);
    if pos == b.len() {
        Some(node)
    } else {
        None
    }
}

fn skip_ws(b: &[u8], pos: &mut usize) {
    while *pos < b.len() && (b[*pos] as char).is_whitespace() {
        *pos += 1;
    }
}

fn expect(b: &[u8], pos: &mut usize, ch: u8) -> Option<()> {
    skip_ws(b, pos);
    if *pos < b.len() && b[*pos] == ch {
        *pos += 1;
        Some(())
    } else {
        None
    }
}

fn parse_expr(arena: &mut Arena, b: &[u8], pos: &mut usize) -> Option<u32> {
    skip_ws(b, pos);
    let start = *pos;
    while *pos < b.len() && (b[*pos] as char).is_ascii_alphanumeric() {
        *pos += 1;
    }
    let name = std::str::from_utf8(&b[start..*pos]).ok()?;
    let op = match name {
        "Var" => Op::Var,
        "Acc" => Op::Acc,
        "Idx" => Op::Idx,
        "Const" => Op::Const,
        "Succ" => Op::Succ,
        "Pred" => Op::Pred,
        "Half" => Op::Half,
        "Add" => Op::Add,
        "Mul" => Op::Mul,
        "Monus" => Op::Monus,
        "Rem" => Op::Rem,
        "Quot" => Op::Quot,
        "Ifz" => Op::Ifz,
        "Iter" => Op::Iter,
        "Rec" => Op::Rec,
        "WhileLoop" => Op::While,
        "CoRec" => Op::CoRec,
        "CGet" => Op::CGet,
        "Let" => Op::Let,
        _ => return None,
    };
    if op == Op::Const {
        expect(b, pos, b'[')?;
        skip_ws(b, pos);
        let s = *pos;
        while *pos < b.len() && b[*pos].is_ascii_digit() {
            *pos += 1;
        }
        let k: i64 = std::str::from_utf8(&b[s..*pos]).ok()?.parse().ok()?;
        expect(b, pos, b']')?;
        return Some(arena.konst(k));
    }
    let arity = op.arity();
    if arity == 0 {
        return Some(arena.leaf(op));
    }
    expect(b, pos, b'[')?;
    let mut args = [NIL; 3];
    for (i, slot) in args.iter_mut().enumerate().take(arity) {
        if i > 0 {
            expect(b, pos, b',')?;
        }
        *slot = parse_expr(arena, b, pos)?;
    }
    expect(b, pos, b']')?;
    Some(arena.mk(op, 0, args[0], args[1], args[2]))
}

/// Exact rational numbers for the algebraic solvers. Every operation is
/// checked; overflow abandons the solve instead of producing a wrong answer.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Frac {
    pub n: i128,
    pub d: i128,
}

impl Frac {
    pub fn int(n: i128) -> Frac {
        Frac { n, d: 1 }
    }
    pub fn new(n: i128, d: i128) -> Option<Frac> {
        if d == 0 {
            return None;
        }
        let g = gcd(n, d).max(1);
        let (mut n, mut d) = (n / g, d / g);
        if d < 0 {
            n = n.checked_neg()?;
            d = d.checked_neg()?;
        }
        Some(Frac { n, d })
    }
    pub fn is_zero(&self) -> bool {
        self.n == 0
    }
    pub fn add(self, o: Frac) -> Option<Frac> {
        Frac::new(self.n.checked_mul(o.d)?.checked_add(o.n.checked_mul(self.d)?)?, self.d.checked_mul(o.d)?)
    }
    pub fn sub(self, o: Frac) -> Option<Frac> {
        Frac::new(self.n.checked_mul(o.d)?.checked_sub(o.n.checked_mul(self.d)?)?, self.d.checked_mul(o.d)?)
    }
    pub fn mul(self, o: Frac) -> Option<Frac> {
        let g1 = gcd(self.n, o.d).max(1);
        let g2 = gcd(o.n, self.d).max(1);
        Frac::new((self.n / g1).checked_mul(o.n / g2)?, (self.d / g2).checked_mul(o.d / g1)?)
    }
    pub fn div(self, o: Frac) -> Option<Frac> {
        if o.n == 0 {
            return None;
        }
        self.mul(Frac { n: o.d, d: o.n })
    }
}

/// Description cost of a constant in node equivalents: 0..3 cost one node,
/// and every further two bits cost one more. Enumeration only creates the
/// constants 0..3; larger ones come from data (seeds) or exact solving.
pub fn const_cost(c: i128) -> u16 {
    let c = c.unsigned_abs();
    let bits = 128 - c.leading_zeros();
    if bits <= 2 {
        1
    } else {
        1 + ((bits - 2 + 1) / 2) as u16
    }
}
