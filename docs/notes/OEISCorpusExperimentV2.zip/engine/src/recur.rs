//! Mode II: recurrences found by teacher forcing.
//!
//! A step body F(i, a(i-1), a(i-2), a(i-3), a(floor(i/2))) is checked
//! directly against the training terms: body(i, t[i-1], ...) = t[i] for every
//! training position after the seeds. No candidate has to be run from the
//! start. All bodies of a body universe are evaluated in one pass over a
//! shared DAG, grouped by operator.
//!
//! The seeds are read from the training data. Extra seeds absorb exceptional
//! initial terms. The cost of a recurrence is its body nodes, plus the cost
//! of each seed constant, plus one for the recurrence itself.

use crate::corpus::*;
use crate::lang::*;
use crate::universe::*;

pub const NR: usize = 16;
pub type RV = [V; NR];

pub const R_I: RV = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 3, 5, 7, 9];
pub const R_P1: RV = [1, 0, 2, 5, 13, 8, 34, 3, 100, 21, 7, 233, 1, 55, 610, 12];
pub const R_P2: RV = [0, 1, 1, 3, 8, 5, 21, 2, 60, 13, 4, 144, 4, 34, 377, 9];
pub const R_P3: RV = [2, 0, 1, 2, 5, 3, 13, 7, 30, 8, 6, 89, 0, 21, 233, 5];
pub const R_PH: RV = [3, 1, 0, 4, 2, 9, 1, 6, 17, 2, 11, 40, 7, 0, 5, 28];

/// Offsets above this are handled by shifting the input, so a program never
/// builds a history from index zero up to a large offset.
pub const DIRECT_OFFSET: u32 = 4;
/// Most seeds a recurrence may take from the data.
pub const MAX_SEEDS: usize = TRAIN - MIN_CHECKS;
/// Above this many surviving bodies, keep filtering with full DAG passes.
const DENSE: usize = 1024;

/// Bodies in an evaluation order grouped by operator.
pub struct Dag {
    pub op: Vec<Op>,
    pub k: Vec<V>,
    pub a: Vec<u32>,
    pub b: Vec<u32>,
    pub c: Vec<u32>,
    pub size: Vec<u16>,
    /// Largest lag among a(i-k) leaves; 0 when none is used.
    pub lag: Vec<u8>,
    pub half: Vec<bool>,
    /// Whether the body is a recurrence candidate of its family.
    pub active: Vec<bool>,
    pub node: Vec<u32>,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Family {
    /// a(i) from i and the previous three terms.
    Linear,
    /// a(i) from i, a(i-1) and a(floor(i/2)).
    Binary,
}

pub fn build_bodies(arena: &mut Arena, family: Family, max_const: i64, max_size: usize) -> Universe<NR> {
    let mut leaves: Vec<(Op, i64, RV)> = match family {
        Family::Linear => vec![(Op::Idx, 0, R_I), (Op::Prev, 1, R_P1), (Op::Prev, 2, R_P2), (Op::Prev, 3, R_P3)],
        Family::Binary => vec![(Op::Idx, 0, R_I), (Op::PH, 0, R_PH), (Op::Prev, 1, R_P1)],
    };
    for k in 0..=max_const {
        leaves.push((Op::Const, k, [k as V; NR]));
    }
    build_open(arena, &leaves, max_size)
}

/// (largest lag, uses a(floor(i/2))) of a body.
pub fn uses(arena: &Arena, node: u32) -> (u8, bool) {
    let n = arena.get(node);
    let (mut lag, mut half) = match n.op {
        Op::Prev => (n.k as u8, false),
        Op::PH => (0, true),
        _ => (0, false),
    };
    for ch in [n.a, n.b, n.c] {
        if ch != NIL {
            let (l, h) = uses(arena, ch);
            lag = lag.max(l);
            half |= h;
        }
    }
    (lag, half)
}

pub fn build_dag(arena: &Arena, u: &Universe<NR>, family: Family) -> Dag {
    let n = u.len();
    // Children are in strictly smaller size levels, so any order inside a
    // level is a valid evaluation order. Group by operator.
    let mut order: Vec<u32> = (0..n as u32).collect();
    order.sort_by_key(|&ci| {
        let nd = arena.get(u.node[ci as usize]);
        (nd.size, nd.op as u8, ci)
    });
    let mut position = vec![0u32; n];
    for (pos, &ci) in order.iter().enumerate() {
        position[ci as usize] = pos as u32;
    }
    let mut class_of: FxMap<u32, u32> = FxMap::default();
    for ci in 0..n {
        class_of.insert(u.node[ci], position[ci]);
    }
    let mut d = Dag {
        op: Vec::with_capacity(n),
        k: Vec::with_capacity(n),
        a: Vec::with_capacity(n),
        b: Vec::with_capacity(n),
        c: Vec::with_capacity(n),
        size: Vec::with_capacity(n),
        lag: Vec::with_capacity(n),
        half: Vec::with_capacity(n),
        active: Vec::with_capacity(n),
        node: Vec::with_capacity(n),
    };
    let child = |x: u32, class_of: &FxMap<u32, u32>| if x == NIL { 0 } else { class_of[&x] };
    for &ci in &order {
        let node = u.node[ci as usize];
        let nd = arena.get(node);
        let (lag, half) = uses(arena, node);
        d.op.push(nd.op);
        d.k.push(nd.k as V);
        d.a.push(child(nd.a, &class_of));
        d.b.push(child(nd.b, &class_of));
        d.c.push(child(nd.c, &class_of));
        d.size.push(nd.size);
        // The binary family is only interesting when a(floor(i/2)) is used;
        // the linear family covers everything else.
        d.active.push(if family == Family::Binary { half } else { lag >= 1 });
        d.lag.push(lag);
        d.half.push(half);
        d.node.push(node);
    }
    d
}

/// Teacher-forced environment of one training position.
#[derive(Clone, Copy)]
pub struct Position {
    pub index: V,
    pub prev: [V; LAGS],
    pub half: V,
}

/// Environment of training position j: index and earlier terms.
pub fn position(offset: u32, train: &[V; TRAIN], j: usize) -> Position {
    let mut prev = [BOT; LAGS];
    for (lag, slot) in prev.iter_mut().enumerate() {
        if j > lag {
            *slot = train[j - lag - 1];
        }
    }
    let i = offset as usize + j;
    let h = i / 2;
    let half = if h >= offset as usize && h - (offset as usize) < j { train[h - offset as usize] } else { BOT };
    Position { index: i as V, prev, half }
}

impl Dag {
    /// Evaluate every body on one environment.
    pub fn pass(&self, p: &Position, vals: &mut [V]) {
        let n = self.op.len();
        let mut s = 0usize;
        while s < n {
            let op = self.op[s];
            let mut e = s + 1;
            while e < n && self.op[e] == op {
                e += 1;
            }
            match op {
                Op::Idx => vals[s..e].fill(p.index),
                Op::PH => vals[s..e].fill(p.half),
                Op::Prev => {
                    for t in s..e {
                        vals[t] = p.prev[(self.k[t] - 1) as usize];
                    }
                }
                Op::Const => {
                    for t in s..e {
                        vals[t] = self.k[t];
                    }
                }
                Op::Succ | Op::Pred | Op::Half => {
                    for t in s..e {
                        vals[t] = v1(op, vals[self.a[t] as usize]);
                    }
                }
                Op::Add | Op::Mul | Op::Monus | Op::Rem | Op::Quot => {
                    for t in s..e {
                        vals[t] = v2(op, vals[self.a[t] as usize], vals[self.b[t] as usize]);
                    }
                }
                Op::Ifz => {
                    for t in s..e {
                        let c = vals[self.a[t] as usize];
                        vals[t] = if c == BOT {
                            BOT
                        } else if c == 0 {
                            vals[self.b[t] as usize]
                        } else {
                            vals[self.c[t] as usize]
                        };
                    }
                }
                _ => vals[s..e].fill(BOT),
            }
            s = e;
        }
    }

    /// Fewest seeds a body needs for a target with the given offset.
    #[inline(always)]
    pub fn seeds(&self, t: usize, offset: u32) -> usize {
        let lag = self.lag[t] as usize;
        if self.half[t] {
            if offset > DIRECT_OFFSET {
                // a(floor(i/2)) lies before the first recorded term.
                return TRAIN;
            }
            lag.max(1).max(offset as usize)
        } else {
            lag
        }
    }
}

/// Evaluate one body at one training position, exactly.
pub fn body_at(nodes: &[Node], body: u32, p: &Position) -> V {
    let mut it = Interp::new(nodes, 4096);
    for lag in 0..LAGS {
        // An unavailable earlier term makes the body unevaluable there.
        it.prev[lag] = if p.prev[lag] == BOT { CAP + 1 } else { p.prev[lag] as i128 };
    }
    it.half = if p.half == BOT { CAP + 1 } else { p.half as i128 };
    match it.ev(body, &Env { n: p.index as i128, acc: 0, idx: p.index as i128 }, &[]) {
        Some(x) => clamp(x),
        None => BOT,
    }
}

pub fn seed_cost(train: &[V; TRAIN], seeds: usize) -> u16 {
    (0..seeds).map(|j| const_cost(train[j] as i128)).sum()
}

/// Cheapest body for one target as (dag position, seeds, cost).
///
/// A body must reproduce a suffix of the training window: every position
/// from its last seed onward, and at least MIN_CHECKS positions.
pub fn best_body(
    d: &Dag,
    nodes: &[Node],
    offset: u32,
    train: &[V; TRAIN],
    limit: u16,
    vals: &mut [V],
    scratch: &mut [V],
    survivors: &mut Vec<(u32, u8)>,
) -> Option<(u32, u8, u16)> {
    let last = TRAIN - 1;
    d.pass(&position(offset, train, last), vals);
    d.pass(&position(offset, train, last - 1), scratch);
    survivors.clear();
    let (want, want2) = (train[last], train[last - 1]);
    for t in 0..d.op.len() {
        if vals[t] == want && scratch[t] == want2 && d.active[t] {
            let base = d.seeds(t, offset);
            if base <= MAX_SEEDS && d.size[t] + (base as u16) + 1 < limit {
                // Seed count 0 marks "not fixed yet".
                survivors.push((t as u32, 0));
            }
        }
    }
    let mut j = last - 1;
    // Dense phase: one DAG pass filters every survivor at once.
    while j > 1 && survivors.iter().filter(|s| s.1 == 0).count() > DENSE {
        j -= 1;
        d.pass(&position(offset, train, j), vals);
        survivors.retain_mut(|s| {
            if s.1 != 0 {
                return true;
            }
            let base = d.seeds(s.0 as usize, offset);
            if j < base {
                s.1 = base as u8;
                return true;
            }
            if vals[s.0 as usize] == train[j] {
                return true;
            }
            if j + 1 > MAX_SEEDS {
                return false;
            }
            s.1 = (j + 1) as u8;
            true
        });
    }
    // Sparse phase: evaluate the few remaining bodies one by one.
    let mut best: Option<(u32, u8, u16)> = None;
    for &(t, fixed) in survivors.iter() {
        let base = d.seeds(t as usize, offset).max(1);
        let mut seeds = if fixed != 0 { fixed as usize } else { base };
        if fixed == 0 {
            let mut k = j;
            while k > base {
                k -= 1;
                if body_at(nodes, d.node[t as usize], &position(offset, train, k)) != train[k] {
                    seeds = k + 1;
                    break;
                }
            }
        }
        if seeds > MAX_SEEDS {
            continue;
        }
        let cost = d.size[t as usize] + seed_cost(train, seeds) + 1;
        if cost < limit && best.map_or(true, |(_, _, c)| cost < c) {
            best = Some((t, seeds as u8, cost));
        }
    }
    best
}

/// Copy a body, replacing its leaves: the index, a(i-k) and a(floor(i/2)).
fn rebuild(arena: &mut Arena, node: u32, index: u32, prev: &[u32; LAGS], half: u32) -> u32 {
    let nd = *arena.get(node);
    match nd.op {
        Op::Idx => index,
        Op::Prev => prev[(nd.k - 1) as usize],
        Op::PH => half,
        Op::Const => arena.konst(nd.k),
        _ => {
            let a = if nd.a == NIL { NIL } else { rebuild(arena, nd.a, index, prev, half) };
            let b = if nd.b == NIL { NIL } else { rebuild(arena, nd.b, index, prev, half) };
            let c = if nd.c == NIL { NIL } else { rebuild(arena, nd.c, index, prev, half) };
            arena.mk(nd.op, 0, a, b, c)
        }
    }
}

/// CGet[Idx - lag].
pub fn previous(arena: &mut Arena, lag: usize) -> u32 {
    let i = arena.leaf(Op::Idx);
    let at = match lag {
        1 => arena.un(Op::Pred, i),
        2 => {
            let p = arena.un(Op::Pred, i);
            arena.un(Op::Pred, p)
        }
        _ => {
            let k = arena.konst(lag as i64);
            arena.bin(Op::Monus, i, k)
        }
    };
    arena.un(Op::CGet, at)
}

/// A test that is zero exactly when `x` is at most `m`.
pub fn at_most(arena: &mut Arena, x: u32, m: i64) -> u32 {
    match m {
        0 => x,
        1 => arena.un(Op::Pred, x),
        _ => {
            let k = arena.konst(m);
            arena.bin(Op::Monus, x, k)
        }
    }
}

/// CoRec[Var, seeds..., step]: the history index is the sequence index, or
/// the index minus the offset when the offset is large. Indices up to the
/// position of seed j give that seed; later indices give `step`.
pub fn seeded(arena: &mut Arena, step: u32, seeds: usize, offset: u32, train: &[V; TRAIN]) -> u32 {
    let base = if offset > DIRECT_OFFSET { 0 } else { offset as i64 };
    let mut chain = step;
    for j in (0..seeds).rev() {
        let i = arena.leaf(Op::Idx);
        let test = at_most(arena, i, base + j as i64);
        let seed = arena.konst(train[j]);
        chain = arena.tri(Op::Ifz, test, seed, chain);
    }
    let var = arena.leaf(Op::Var);
    let program = arena.bin(Op::CoRec, var, chain);
    if offset > DIRECT_OFFSET {
        shifted(arena, program, offset as i64)
    } else {
        program
    }
}

/// Emit a closed Recursor program for a recurrence body with `seeds` seeds
/// from `train`.
pub fn emit(arena: &mut Arena, body: u32, seeds: usize, offset: u32, train: &[V; TRAIN]) -> u32 {
    let o = offset as i64;
    let (lag, half) = uses(arena, body);
    if lag <= 1 && !half && seeds == 1 {
        // Rec[n - o, a(o), step]: Acc is a(i-1), the term index is Idx + o + 1.
        let var = arena.leaf(Op::Var);
        let count = if o == 0 {
            var
        } else {
            let k = arena.konst(o);
            arena.bin(Op::Monus, var, k)
        };
        let idx = arena.leaf(Op::Idx);
        let index = if o == 0 {
            arena.un(Op::Succ, idx)
        } else {
            let k = arena.konst(o + 1);
            arena.bin(Op::Add, idx, k)
        };
        let acc = arena.leaf(Op::Acc);
        let mut prev = [NIL; LAGS];
        prev[0] = acc;
        let step = rebuild(arena, body, index, &prev, NIL);
        let base = arena.konst(train[0]);
        return arena.tri(Op::Rec, count, base, step);
    }
    let index = if offset > DIRECT_OFFSET {
        // The history index is i - offset; the body wants the true index.
        let i = arena.leaf(Op::Idx);
        let k = arena.konst(o);
        arena.bin(Op::Add, i, k)
    } else {
        arena.leaf(Op::Idx)
    };
    let halved = {
        let i = arena.leaf(Op::Idx);
        let h = arena.un(Op::Half, i);
        arena.un(Op::CGet, h)
    };
    let mut prev = [NIL; LAGS];
    for k in 1..=(lag as usize) {
        prev[k - 1] = previous(arena, k);
    }
    let step = rebuild(arena, body, index, &prev, halved);
    seeded(arena, step, seeds, offset, train)
}

/// Whether a program reproduces the training window. Solver and sketch
/// outputs are checked this way before they are offered.
pub fn reproduces(nodes: &[Node], program: u32, offset: u32, train: &[V; TRAIN], fuel: i64) -> bool {
    (0..TRAIN).all(|j| Interp::run(nodes, program, offset as i128 + j as i128, fuel) == Some(train[j] as i128))
}

/// Run mode II over every target. Returns the number of improved targets.
pub fn search(arena: &mut Arena, corpus: &mut Corpus, d: &Dag, threads: usize) -> usize {
    let n = corpus.targets.len();
    let threads = threads.max(1);
    let chunk = (n + threads - 1) / threads;
    let mut found: Vec<(u32, u16, u32, u8)> = Vec::new();
    {
        let targets = &corpus.targets;
        let nodes: &[Node] = &arena.nodes;
        let results: Vec<Vec<(u32, u16, u32, u8)>> = std::thread::scope(|scope| {
            let handles: Vec<_> = (0..threads)
                .map(|w| {
                    scope.spawn(move || {
                        let mut vals = vec![0 as V; d.op.len()];
                        let mut scratch = vec![0 as V; d.op.len()];
                        let mut survivors: Vec<(u32, u8)> = Vec::new();
                        let mut out = Vec::new();
                        for ti in (w * chunk).min(n)..((w + 1) * chunk).min(n) {
                            let t = &targets[ti];
                            if let Some((pos, seeds, cost)) = best_body(d, nodes, t.offset, &t.train, t.cost, &mut vals, &mut scratch, &mut survivors) {
                                out.push((ti as u32, cost, pos, seeds));
                            }
                        }
                        out
                    })
                })
                .collect();
            handles.into_iter().map(|h| h.join().unwrap()).collect()
        });
        for r in results {
            found.extend(r);
        }
    }
    found.sort_unstable();
    let mut improved = 0;
    for (ti, cost, pos, seeds) in found {
        let (offset, train) = {
            let t = &corpus.targets[ti as usize];
            (t.offset, t.train)
        };
        let program = emit(arena, d.node[pos as usize], seeds as usize, offset, &train);
        if corpus.offer(ti, cost, program, Mode::Recurrence) {
            improved += 1;
        }
    }
    improved
}
