//! The pinned OEIS inventory and its training targets.
//!
//! A target is a distinct (offset, first eight terms) pair. Search sees only
//! targets. When the input file also carries later terms they stay in `Seq`
//! and are read by the diagnostic scorer alone; the production pipeline gives
//! the engine a file with training terms only.

use crate::lang::*;
use std::io::{BufRead, BufReader};

/// Training terms. Protocol P8 searches on eight terms and tests on the next
/// twelve; protocol P20 searches on twenty and tests on every later term.
#[cfg(not(feature = "p20"))]
pub const TRAIN: usize = 8;
#[cfg(feature = "p20")]
pub const TRAIN: usize = 20;
/// Held-out terms read by the diagnostic scorer.
#[cfg(not(feature = "p20"))]
pub const TEST: usize = 12;
#[cfg(feature = "p20")]
pub const TEST: usize = 30;
/// Whether the diagnostic test needs every one of the TEST terms.
#[cfg(not(feature = "p20"))]
pub const TEST_EXACT: bool = true;
#[cfg(feature = "p20")]
pub const TEST_EXACT: bool = false;
/// Fewest training positions a recurrence or solver must reproduce beyond
/// the terms it takes as given.
#[cfg(not(feature = "p20"))]
pub const MIN_CHECKS: usize = 3;
#[cfg(feature = "p20")]
pub const MIN_CHECKS: usize = 8;
/// Spare equations an exact solve must satisfy beyond its unknowns.
#[cfg(not(feature = "p20"))]
pub const SPARE: usize = 2;
#[cfg(feature = "p20")]
pub const SPARE: usize = 4;
/// Sentinel for a recorded term too large for exact machine comparison.
pub const BIG: i128 = i128::MAX;

pub struct Seq {
    pub id: String,
    pub offset: u32,
    pub terms: Vec<i128>,
    pub target: u32,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum Mode {
    None,
    Constant,
    Closed,
    Affine,
    Recurrence,
    Linear,
    Periodic,
    Polynomial,
    Hypergeometric,
    Holonomic,
    Tail,
}

impl Mode {
    pub fn name(self) -> &'static str {
        match self {
            Mode::None => "None",
            Mode::Constant => "Constant",
            Mode::Closed => "Closed",
            Mode::Affine => "Affine",
            Mode::Recurrence => "Recurrence",
            Mode::Linear => "Linear",
            Mode::Periodic => "Periodic",
            Mode::Polynomial => "Polynomial",
            Mode::Hypergeometric => "Hypergeometric",
            Mode::Holonomic => "Holonomic",
            Mode::Tail => "Tail",
        }
    }
}

pub struct Target {
    /// OEIS offset: the input of the first training term.
    pub offset: u32,
    /// Window used for closed-form lookup. Equal to `offset` when that is
    /// small; otherwise 0, with `shift = offset` applied through Let.
    pub window: u8,
    pub shift: i64,
    pub train: [V; TRAIN],
    pub seqs: Vec<u32>,
    pub cost: u16,
    pub node: u32,
    pub mode: Mode,
    /// Closed classes the selected program was built from (for the library).
    pub from: [u32; 3],
}

pub struct Corpus {
    pub seqs: Vec<Seq>,
    pub targets: Vec<Target>,
    pub by_key: FxMap<(u32, [V; TRAIN]), u32>,
    pub exact: FxMap<(u8, [V; TRAIN]), Vec<u32>>,
    /// Normalized consecutive differences -> targets, for c1*x + c0 closure.
    pub affine: FxMap<(u8, [V; TRAIN - 1]), Vec<u32>>,
    /// Sequences whose training terms exceed the machine range.
    pub unreachable: usize,
    /// Sequences skipped because an earlier round solved their target.
    pub solved: usize,
    pub max_window: usize,
}

/// Divide consecutive differences by their signed gcd. `None` for constants.
pub fn normalize(w: &[V; TRAIN]) -> Option<([V; TRAIN - 1], i128)> {
    let mut d = [0i128; TRAIN - 1];
    let mut g: i128 = 0;
    for j in 0..TRAIN - 1 {
        d[j] = w[j + 1] as i128 - w[j] as i128;
        g = gcd(g, d[j]);
    }
    if g == 0 {
        return None;
    }
    let first = d.iter().find(|x| **x != 0).copied().unwrap();
    let s = if first < 0 { -g } else { g };
    let mut out = [0 as V; TRAIN - 1];
    for j in 0..TRAIN - 1 {
        out[j] = (d[j] / s) as V;
    }
    Some((out, s))
}

impl Corpus {
    /// `solved` lists targets ("offset<TAB>terms") that already have a
    /// program from an earlier round; they are not searched again.
    pub fn load(path: &str, max_window: usize, solved: &std::collections::HashSet<String>) -> Corpus {
        let file = std::fs::File::open(path).unwrap_or_else(|e| panic!("cannot open {}: {}", path, e));
        let mut seqs: Vec<Seq> = Vec::new();
        for line in BufReader::new(file).lines() {
            let line = line.unwrap();
            let mut parts = line.split('\t');
            let id = parts.next().unwrap().to_string();
            let offset: u32 = parts.next().unwrap().parse().unwrap_or(u32::MAX);
            let terms: Vec<i128> = parts
                .next()
                .unwrap_or("")
                .split(',')
                .map(|t| match t.parse::<i128>() {
                    Ok(v) if v >= 0 && v < CAP => v,
                    _ => BIG,
                })
                .collect();
            seqs.push(Seq { id, offset, terms, target: NIL });
        }
        let mut corpus = Corpus {
            seqs,
            targets: Vec::new(),
            by_key: FxMap::default(),
            exact: FxMap::default(),
            affine: FxMap::default(),
            unreachable: 0,
            solved: 0,
            max_window,
        };
        for si in 0..corpus.seqs.len() {
            let s = &corpus.seqs[si];
            if s.offset > 1_000_000 || s.terms.len() < TRAIN {
                corpus.unreachable += 1;
                continue;
            }
            let mut train = [0 as V; TRAIN];
            let mut fits = true;
            for j in 0..TRAIN {
                let t = s.terms[j];
                if t == BIG || t >= VMAX as i128 {
                    fits = false;
                    break;
                }
                train[j] = t as V;
            }
            if !fits {
                corpus.unreachable += 1;
                continue;
            }
            if !solved.is_empty() {
                let text: Vec<String> = train.iter().map(|x| x.to_string()).collect();
                if solved.contains(&format!("{}\t{}", s.offset, text.join(","))) {
                    corpus.solved += 1;
                    continue;
                }
            }
            let key = (s.offset, train);
            let ti = match corpus.by_key.get(&key) {
                Some(&ti) => ti,
                None => {
                    let ti = corpus.targets.len() as u32;
                    let (window, shift) = if (s.offset as usize) <= max_window { (s.offset as u8, 0) } else { (0u8, s.offset as i64) };
                    corpus.targets.push(Target {
                        offset: s.offset,
                        window,
                        shift,
                        train,
                        seqs: Vec::new(),
                        cost: u16::MAX,
                        node: NIL,
                        mode: Mode::None,
                        from: [NIL; 3],
                    });
                    corpus.by_key.insert(key, ti);
                    corpus.exact.entry((window, train)).or_default().push(ti);
                    if let Some((norm, _)) = normalize(&train) {
                        corpus.affine.entry((window, norm)).or_default().push(ti);
                    }
                    ti
                }
            };
            corpus.targets[ti as usize].seqs.push(si as u32);
            corpus.seqs[si].target = ti;
        }
        corpus
    }

    /// Record a candidate program for a target. Strictly cheaper programs
    /// win; callers present candidates in a deterministic order.
    #[inline]
    pub fn offer(&mut self, ti: u32, cost: u16, node: u32, mode: Mode) -> bool {
        let t = &mut self.targets[ti as usize];
        if cost < t.cost {
            t.cost = cost;
            t.node = node;
            t.mode = mode;
            t.from = [NIL; 3];
            true
        } else {
            false
        }
    }
}

/// Wrap a window-relative program for a target with a large offset:
/// Let[Monus[Var, Const[shift]], program].
pub fn shifted(arena: &mut Arena, node: u32, shift: i64) -> u32 {
    if shift == 0 {
        return node;
    }
    let var = arena.leaf(Op::Var);
    let k = arena.konst(shift);
    let m = arena.bin(Op::Monus, var, k);
    arena.bin(Op::Let, m, node)
}

/// Cost of the Let wrapper for a shifted input.
pub fn shift_cost(shift: i64) -> u16 {
    if shift == 0 {
        0
    } else {
        2 + const_cost(shift as i128)
    }
}

#[derive(Default, Clone, Copy, Debug)]
pub struct Score {
    pub targets_fit: usize,
    pub train_fit: usize,
    pub joint_fit: usize,
    pub unverified: usize,
    pub inconsistent: usize,
}
