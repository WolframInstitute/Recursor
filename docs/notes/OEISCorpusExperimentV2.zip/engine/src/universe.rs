//! A size-stratified set of programs up to observational equivalence.
//!
//! `Universe<N>` keeps one representative program per distinct vector of N
//! observed values. Closed programs are observed on the inputs n = 0..N-1.
//! Open programs (loop bodies, recurrence steps) are observed on N sample
//! environments, so their equivalence is empirical: two bodies that agree on
//! every sample are merged. Merging can only lose candidates, never produce a
//! wrong program, because every reported program is evaluated exactly.

use crate::lang::*;

pub struct Universe<const N: usize> {
    pub vecs: Vec<[V; N]>,
    pub node: Vec<u32>,
    /// levels[s] = half-open class range of programs with s nodes.
    pub levels: Vec<(usize, usize)>,
    pub index: FxMap<[V; N], u32>,
    /// Per size: classes that introduce a new zero pattern (Ifz conditions).
    pub cond: Vec<Vec<u32>>,
    pub patterns: FxMap<(u32, u32), u32>,
    pub candidates: u64,
}

#[inline(always)]
pub fn all_bot<const N: usize>(v: &[V; N]) -> bool {
    v.iter().all(|x| *x == BOT)
}

#[inline(always)]
pub fn pattern<const N: usize>(v: &[V; N]) -> (u32, u32) {
    let mut zero = 0u32;
    let mut bot = 0u32;
    for (i, x) in v.iter().enumerate() {
        if *x == BOT {
            bot |= 1 << i;
        } else if *x == 0 {
            zero |= 1 << i;
        }
    }
    (zero, bot)
}

impl<const N: usize> Universe<N> {
    pub fn new() -> Self {
        Universe {
            vecs: Vec::new(),
            node: Vec::new(),
            levels: vec![(0, 0)],
            index: FxMap::default(),
            cond: vec![Vec::new()],
            patterns: FxMap::default(),
            candidates: 0,
        }
    }
    pub fn len(&self) -> usize {
        self.vecs.len()
    }
    pub fn range(&self, s: usize) -> (usize, usize) {
        if s < self.levels.len() {
            self.levels[s]
        } else {
            (0, 0)
        }
    }
    pub fn contains(&self, v: &[V; N]) -> bool {
        self.index.contains_key(v)
    }
    pub fn begin_level(&mut self, s: usize) {
        let n = self.len();
        while self.levels.len() <= s {
            self.levels.push((n, n));
        }
        self.levels[s] = (n, n);
        while self.cond.len() <= s {
            self.cond.push(Vec::new());
        }
    }
    pub fn end_level(&mut self, s: usize) {
        self.levels[s].1 = self.len();
    }
    /// Store a new class. The caller has checked `contains`.
    pub fn insert(&mut self, v: [V; N], size: usize, node: u32) -> u32 {
        let id = self.vecs.len() as u32;
        self.vecs.push(v);
        self.node.push(node);
        self.index.insert(v, id);
        let p = pattern(&v);
        let full: u32 = if N >= 32 { u32::MAX } else { (1u32 << N) - 1 };
        if p.0 != 0 && (p.0 | p.1) != full && !self.patterns.contains_key(&p) {
            self.patterns.insert(p, id);
            while self.cond.len() <= size {
                self.cond.push(Vec::new());
            }
            self.cond[size].push(id);
        }
        id
    }
    /// Insert if the vector is new and has at least one value.
    pub fn offer(&mut self, arena: &mut Arena, v: [V; N], size: usize, op: Op, a: u32, b: u32, c: u32) -> Option<u32> {
        self.candidates += 1;
        if all_bot(&v) || self.contains(&v) {
            return None;
        }
        let node = arena.mk(op, 0, a, b, c);
        Some(self.insert(v, size, node))
    }
}

pub const UNARY: [Op; 3] = [Op::Succ, Op::Pred, Op::Half];
pub const COMMUTATIVE: [Op; 2] = [Op::Add, Op::Mul];
pub const ORDERED: [Op; 3] = [Op::Monus, Op::Rem, Op::Quot];

/// Enumerate every arithmetic or conditional program with exactly `s` nodes
/// whose children are stored classes, and hand each candidate to `f`.
pub fn arithmetic<const N: usize, F>(u: &mut Universe<N>, arena: &mut Arena, s: usize, mut f: F)
where
    F: FnMut(&mut Universe<N>, &mut Arena, [V; N], Op, u32, u32, u32),
{
    let (lo, hi) = u.range(s - 1);
    for xi in lo..hi {
        let x = u.vecs[xi];
        let xn = u.node[xi];
        for op in UNARY {
            let mut v = [0 as V; N];
            for t in 0..N {
                v[t] = v1(op, x[t]);
            }
            f(u, arena, v, op, xn, NIL, NIL);
        }
    }
    if s >= 3 {
        for i in 1..=(s - 2) {
            let j = s - 1 - i;
            let (ilo, ihi) = u.range(i);
            let (jlo, jhi) = u.range(j);
            for xi in ilo..ihi {
                let x = u.vecs[xi];
                let xn = u.node[xi];
                for yi in jlo..jhi {
                    let y = u.vecs[yi];
                    let yn = u.node[yi];
                    if i < j || (i == j && xi <= yi) {
                        for op in COMMUTATIVE {
                            let mut v = [0 as V; N];
                            for t in 0..N {
                                v[t] = v2(op, x[t], y[t]);
                            }
                            f(u, arena, v, op, xn, yn, NIL);
                        }
                    }
                    for op in ORDERED {
                        let mut v = [0 as V; N];
                        for t in 0..N {
                            v[t] = v2(op, x[t], y[t]);
                        }
                        f(u, arena, v, op, xn, yn, NIL);
                    }
                }
            }
        }
    }
    if s >= 4 {
        for i in 1..=(s - 3) {
            let conds: Vec<u32> = if i < u.cond.len() { u.cond[i].clone() } else { Vec::new() };
            if conds.is_empty() {
                continue;
            }
            for j in 1..=(s - 2 - i) {
                let k = s - 1 - i - j;
                let (jlo, jhi) = u.range(j);
                let (klo, khi) = u.range(k);
                for &ci in &conds {
                    let c = u.vecs[ci as usize];
                    let cn = u.node[ci as usize];
                    for zi in jlo..jhi {
                        let z = u.vecs[zi];
                        let zn = u.node[zi];
                        for pi in klo..khi {
                            if zi == pi {
                                continue;
                            }
                            let p = u.vecs[pi];
                            let pn = u.node[pi];
                            let mut v = [0 as V; N];
                            for t in 0..N {
                                v[t] = if c[t] == BOT {
                                    BOT
                                } else if c[t] == 0 {
                                    z[t]
                                } else {
                                    p[t]
                                };
                            }
                            f(u, arena, v, Op::Ifz, cn, zn, pn);
                        }
                    }
                }
            }
        }
    }
}

/// Build an open universe from leaves, with programs of at most `max` nodes.
pub fn build_open<const N: usize>(arena: &mut Arena, leaves: &[(Op, i64, [V; N])], max: usize) -> Universe<N> {
    let mut u: Universe<N> = Universe::new();
    u.begin_level(1);
    for (op, k, v) in leaves {
        if !u.contains(v) {
            let node = arena.mk(*op, *k, NIL, NIL, NIL);
            u.insert(*v, 1, node);
        }
    }
    u.end_level(1);
    for s in 2..=max {
        u.begin_level(s);
        arithmetic(&mut u, arena, s, |u, arena, v, op, a, b, c| {
            u.offer(arena, v, s, op, a, b, c);
        });
        u.end_level(s);
    }
    u
}
